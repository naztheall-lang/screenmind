package com.screenmind.app.ui

import android.os.Bundle
import com.screenmind.app.assistant.CloudConfig
import com.screenmind.app.services.Analyzer
import com.screenmind.app.settings.PerformanceProfile
import com.screenmind.app.settings.Settings

class SettingsActivity : BaseActivity() {
    private val settings by lazy { Settings(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun build() {
        val page = page("Settings")
        page.heading("Performance")
        for (p in PerformanceProfile.values()) {
            val title = (if (p == settings.performance) "● " else "○ ") + p.label
            page.add(card(title, "${p.captureWidth}px capture · auto check every ${p.frameIntervalMs / 1000.0}s · depth ${p.depth} · ${p.threads} thread(s) · ${p.hashMb} MB") {
                settings.performance = p
                build()
            }, bottom = 4)
        }
        page.note("Fast and strong answers in a few seconds using nearly all processor cores.")
        page.note("A new capture size applies the next time screen reading starts.")
        val depth = settings.depth
        page.add(button("Engine depth: ${if (depth == 0) "from profile" else depth.toString()}") {
            val values = listOf(0, 8, 10, 12, 14, 16, 18, 20, 22)
            choose("Search depth", values.map { if (it == 0) "From profile" else it.toString() }) {
                settings.depth = values[it]
                build()
            }
        })
        page.heading("Floating panel")
        page.add(button("Default size: ${listOf("Small", "Medium", "Large")[settings.panelSize.coerceIn(0, 2)]}") {
            settings.panelSize = (settings.panelSize + 1) % 3
            build()
        })
        page.heading("Privacy")
        page.add(toggle("Keep text history on this phone", settings.saveHistory) { settings.saveHistory = it })
        page.add(button("Clear history") { confirm("Clear history?", "This cannot be undone.", "Clear") { Analyzer.history(this).clear() } })
        page.add(button("Forget learned piece styles") { confirm("Forget styles?", "Chess scans will need teaching again.", "Forget") { Analyzer.forgetStyles(this) } })
        page.heading("Online AI (optional)")
        page.note("Off by default. Works with any OpenAI-compatible https service that you choose, including free tiers. Their terms, limits and availability can change.")
        page.add(toggle("Enable online AI button", settings.cloudEnabled) { settings.cloudEnabled = it })
        val config = settings.cloud
        val url = page.add(input("Base URL, e.g. https://generativelanguage.googleapis.com/v1beta/openai/", config.baseUrl))
        val model = page.add(input("Model name from the service", config.model))
        val key = page.add(input("API key if required (stored on this phone)", config.apiKey, secret = true))
        page.add(button("Fill in Google Gemini (add your own free key)") {
            url.setText("https://generativelanguage.googleapis.com/v1beta/openai/")
            model.setText("gemini-3.8-flash")
            toast("Paste your API key, tap Save, and switch the online AI on")
        })
        page.add(button("Save online settings", true) {
            settings.cloud = CloudConfig(url.text.toString().trim(), model.text.toString().trim(), key.text.toString().trim())
            toast(if (settings.cloud.usable) "Saved" else "Saved, but it needs an https address and a model")
        })
    }
}
