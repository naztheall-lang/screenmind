package com.screenmind.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import com.screenmind.app.chess.FairPlayVerdict
import com.screenmind.app.chess.Fen
import com.screenmind.app.chess.FenException
import com.screenmind.app.chess.Game
import com.screenmind.app.chess.Move
import com.screenmind.app.chess.Pgn
import com.screenmind.app.chess.PgnGame
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.PositionValidator
import com.screenmind.app.chess.San
import com.screenmind.app.chess.Side
import com.screenmind.app.engine.AnalysisRequest
import com.screenmind.app.engine.AnalysisResult
import com.screenmind.app.engine.CandidateLine
import com.screenmind.app.engine.DeepSearch
import com.screenmind.app.engine.ChessEngine
import com.screenmind.app.engine.EngineException
import com.screenmind.app.engine.EngineProvider
import com.screenmind.app.engine.GameReview
import com.screenmind.app.engine.GameReviewer
import com.screenmind.app.engine.MoveExplainer
import com.screenmind.app.services.Analyzer
import com.screenmind.app.services.ChessSnapshot
import com.screenmind.app.services.SessionService
import com.screenmind.app.settings.Settings
import com.screenmind.app.utils.Bitmaps
import com.screenmind.app.vision.PieceProfile
import com.screenmind.app.vision.PieceRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

/** Practice board, position editor, engine analysis and post-game review. */
class ChessActivity : BaseActivity() {
    private lateinit var board: ChessBoardView
    private lateinit var status: TextView
    private lateinit var bar: EvalBar
    private lateinit var evaluation: TextView
    private lateinit var lines: LinearLayout
    private val settings by lazy { Settings(this) }
    private var game = Game()
    private var engine: ChessEngine? = null
    private var job: Job? = null
    private var selected: Int? = null
    /** Non-null while the position editor is open. */
    private var editing: Array<Piece?>? = null
    private var brush: Piece? = null
    /** The scan being corrected, so fixes can be learned. */
    private var scan: ChessSnapshot? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = page("Chess analysis")
        page.note("For practice and finished games only.")
        board = ChessBoardView(this) { tap(it) }
        bar = page.add(EvalBar(this))
        page.add(board)
        status = page.note("", Ui.TEXT)
        page.add(row(button("◀") { step(-1) }, button("▶") { step(1) }, button("Flip") { board.flipped = !board.flipped }, button("New") { load(Game()) }))
        page.add(button("Analyse position", true) { analyse() })
        evaluation = page.note("", Ui.ACCENT)
        lines = page.add(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL })
        page.heading("Position")
        page.add(row(button("Edit board") { toggleEditor() }, button("Turn / rights") { positionOptions() }))
        page.add(row(button("Load FEN") { askText("FEN") { loadFen(it) } }, button("Copy FEN") { copy(game.current.toFen()) }))
        page.heading("Games")
        page.add(row(button("Paste PGN") { askText("PGN") { loadPgn(it) } }, button("Open PGN file") { pick("*/*", PICK_PGN) }))
        page.add(row(button("Review game") { review() }, button("Copy PGN") { copy(Pgn.write(game)) }))
        page.heading("From a screen")
        page.add(row(button("Use last scan") { importScan() }, button("Open screenshot") { pick("image/*", PICK_IMAGE) }))
        page.add(button("Save corrections to piece style") { learn() })

        val fen = savedInstanceState?.getString("fen") ?: intent.getStringExtra(EXTRA_FEN)
        if (fen != null) loadFen(fen) else show()
        if (savedInstanceState == null && intent.getBooleanExtra(EXTRA_IMPORT, false)) importScan()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_FEN)?.let { loadFen(it) }
        if (intent.getBooleanExtra(EXTRA_IMPORT, false)) importScan()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("fen", game.current.toFen())
    }

    override fun onStop() {
        super.onStop()
        stopEngine()
    }

    private fun stopEngine() {
        job?.cancel()
        engine?.close()
        engine = null
    }

    private fun load(next: Game) {
        job?.cancel()
        game = next
        editing = null
        scan = null
        selected = null
        board.doubtful = emptySet()
        show()
    }

    private fun show() {
        val position = game.current
        board.position = editing?.let { Position(it, Side.WHITE, 0, null, 0, 1) } ?: position
        board.selected = selected
        board.targets = selected?.let { from -> position.legalMoves().filter { it.from == from }.map { it.to }.toSet() } ?: emptySet()
        board.lastMove = if (editing == null) game.lastMove else null
        board.arrow = null
        board.refresh()
        lines.removeAllViews()
        evaluation.text = ""
        if (editing != null) {
            editorPalette()
            return
        }
        val state = game.status()
        val check = if (!state.isOver && position.isInCheck()) " · check" else ""
        val last = game.lastMove?.let { " · last: " + San.write(game.positionAt(game.ply - 1), it) } ?: ""
        status.text = (if (state.isOver) state.message else "${position.sideToMove.title} to move$check") + last
    }

    private fun step(by: Int) {
        job?.cancel()
        selected = null
        val before = game.ply
        val undone = game.lastMove
        game.goTo(game.ply + by)
        show()
        if (game.ply > before) game.lastMove?.let { board.slide(it.from, it.to) }
        if (game.ply < before) undone?.let { board.slide(it.to, it.from) }
    }

    private fun tap(square: Int) {
        val edit = editing
        if (edit != null) {
            edit[square] = brush
            board.doubtful = board.doubtful - square
            show()
            return
        }
        val from = selected
        val position = game.current
        val options = position.legalMoves().filter { it.from == from && it.to == square }
        if (options.isNotEmpty()) {
            if (options.size > 1) {
                choose("Promote to", options.map { it.promotion!!.word }) { play(options[it]) }
            } else play(options[0])
            return
        }
        selected = if (position[square]?.side == position.sideToMove && square != from) square else null
        show()
    }

    private fun play(move: Move) {
        job?.cancel()
        selected = null
        game.play(move)
        show()
        board.slide(move.from, move.to)
    }

    /** Why the engine may not run now, or null. */
    private fun engineBlock(): String? {
        if (SessionService.instance?.isReading == true) return "Stop screen reading before using the engine."
        val wait = (settings.engineLockedUntil - System.currentTimeMillis()) / 1000
        return if (wait > 0) "Locked for ${wait}s because a possible live game was seen." else null
    }

    private fun obtainEngine(): ChessEngine = engine ?: EngineProvider.create(this).also { engine = it }

    private fun analyse() {
        if (editing != null) {
            toast("Finish editing first")
            return
        }
        engineBlock()?.let { return message("Engine unavailable", it) }
        val position = game.current
        val problems = PositionValidator.problems(position)
        if (problems.isNotEmpty()) return message("Invalid position", problems.joinToString("\n"))
        if (game.status().isOver) {
            evaluation.text = game.status().message
            return
        }
        val request = AnalysisRequest(position, game.start.toFen(), game.movesToCurrent)
        val previous = job
        evaluation.text = "Thinking…"
        job = scope.launch {
            previous?.cancel()
            previous?.join()
            try {
                val base = settings.performance.engineSettings(settings.depth)
                // Leave one core free so the screen stays responsive.
                val cores = maxOf(1, Runtime.getRuntime().availableProcessors() - 1)
                val deep = DeepSearch.run(
                    obtainEngine(), request, base.copy(threads = minOf(base.threads, cores)),
                    onUpdate = { partial -> runOnUiThread { if (game.current === position) present(position, partial, null) } },
                    onHunt = { runOnUiThread { if (game.current === position) evaluation.append("\nHunting for Brilliant sacrifices…") } },
                )
                val result = deep.main
                present(position, result, deep.brilliant)
                Analyzer.history(this@ChessActivity).takeIf { settings.saveHistory }?.add(
                    com.screenmind.app.history.HistoryEntry(
                        System.currentTimeMillis(), com.screenmind.app.history.HistoryKind.CHESS,
                        (deep.brilliant.firstOrNull() ?: result.lines.firstOrNull())?.let { MoveExplainer.title(position, it) } ?: "Analysis", position.toFen(),
                    )
                )
            } catch (e: EngineException) {
                evaluation.text = "Engine error: ${e.message}"
            }
        }
    }

    /** [brilliant] is null while the search is still running. */
    private fun present(position: Position, result: AnalysisResult, brilliant: List<CandidateLine>?) {
        val done = brilliant != null
        val best = result.lines.firstOrNull() ?: return
        val found = brilliant.orEmpty()
        val mate = best.score.mateIn
        val mine = if (mate != null) (if (mate > 0) 1000 else -1000) else best.score.centipawns ?: 0
        val white = if (position.sideToMove == Side.WHITE) mine else -mine
        bar.show((0.5 + kotlin.math.atan(white / 250.0) / Math.PI).toFloat())
        val verdict = when {
            found.isNotEmpty() -> "\n!! ${found.size} Brilliant move${if (found.size > 1) "s" else ""} found"
            done -> "\nNo sound Brilliant (sacrifice) found here. Best moves below."
            else -> ""
        }
        evaluation.text = "${MoveExplainer.describe(best.score, position.sideToMove)} (${best.score.display(position.sideToMove)})\n" +
            "${result.engineName} · depth ${result.depth}" + (if (done) "" else " · searching") + verdict +
            (if (result.engineName.startsWith("Basic")) "\n⚠ Stockfish is not running, so these moves are weak." else "")
        lines.removeAllViews()
        // A Brilliant move, when one exists, goes to the top.
        val shown = (found + result.lines.take(5)).distinctBy { it.move }
        for (line in shown) {
            val detail = MoveExplainer.explain(position, line, best) + "\n" + MoveExplainer.moveLine(position, line.pv)
            val special = found.any { it.move == line.move }
            val risky = !special && best.score.value() - line.score.value() > 90
            val label = if (special) "!! Brilliant · " else if (risky) "⚠ Much weaker · " else "${line.rank}. "
            val note = if (special) "Gives up material on purpose and the engine still approves.\n" else ""
            val entry = card(label + MoveExplainer.title(position, line), note + detail) {
                board.arrow = line.move
                board.refresh()
            }
            if (special) entry.background = Ui.box(this, Ui.SURFACE, Ui.BRILLIANT)
            lines.add(entry, bottom = 6)
            if (!done) {
                // Live updates redraw often, so only the final list is animated.
                entry.animate().cancel()
                entry.alpha = 1f
                entry.translationY = 0f
            }
        }
        if (board.arrow == null || done) {
            board.arrow = (found.firstOrNull() ?: best).move
            board.refresh()
        }
    }

    private fun review() {
        engineBlock()?.let { return message("Engine unavailable", it) }
        if (game.length == 0) return message("Nothing to review", "Load a PGN or play some moves first.")
        val reviewed = game
        val previous = job
        job = scope.launch {
            previous?.cancel()
            previous?.join()
            val quick = settings.performance.engineSettings(settings.depth).let { it.copy(depth = minOf(it.depth, 14), moveTimeMs = minOf(it.moveTimeMs / 2, 2500L)) }
            try {
                val result = GameReviewer(obtainEngine()).review(reviewed, quick) { done, total ->
                    runOnUiThread { evaluation.text = "Reviewing $done / $total (tap ◀ to cancel)" }
                }
                showReview(result)
            } catch (e: EngineException) {
                evaluation.text = "Review failed: ${e.message}"
            }
        }
    }

    private fun showReview(review: GameReview) {
        evaluation.text = review.summary()
        lines.removeAllViews()
        for (m in review.moves) {
            val number = (m.ply + 1) / 2
            val better = m.bestSan?.let { " · engine preferred $it" } ?: ""
            lines.add(card("$number${if (m.side == Side.WHITE) "." else "…"} ${m.san}${m.quality.mark}  ${m.evaluation}", m.quality.label + better) {
                game.goTo(m.ply)
                board.position = game.current
                board.lastMove = game.lastMove
                board.arrow = null
                board.refresh()
                status.text = "After ${m.san}"
            }, bottom = 4)
        }
    }

    private fun askText(title: String, onText: (String) -> Unit) {
        val field = input(title, lines = 4)
        android.app.AlertDialog.Builder(this).setTitle("Paste $title").setView(field)
            .setPositiveButton("Load") { _, _ -> onText(field.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun loadFen(text: String) {
        try {
            val p = Fen.parse(text)
            val problems = PositionValidator.problems(p)
            if (problems.isNotEmpty()) message("Invalid position", problems.joinToString("\n")) else load(Game(p))
        } catch (e: FenException) {
            message("Could not read FEN", e.message ?: "")
        }
    }

    private fun loadPgn(text: String) {
        val games = Pgn.parse(text)
        if (games.isEmpty()) return message("PGN", "No game found.")
        fun open(g: PgnGame) {
            g.game.goTo(0)
            load(g.game)
            g.error?.let { message("PGN partly loaded", it) }
        }
        if (games.size == 1) open(games[0]) else choose("Choose a game", games.map { it.title }) { open(games[it]) }
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("chess", text))
        toast("Copied")
    }

    private fun pick(type: String, code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(type)
        startActivityForResult(intent, code)
    }

    @Deprecated("Framework callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val uri: Uri = data?.data?.takeIf { resultCode == RESULT_OK } ?: return
        scope.launch {
            try {
                if (requestCode == PICK_PGN) {
                    val text = withContext(Dispatchers.IO) {
                        contentResolver.openInputStream(uri)?.bufferedReader()?.use { r ->
                            val buffer = CharArray(Pgn.MAX_CHARS)
                            var n = 0
                            while (n < buffer.size) {
                                val read = r.read(buffer, n, buffer.size - n)
                                if (read < 0) break
                                n += read
                            }
                            String(buffer, 0, n)
                        }
                    }
                    loadPgn(text ?: "")
                } else if (requestCode == PICK_IMAGE) {
                    status.text = "Reading picture…"
                    val image = withContext(Dispatchers.IO) { Bitmaps.load(contentResolver, uri) }
                    if (Analyzer.chess(this@ChessActivity, image, true) == null) {
                        message("No board", "No chessboard was found. Use a straight, uncropped screenshot.")
                        show()
                    } else importScan()
                }
            } catch (e: IOException) {
                message("Could not open file", e.message ?: "")
            } catch (e: SecurityException) {
                message("Could not open file", "Permission was refused.")
            }
        }
    }

    private fun importScan() {
        val snapshot = Analyzer.lastChess ?: return message("No scan", "Analyse a board with the floating panel, or open a screenshot.")
        val verdict = snapshot.verdict
        if (verdict is FairPlayVerdict.Blocked) return message("Analysis refused", verdict.reason)
        val note = (verdict as FairPlayVerdict.NeedsConfirmation).note
        confirm("Practice or finished game?", "$note\n\nContinue only if this is not a game in progress.", "It is not live") {
            SessionService.stopReading(this)
            load(Game(snapshot.position))
            scan = snapshot
            board.flipped = !snapshot.whiteAtBottom
            board.doubtful = snapshot.uncertain.toSet()
            board.refresh()
            status.text = snapshot.report()
            if (snapshot.unknown > 0 || snapshot.problems.isNotEmpty()) toggleEditor()
        }
    }

    private fun toggleEditor() {
        val edit = editing
        job?.cancel()
        selected = null
        if (edit == null) {
            editing = game.current.copyBoard()
            show()
            return
        }
        val old = game.current
        val position = Position(edit.copyOf(), old.sideToMove, Position.possibleCastling(edit), null, 0, old.fullmoveNumber)
        // Allow the side to move to be corrected before the position is judged.
        val fixed = if (position.isInCheck(position.sideToMove.other)) {
            Position(edit.copyOf(), old.sideToMove.other, position.castling, null, 0, old.fullmoveNumber)
        } else position
        val problems = PositionValidator.problems(fixed)
        if (problems.isNotEmpty()) return message("Fix the position", problems.joinToString("\n"))
        val keep = scan
        load(Game(fixed))
        scan = keep
    }

    private fun editorPalette() {
        status.text = "Editing: choose a piece, tap squares, then tap Edit board again. Brush: " +
            (brush?.let { "${it.side.title} ${it.type.word}" } ?: "eraser")
        lines.add(button("Choose piece") {
            val pieces: List<Piece?> = listOf<Piece?>(null) + "KQRBNPkqrbnp".map { Piece.fromFen(it) }
            choose("Brush", pieces.map { p -> p?.let { "${it.side.title} ${it.type.word}" } ?: "Eraser" }) {
                brush = pieces[it]
                show()
            }
        })
        lines.add(button("Clear board") {
            editing?.fill(null)
            show()
        })
        lines.add(button("Discard changes") {
            editing = null
            show()
        })
    }

    private fun positionOptions() {
        if (editing != null) return toast("Finish editing first")
        val p = game.current
        val options = mutableListOf("White to move", "Black to move", "Castling: allow where possible", "Castling: none")
        // A pawn that may just have advanced two squares can be captured en passant.
        val white = p.sideToMove == Side.WHITE
        val eps = (0..7).map { (if (white) 40 else 16) + it }.filter {
            PositionValidator.isValid(Position(p.copyBoard(), p.sideToMove, p.castling, it, 0, p.fullmoveNumber))
        }
        eps.forEach { options.add("En passant on ${com.screenmind.app.chess.Squares.name(it)}") }
        choose("Position options", options) { i ->
            val side = when (i) {
                0 -> Side.WHITE
                1 -> Side.BLACK
                else -> p.sideToMove
            }
            val rights = when (i) {
                2 -> Position.possibleCastling(p.copyBoard())
                3 -> 0
                else -> p.castling
            }
            val ep = if (i >= 4) eps[i - 4] else if (i >= 2) p.enPassant else null
            val next = Position(p.copyBoard(), side, rights, ep, p.halfmoveClock, p.fullmoveNumber)
            val problems = PositionValidator.problems(next)
            if (problems.isNotEmpty()) message("Not possible", problems.joinToString("\n")) else {
                val keep = scan
                load(Game(next))
                scan = keep
            }
        }
    }

    private fun learn() {
        val snapshot = scan ?: return message("No scan", "Import a scan, correct it with Edit board, then save.")
        if (editing != null) return toast("Finish editing first")
        val base = Analyzer.styles(this).firstOrNull { it.name == snapshot.styleName }
            ?: PieceProfile("style-${System.currentTimeMillis()}", emptyList())
        val updated = PieceRecognizer.learn(base, snapshot.features, game.start.copyBoard(), snapshot.whiteAtBottom)
        if (updated.templates.isEmpty()) return toast("Nothing to learn")
        Analyzer.saveStyle(this, updated)
        toast("Piece style saved")
    }

    companion object {
        const val EXTRA_IMPORT = "import"
        const val EXTRA_FEN = "fen"
        private const val PICK_PGN = 10
        private const val PICK_IMAGE = 11
    }
}
