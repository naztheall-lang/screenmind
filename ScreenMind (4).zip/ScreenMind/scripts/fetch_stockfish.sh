#!/bin/bash
# Downloads the official Stockfish 17.1 Android binaries (GPL v3) into the app.
set -euo pipefail
cd "$(dirname "$0")/.."
BASE=https://github.com/official-stockfish/Stockfish/releases/download/sf_17.1
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
fetch() { # asset abi
  mkdir -p "$work/$2" "app/src/main/jniLibs/$2"
  curl -fL --retry 3 -o "$work/$1.tar" "$BASE/$1.tar"
  tar -xf "$work/$1.tar" -C "$work/$2"
  bin=$(find "$work/$2" -type f -name "$1" | head -n 1)
  [ -n "$bin" ] || { echo "Binary $1 not found in archive"; exit 1; }
  cp "$bin" "app/src/main/jniLibs/$2/libstockfish.so"
  echo "Installed $1 for $2"
}
fetch stockfish-android-armv8 arm64-v8a
fetch stockfish-android-armv7-neon armeabi-v7a
