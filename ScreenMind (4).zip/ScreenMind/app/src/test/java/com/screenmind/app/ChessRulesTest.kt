package com.screenmind.app

import com.screenmind.app.chess.BoardTracker
import com.screenmind.app.chess.FairPlayGuard
import com.screenmind.app.chess.FairPlayVerdict
import com.screenmind.app.chess.Fen
import com.screenmind.app.chess.Game
import com.screenmind.app.chess.GameStatus
import com.screenmind.app.chess.MoveGen
import com.screenmind.app.chess.Pgn
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.PositionValidator
import com.screenmind.app.chess.San
import com.screenmind.app.chess.ScreenText
import com.screenmind.app.chess.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChessRulesTest {
    private fun perft(fen: String, vararg expected: Long) {
        val p = Fen.parse(fen)
        expected.forEachIndexed { i, n -> assertEquals("depth ${i + 1} of $fen", n, MoveGen.perft(p, i + 1)) }
    }

    // Reference node counts from the Chess Programming Wiki perft suite.
    @Test fun perftStart() = perft(Position.START_FEN, 20, 400, 8902, 197281)
    @Test fun perftKiwipete() =
        perft("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1", 48, 2039, 97862)
    @Test fun perftEnPassantPins() = perft("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 14, 191, 2812, 43238)
    @Test fun perftPromotions() =
        perft("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1", 6, 264, 9467)
    @Test fun perftPosition5() = perft("rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8", 44, 1486, 62379)

    @Test fun fenRoundTrips() {
        for (fen in listOf(Position.START_FEN, "r3k2r/8/8/3pP3/8/8/8/R3K2R w Kq d6 4 20")) {
            assertEquals(fen, Fen.parse(fen).toFen())
        }
    }

    private fun play(game: Game, vararg sans: String) = sans.forEach {
        val m = San.parse(game.current, it)
        assertNotNull(it, m)
        assertTrue(game.play(m!!))
    }

    @Test fun detectsEndings() {
        val mate = Game()
        play(mate, "f3", "e5", "g4", "Qh4#")
        assertEquals(GameStatus.CHECKMATE, mate.status())
        assertEquals("Qh4#", mate.sanList().last())
        assertEquals(GameStatus.STALEMATE, Game.statusOf(Fen.parse("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")))
        assertEquals(GameStatus.INSUFFICIENT_MATERIAL, Game.statusOf(Fen.parse("8/8/4k3/8/8/3BK3/8/8 w - - 0 1")))
        assertEquals(GameStatus.FIFTY_MOVES, Game.statusOf(Fen.parse("8/8/4k3/8/8/3RK3/8/8 w - - 100 80")))
        val rep = Game()
        repeat(2) { play(rep, "Nf3", "Nf6", "Ng1", "Ng8") }
        assertEquals(GameStatus.REPETITION, rep.status())
    }

    @Test fun validatorRejectsImpossiblePositions() {
        assertTrue(PositionValidator.isValid(Position.start()))
        assertTrue(!PositionValidator.isValid(Fen.parse("8/8/8/8/8/8/8/K7 w - - 0 1")))
        assertTrue(!PositionValidator.isValid(Fen.parse("P6k/8/8/8/8/8/8/K7 w - - 0 1")))
        assertTrue(!PositionValidator.isValid(Fen.parse("k7/8/8/8/8/8/8/R6K w - - 0 1")))
        assertTrue(!PositionValidator.isValid(Fen.parse("k7/8/8/8/8/8/8/7K w KQ - 0 1")))
    }

    @Test fun sanDisambiguates() {
        val p = Fen.parse("4k3/8/8/8/8/8/8/R3K2R w - - 0 1")
        assertEquals("Rb1", San.write(p, San.parse(p, "Rb1")!!))
        val knights = Fen.parse("4k3/8/8/8/8/8/3N4/4K1N1 w - - 0 1")
        assertNull(San.parse(knights, "Nf3"))
        assertEquals("Ngf3", San.write(knights, knights.findLegal("g1f3")!!))
    }

    @Test fun parsesPgnWithNoise() {
        val pgn = """
            [Event "Test"]
            [White "A"]
            [Black "B"]

            1. e4 {king pawn (best)} e5 2. Nf3 (2. f4 exf4) Nc6 ${'$'}1 3. Bb5!? a6 ; comment
            4. Ba4 Nf6 5. O-O Be7 1-0

            [Event "Second"]

            1.d4 d5 2.c4 dxc4 *
        """.trimIndent()
        val games = Pgn.parse(pgn)
        assertEquals(2, games.size)
        assertNull(games[0].error)
        assertEquals(10, games[0].game.length)
        assertEquals(4, games[1].game.length)
        val again = Pgn.parse(Pgn.write(games[0].game, games[0].headers))
        assertEquals(games[0].game.current.toFen(), again[0].game.current.toFen())
    }

    @Test fun reportsBadPgnMove() {
        val g = Pgn.parse("1. e4 e5 2. Ke3 *")[0]
        assertNotNull(g.error)
        assertEquals(2, g.game.length)
    }

    @Test fun trackerInfersMovesAndTurn() {
        val game = Game()
        val tracker = BoardTracker()
        assertEquals(Side.WHITE, tracker.update(game.current.copyBoard()).position.sideToMove)
        play(game, "e4")
        val one = tracker.update(game.current.copyBoard())
        assertEquals(1, one.moves.size)
        assertEquals(Side.BLACK, one.position.sideToMove)
        play(game, "a6", "e5", "d5")
        tracker.update(game.positionAt(3).copyBoard())
        val ep = tracker.update(game.current.copyBoard())
        assertEquals("d6", ep.position.toFen().split(" ")[3])
        play(game, "exd6", "Nf6")
        assertEquals(2, tracker.update(game.current.copyBoard()).moves.size)
        assertTrue(!tracker.update(game.current.copyBoard()).changed)
    }

    @Test fun fairPlayBlocksLiveGames() {
        fun t(vararg s: String) = s.map { ScreenText(it, 0.5f) }
        assertTrue(FairPlayGuard.assess(t("Resign", "Offer draw")) is FairPlayVerdict.Blocked)
        assertTrue(FairPlayGuard.assess(t("4:59", "3:12")) is FairPlayVerdict.Blocked)
        assertTrue(FairPlayGuard.assess(t("0:09.4", "1:02:11")) is FairPlayVerdict.Blocked)
        assertTrue(FairPlayGuard.assess(t("Black resigned", "White wins")) is FairPlayVerdict.NeedsConfirmation)
        assertTrue(FairPlayGuard.assess(listOf(ScreenText("16:29", 0.01f), ScreenText("4:00", 0.5f))) is FairPlayVerdict.NeedsConfirmation)
        assertTrue(FairPlayGuard.asksForMove("What's the best move here?"))
        assertTrue(!FairPlayGuard.asksForMove("Where is the export button?"))
    }
}
