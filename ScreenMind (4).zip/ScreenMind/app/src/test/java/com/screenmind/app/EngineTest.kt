package com.screenmind.app

import com.screenmind.app.chess.Fen
import com.screenmind.app.chess.Game
import com.screenmind.app.chess.Pgn
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.San
import com.screenmind.app.engine.AnalysisRequest
import com.screenmind.app.engine.BuiltinEngine
import com.screenmind.app.engine.EngineSettings
import com.screenmind.app.engine.GameReviewer
import com.screenmind.app.engine.MoveExplainer
import com.screenmind.app.engine.MoveQuality
import com.screenmind.app.engine.StockfishEngine
import com.screenmind.app.engine.UciParser
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

class EngineTest {
    private val fast = EngineSettings(depth = 3, moveTimeMs = 4000, multiPv = 5)

    @Test fun builtinReturnsFiveRankedCandidates() = runBlocking {
        val r = BuiltinEngine().analyse(AnalysisRequest(Position.start()), fast)
        assertEquals(5, r.lines.size)
        assertEquals(r.lines.map { it.score.value() }.sortedDescending(), r.lines.map { it.score.value() })
        assertEquals(5, r.lines.map { it.move }.toSet().size)
    }

    @Test fun builtinFindsMateAndExplainsIt() = runBlocking {
        val p = Fen.parse("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1")
        val best = BuiltinEngine().analyse(AnalysisRequest(p), fast).lines[0]
        assertEquals("Ra8#", San.write(p, best.move))
        assertEquals(1, best.score.mateIn)
        assertEquals("Delivers checkmate.", MoveExplainer.explain(p, best))
    }

    @Test fun explainsAWinningCapture() = runBlocking {
        val p = Fen.parse("4k3/8/8/3q4/8/4N3/8/4K3 w - - 0 1")
        val best = BuiltinEngine().analyse(AnalysisRequest(p), fast).lines[0]
        assertEquals("e3d5", best.move.uci())
        assertTrue(MoveExplainer.explain(p, best).contains("queen"))
    }

    @Test fun reviewerFlagsABlunder() = runBlocking {
        val game: Game = Pgn.parse("1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7# 1-0")[0].game
        val review = GameReviewer(BuiltinEngine()).review(game, fast) { _, _ -> }
        assertEquals(7, review.moves.size)
        assertEquals(MoveQuality.BLUNDER, review.moves[5].quality)
        assertEquals(MoveQuality.BEST, review.moves[6].quality)
    }

    @Test fun parsesUciInfo() {
        val line = UciParser.parseInfo(
            "info depth 12 seldepth 18 multipv 2 score cp -31 nodes 1 nps 1 pv e2e4 e7e5", Position.start()
        )
        assertNotNull(line)
        assertEquals(2, line!!.rank)
        assertEquals(-31, line.score.centipawns)
        assertEquals(2, line.pv.size)
        assertNull(UciParser.parseInfo("info depth 3 score cp 10 lowerbound pv e2e4", Position.start()))
        assertNull(UciParser.parseInfo("info string NNUE enabled", Position.start()))
    }

    /** Exercises the process protocol with a scripted stand-in that speaks UCI. */
    @Test fun drivesAUciProcess() = runBlocking {
        val shell = File("/bin/sh")
        assumeTrue(shell.exists())
        val script = File.createTempFile("fakeuci", ".sh")
        script.writeText(
            """
            while read line; do
              case "${'$'}line" in
                uci) echo "id name FakeFish"; echo uciok;;
                isready) echo readyok;;
                go*) echo "info depth 1 multipv 1 score cp 20 pv e2e4"; echo "info depth 1 multipv 2 score cp 10 pv d2d4"; echo "bestmove e2e4";;
                quit) exit 0;;
              esac
            done
            """.trimIndent() + "\n"
        )
        val engine = StockfishEngine(listOf(shell.path, script.path))
        repeat(2) {
            val r = engine.analyse(AnalysisRequest(Position.start()), fast.copy(multiPv = 2))
            assertEquals("FakeFish", r.engineName)
            assertEquals(listOf("e2e4", "d2d4"), r.lines.map { it.move.uci() })
        }
        engine.close()
        script.delete()
        Unit
    }
}
