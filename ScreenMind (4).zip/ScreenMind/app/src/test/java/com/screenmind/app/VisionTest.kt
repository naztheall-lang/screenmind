package com.screenmind.app

import com.screenmind.app.chess.Fen
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.Side
import com.screenmind.app.vision.BoardDetector
import com.screenmind.app.vision.Colors
import com.screenmind.app.vision.PieceArt
import com.screenmind.app.vision.PieceProfile
import com.screenmind.app.vision.PieceRecognizer
import com.screenmind.app.vision.PixelImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Synthetic screenshots drawn with the app's piece shapes. Real third-party themes are not covered. */
class VisionTest {
    private val themes = listOf(
        0xFFF0D9B5.toInt() to 0xFFB58863.toInt(),
        0xFFEBECD0.toInt() to 0xFF739552.toInt(),
        0xFFDEE3E6.toInt() to 0xFF8CA2AD.toInt(),
    )

    private fun inside(p: FloatArray, x: Float, y: Float): Boolean {
        var result = false
        var j = p.size - 2
        for (i in 0 until p.size step 2) {
            if ((p[i + 1] > y) != (p[j + 1] > y) &&
                x < (p[j] - p[i]) * (y - p[i + 1]) / (p[j + 1] - p[i + 1]) + p[i]
            ) result = !result
            j = i
        }
        return result
    }

    private fun render(
        position: Position, left: Int, top: Int, square: Int, theme: Int, whiteBottom: Boolean = true,
        highlight: Set<Int> = emptySet(), width: Int = 720, height: Int = 1600,
    ): PixelImage {
        val img = PixelImage(width, height, IntArray(width * height) { Colors.rgb(38, 36, 33) })
        // Surrounding interface clutter: bars and text-like blocks.
        for (y in 20 until 70) for (x in 0 until width) img.pixels[y * width + x] = Colors.rgb(60, 60, 66)
        for (y in height - 200 until height - 150) for (x in 40 until width - 40) {
            if (x / 14 % 2 == 0) img.pixels[y * width + x] = Colors.rgb(210, 210, 210)
        }
        for (row in 0..7) for (col in 0..7) {
            val sq = PieceRecognizer.toSquare(row * 8 + col, whiteBottom)
            var colour = if ((row + col) % 2 == 0) themes[theme].first else themes[theme].second
            if (sq in highlight) colour = Colors.rgb(205, 210, 70)
            val piece = position[sq]
            val shapes = piece?.let { PieceArt.outline(it.type) }
            val fill = if (piece?.side == Side.WHITE) Colors.rgb(250, 250, 250) else Colors.rgb(45, 42, 40)
            for (y in 0 until square) for (x in 0 until square) {
                var c = colour
                if (shapes != null) {
                    val u = (x + 0.5f) * 100 / square
                    val v = (y + 0.5f) * 100 / square
                    if (shapes.any { inside(it, u, v) }) {
                        val edge = listOf(-3f to 0f, 3f to 0f, 0f to -3f, 0f to 3f).any { (dx, dy) ->
                            shapes.none { inside(it, u + dx, v + dy) }
                        }
                        c = if (edge) Colors.rgb(20, 20, 20) else fill
                    }
                }
                img.pixels[(top + row * square + y) * width + left + col * square + x] = c
            }
        }
        return img
    }

    private fun profile(theme: Int, whiteBottom: Boolean = true): PieceProfile {
        val img = render(Position.start(), 0, 400, 90, theme, whiteBottom)
        val board = BoardDetector.detect(img)!!
        return PieceRecognizer.calibrateFromStart(PieceRecognizer.extract(img, board), "test")!!
    }

    @Test fun findsBoardsOfDifferentSizesAndPlaces() {
        val cases = listOf(listOf(0, 400, 90, 0), listOf(40, 180, 80, 1), listOf(131, 733, 56, 2), listOf(8, 301, 88, 1))
        for ((left, top, square, theme) in cases) {
            val found = BoardDetector.detect(render(Position.start(), left, top, square, theme))
            assertNotNull("board at $left,$top size $square", found)
            assertEquals(left.toFloat(), found!!.left, 4f)
            assertEquals(top.toFloat(), found.top, 4f)
            assertEquals(square * 8f, found.size, 8f)
        }
    }

    @Test fun ignoresScreensWithoutABoard() {
        val img = PixelImage(720, 1600, IntArray(720 * 1600) { if (it / 720 / 90 % 2 == 0) -1 else Colors.rgb(30, 30, 30) })
        assertNull(BoardDetector.detect(img))
    }

    @Test fun learnsAStyleAndReadsOtherPositions() {
        val learned = PieceProfile.parse(profile(0).serialise())!!
        val fens = listOf(
            "r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/3P1N2/PPP2PPP/RNBQK2R w KQkq - 0 1",
            "8/5pk1/6p1/3Q4/2n5/1b4P1/r4P1P/4R1K1 w - - 0 1",
        )
        for (fen in fens) for (flip in listOf(false, true)) {
            val position = Fen.parse(fen)
            val img = render(position, 24, 351, 82, 0, !flip)
            val board = BoardDetector.detect(img)!!
            val reading = PieceRecognizer.read(PieceRecognizer.extract(img, board), listOf(learned))
            assertEquals(!flip, reading.whiteAtBottom)
            assertEquals(position.placement(), Fen.placement(reading.board()))
        }
    }

    @Test fun learnedStyleTransfersToAnotherBoardColour() {
        val position = Fen.parse("r2q1rk1/1b2bppp/p2ppn2/1p6/3NP3/1BN1B3/PPP1QPPP/2KR3R w - - 0 1")
        val img = render(position, 0, 500, 90, 1)
        val reading = PieceRecognizer.read(PieceRecognizer.extract(img, BoardDetector.detect(img)!!), listOf(profile(0)))
        assertEquals(position.placement(), Fen.placement(reading.board()))
    }

    @Test fun withoutAStyleReportsOccupancyOnly() {
        val img = render(Position.start(), 0, 400, 90, 0)
        val reading = PieceRecognizer.read(PieceRecognizer.extract(img, BoardDetector.detect(img)!!), emptyList())
        assertEquals(32, reading.unknownCount)
        assertEquals(16, reading.squares.count { it.side == Side.WHITE })
    }

    @Test fun usesHighlightToFindWhoseTurn() {
        val after = Fen.parse("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1")
        val img = render(after, 0, 400, 90, 0, highlight = setOf(12, 28))
        val reading = PieceRecognizer.read(PieceRecognizer.extract(img, BoardDetector.detect(img)!!), listOf(profile(0)))
        assertEquals(Side.BLACK, reading.turnHint())
        assertTrue(reading.highlighted.size == 2)
    }
}
