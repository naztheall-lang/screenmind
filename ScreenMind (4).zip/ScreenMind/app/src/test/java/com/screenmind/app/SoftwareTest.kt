package com.screenmind.app

import com.screenmind.app.assistant.Certainty
import com.screenmind.app.assistant.CloudClient
import com.screenmind.app.assistant.OfflineAssistant
import com.screenmind.app.assistant.Redactor
import com.screenmind.app.history.HistoryEntry
import com.screenmind.app.history.HistoryKind
import com.screenmind.app.history.HistoryStore
import com.screenmind.app.software.ElementType
import com.screenmind.app.software.IRect
import com.screenmind.app.software.OcrLine
import com.screenmind.app.software.RawNode
import com.screenmind.app.software.RegionDetector
import com.screenmind.app.software.UiClassifier
import com.screenmind.app.utils.Json
import com.screenmind.app.vision.Colors
import com.screenmind.app.vision.PixelImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SoftwareTest {
    private fun node(cls: String, text: String, r: IRect, click: Boolean = false, edit: Boolean = false, pass: Boolean = false) =
        RawNode("android.widget.$cls", text = text, bounds = r, clickable = click, editable = edit, password = pass)

    private val screen = UiClassifier.build(
        "Editor", "x.editor", 720, 1600,
        listOf(
            RawNode(
                "android.widget.FrameLayout", bounds = IRect(0, 0, 720, 1600),
                children = listOf(
                    RawNode("android.widget.ImageButton", description = "More options", bounds = IRect(640, 60, 710, 130), clickable = true),
                    node("Button", "Export", IRect(500, 1450, 700, 1530), click = true),
                    node("EditText", "hunter2", IRect(40, 400, 680, 480), edit = true, pass = true),
                    node("EditText", "me@example.com", IRect(40, 500, 680, 580), edit = true),
                ),
            )
        ),
        listOf(OcrLine("Export", IRect(560, 1470, 650, 1510)), OcrLine("No internet connection", IRect(100, 800, 600, 840))),
    )

    @Test fun classifiesAndMergesSources() {
        assertEquals(1, screen.elements.count { it.label == "Export" })
        assertEquals(ElementType.TOOLBAR, screen.elements.first { it.label == "More options" }.type)
        assertEquals(ElementType.ERROR, screen.elements.first { it.label.startsWith("No internet") }.type)
        assertTrue(screen.elements.none { it.label.contains("hunter2") })
    }

    @Test fun answersFromTheScreen() {
        val where = OfflineAssistant.answer("Where is the export button?", screen)
        assertEquals(Certainty.SURE, where.certainty)
        assertTrue(where.text.contains("bottom right"))
        assertNotNull(where.highlight)
        assertTrue(OfflineAssistant.answer("What does this error mean?", screen).text.contains("internet"))
        assertTrue(OfflineAssistant.answer("Explain this interface", screen).text.contains("Editor"))
        assertTrue(OfflineAssistant.answer("How do I change this setting?", screen).text.contains("More options"))
        val unknown = OfflineAssistant.answer("Where is the frobnicator?", screen)
        assertEquals(Certainty.UNSURE, unknown.certainty)
        assertTrue(unknown.text.contains("can't see"))
        assertTrue(OfflineAssistant.answer("What's the best move?", screen).text.contains("don't suggest moves"))
        assertTrue(OfflineAssistant.answer("How do I create a new project?", null).text.contains("haven't read"))
    }

    @Test fun ocrOnlyGuessesCarryLowerConfidence() {
        val model = UiClassifier.build(
            null, null, 720, 1600, emptyList(),
            listOf(
                OcrLine("Home", IRect(60, 1520, 150, 1560)), OcrLine("Library", IRect(300, 1520, 420, 1560)),
                OcrLine("Profile", IRect(560, 1520, 680, 1560)), OcrLine("Cancel", IRect(300, 900, 420, 940)),
            ),
        )
        assertEquals(3, model.elements.count { it.type == ElementType.NAV_BAR })
        assertEquals(ElementType.BUTTON, model.elements.first { it.label == "Cancel" }.type)
        assertTrue(model.elements.all { it.confidence < 0.9f })
        assertTrue(model.summary().contains("estimates"))
    }

    @Test fun findsButtonShapedRegions() {
        val img = PixelImage(720, 1600, IntArray(720 * 1600) { Colors.rgb(20, 20, 20) })
        for (y in 1000 until 1090) for (x in 200 until 520) img.pixels[y * 720 + x] = Colors.rgb(50, 120, 220)
        val r = RegionDetector.detect(img).single()
        assertTrue(r.left in 194..206 && r.top in 994..1006 && r.width in 308..332)
    }

    @Test fun redactsBeforeSending() {
        val text = Redactor.describe(screen) + Redactor.clean(" call +44 7700 900123 or a@b.co")
        assertTrue(listOf("hunter2", "me@example.com", "7700", "a@b.co").none { it in text })
        assertTrue("Export" in text)
    }

    @Test fun jsonAndCloudPayloads() {
        val body = Json.parse(CloudClient.body("m", "q \"x\"\n", "ctx")) as Map<*, *>
        assertEquals("m", body["model"])
        assertEquals("hi", CloudClient.reply("{\"choices\":[{\"message\":{\"content\":\" hi \"}}]}"))
    }

    @Test fun historyIsBoundedAndSurvivesDamage() {
        val file = File.createTempFile("history", ".jsonl")
        val store = HistoryStore(file, 3)
        repeat(5) { store.add(HistoryEntry(it.toLong(), HistoryKind.CHESS, "t$it", "line\n\"two\"")) }
        file.appendText("garbage\n")
        assertEquals(listOf("t4", "t3", "t2"), store.all().map { it.title })
        assertEquals("line\n\"two\"", store.all()[0].detail)
        store.clear()
        assertTrue(store.all().isEmpty())
    }
}
