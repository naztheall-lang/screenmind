package com.screenmind.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings.canDrawOverlays
import android.util.DisplayMetrics
import android.view.Display
import com.screenmind.app.R
import com.screenmind.app.capture.CaptureSession
import com.screenmind.app.capture.ProjectionPermissionActivity
import com.screenmind.app.chess.FairPlayVerdict
import com.screenmind.app.overlay.FloatingPanel
import com.screenmind.app.overlay.PanelActions
import com.screenmind.app.settings.Settings
import com.screenmind.app.software.IRect
import com.screenmind.app.ui.AssistantActivity
import com.screenmind.app.ui.ChessActivity
import com.screenmind.app.ui.MainActivity
import com.screenmind.app.ui.SoftwareActivity
import com.screenmind.app.vision.FrameChangeDetector
import com.screenmind.app.vision.PixelImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Foreground service that owns the floating panel and, with consent, the screen capture. */
class SessionService : Service(), PanelActions {
    private val scope = MainScope()
    private val settings by lazy { Settings(this) }
    private var panel: FloatingPanel? = null
    private var capture: CaptureSession? = null
    private var watcher: Job? = null
    private var analysis: Job? = null
    private val changes = FrameChangeDetector()
    private var paused = false
    private var status = "Ready"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen reading", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CAPTURE -> beginCapture(intent)
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_READING -> {
                goForeground(capture != null)
                endCapture("Screen reading stopped")
            }
            else -> {
                goForeground(capture != null)
                showPanel()
            }
        }
        return START_NOT_STICKY
    }

    private fun goForeground(capturing: Boolean) {
        var type = if (capturing) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        if (Build.VERSION.SDK_INT >= 34) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        startForeground(NOTIFICATION, notification(capturing), type)
    }

    private fun notification(capturing: Boolean): Notification {
        fun action(code: Int, label: String, name: String) = Notification.Action.Builder(
            null, label,
            PendingIntent.getService(
                this, code, Intent(this, SessionService::class.java).setAction(name), PendingIntent.FLAG_IMMUTABLE,
            ),
        ).build()
        val builder = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (capturing) "ScreenMind is reading your screen" else "ScreenMind panel is active")
            .setContentIntent(
                PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            .setOngoing(true)
            .addAction(action(1, "Show panel", ACTION_SHOW))
        if (capturing) builder.addAction(action(2, "Stop reading", ACTION_STOP_READING))
        return builder.addAction(action(3, "Close", ACTION_STOP)).build()
    }

    private fun showPanel() {
        if (!canDrawOverlays(this)) {
            panel?.remove()
            panel = null
            return
        }
        val p = panel ?: FloatingPanel(this, this).also {
            it.size = settings.panelSize
            panel = it
        }
        if (!p.show()) panel = null
        render()
    }

    private fun render(result: String? = null) {
        panel?.render(status, result, capture != null, paused, settings.chessMode)
    }

    private fun metrics(): DisplayMetrics {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getRealMetrics(m)
        return m
    }

    private fun beginCapture(intent: Intent) {
        // The foreground service must be running before the projection is obtained.
        goForeground(true)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        capture?.close()
        capture = null
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
                ?: throw IllegalStateException("No projection")
            val m = metrics()
            var created: CaptureSession? = null
            created = CaptureSession(
                projection, m.widthPixels, m.heightPixels, m.densityDpi, settings.performance.captureWidth,
            ) { if (capture === created) endCapture("Android ended screen reading") }
            capture = created
        } catch (e: SecurityException) {
            endCapture("Android refused screen capture. Try again.")
            showPanel()
            return
        } catch (e: IllegalStateException) {
            endCapture("Screen capture could not start.")
            showPanel()
            return
        }
        paused = false
        changes.reset()
        status = "Reading screen"
        showPanel()
        watch()
    }

    /** Optional automatic analysis: only when the picture changes, never faster than the profile allows. */
    private fun watch() {
        watcher?.cancel()
        watcher = scope.launch {
            while (isActive) {
                delay(settings.performance.frameIntervalMs)
                if (panel != null && !canDrawOverlays(this@SessionService)) showPanel()
                if (paused || !settings.autoAnalyse || analysis?.isActive == true) continue
                val frame = capture?.grab() ?: continue
                val area = panel?.bounds()
                if (area != null) blank(frame, area)
                if (changes.hasChanged(frame)) run(frame, area, false)
            }
        }
    }

    /** Paints out the panel so its own text changes do not trigger analysis. */
    private fun blank(frame: PixelImage, area: IRect) {
        val m = metrics()
        val left = (area.left * frame.width / m.widthPixels).coerceIn(0, frame.width)
        val right = (area.right * frame.width / m.widthPixels).coerceIn(0, frame.width)
        val top = (area.top * frame.height / m.heightPixels).coerceIn(0, frame.height)
        val bottom = (area.bottom * frame.height / m.heightPixels).coerceIn(0, frame.height)
        for (y in top until bottom) for (x in left until right) frame.pixels[y * frame.width + x] = 0
    }

    private suspend fun run(frame: PixelImage?, exclude: IRect?, manual: Boolean) {
        status = "Analysing…"
        render()
        val m = metrics()
        val text = if (settings.chessMode) {
            if (frame == null) {
                "Chess mode needs screen reading. Tap Start."
            } else {
                val snapshot = Analyzer.chess(this, frame, manual)
                val verdict = snapshot?.verdict
                when {
                    snapshot == null -> "No chessboard found."
                    verdict is FairPlayVerdict.Blocked -> "Possible live game. ${verdict.reason} Engine analysis is locked."
                    else -> snapshot.report() + " Moves are never shown here; use Review after the game."
                }
            }
        } else {
            Analyzer.software(this, frame, m.widthPixels, m.heightPixels, exclude, manual)
        }
        status = if (paused) "Paused" else if (capture != null) "Reading screen" else "Ready"
        render(text)
    }

    override fun analyse() {
        analysis?.cancel()
        analysis = scope.launch {
            var frame: PixelImage? = null
            if (!paused && capture != null) {
                // Hide the panel briefly so it is not part of the picture.
                panel?.hideFor(2000)
                delay(350)
                frame = capture?.grab()
                panel?.unhide()
            }
            run(frame, null, true)
        }
    }

    override fun toggleReading() {
        if (capture != null) {
            endCapture("Screen reading stopped")
        } else {
            startActivity(Intent(this, ProjectionPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun endCapture(message: String) {
        watcher?.cancel()
        analysis?.cancel()
        capture?.close()
        capture = null
        paused = false
        status = message
        goForeground(false)
        render()
    }

    override fun togglePause() {
        paused = !paused
        if (paused) analysis?.cancel()
        changes.reset()
        status = if (paused) "Paused" else if (capture != null) "Reading screen" else "Ready"
        render()
    }

    private fun open(activity: Class<*>) {
        startActivity(Intent(this, activity).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    override fun openAssistant() {
        analysis?.cancel()
        analysis = scope.launch {
            // Read the current app first so the assistant has fresh context.
            panel?.hideFor(3000)
            delay(350)
            val frame = if (paused) null else capture?.grab()
            val m = metrics()
            if (frame != null || ScreenAccessibilityService.instance != null) {
                Analyzer.software(this@SessionService, frame, m.widthPixels, m.heightPixels, null, false)
            }
            panel?.unhide()
            open(AssistantActivity::class.java)
        }
    }

    override fun switchMode() {
        analysis?.cancel()
        settings.chessMode = !settings.chessMode
        changes.reset()
        status = if (settings.chessMode) "Chess mode" else "Software mode"
        render("Tap Analyse.")
    }

    override fun review() {
        if (!settings.chessMode) {
            open(SoftwareActivity::class.java)
            return
        }
        val snapshot = Analyzer.lastChess
        val verdict = snapshot?.verdict
        when {
            snapshot == null -> render("Analyse a board first.")
            verdict is FairPlayVerdict.Blocked -> render("Review refused. ${verdict.reason}")
            else -> {
                // Reading stops before any engine analysis, so review cannot run alongside a game.
                endCapture("Screen reading stopped for review")
                startActivity(
                    Intent(this, ChessActivity::class.java).putExtra(ChessActivity.EXTRA_IMPORT, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }
        }
    }

    override fun close() {
        stopSelf()
    }

    fun highlight(area: IRect) {
        panel?.highlight(area)
    }

    val isReading: Boolean get() = capture != null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val m = metrics()
        capture?.resize(m.widthPixels, m.heightPixels)
        changes.reset()
        panel?.let { it.size = it.size }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW || level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            scope.launch { Analyzer.releaseModels() }
        }
    }

    override fun onDestroy() {
        instance = null
        scope.cancel()
        capture?.close()
        capture = null
        panel?.remove()
        panel = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "session"
        private const val NOTIFICATION = 1
        private const val ACTION_SHOW = "show"
        private const val ACTION_CAPTURE = "capture"
        private const val ACTION_STOP = "stop"
        private const val ACTION_STOP_READING = "stopReading"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"

        @Volatile
        var instance: SessionService? = null
            private set

        fun showPanel(context: Context) {
            context.startForegroundService(Intent(context, SessionService::class.java).setAction(ACTION_SHOW))
        }

        fun startCapture(context: Context, code: Int, data: Intent) {
            context.startForegroundService(
                Intent(context, SessionService::class.java).setAction(ACTION_CAPTURE)
                    .putExtra(EXTRA_CODE, code).putExtra(EXTRA_DATA, data)
            )
        }

        fun stopReading(context: Context) {
            if (instance?.isReading == true) {
                context.startService(Intent(context, SessionService::class.java).setAction(ACTION_STOP_READING))
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SessionService::class.java))
        }
    }
}
