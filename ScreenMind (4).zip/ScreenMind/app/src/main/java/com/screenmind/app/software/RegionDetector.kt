package com.screenmind.app.software

import com.screenmind.app.vision.Colors
import com.screenmind.app.vision.PixelImage

/** Finds solid rectangular areas (likely buttons, fields and cards) by flood filling flat colour. */
object RegionDetector {
    fun detect(source: PixelImage): List<IRect> {
        val img = source.scaledToWidth(360)
        val w = img.width
        val h = img.height
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val found = ArrayList<IRect>()
        val k = source.width.toFloat() / w
        for (start in 0 until w * h) {
            if (seen[start]) continue
            val colour = img.pixels[start]
            var n = 0
            var count = 0
            var l = w
            var r = 0
            var t = h
            var b = 0
            seen[start] = true
            stack[n++] = start
            while (n > 0) {
                val i = stack[--n]
                val x = i % w
                val y = i / w
                count++
                l = minOf(l, x)
                r = maxOf(r, x + 1)
                t = minOf(t, y)
                b = maxOf(b, y + 1)
                fun join(j: Int) {
                    if (!seen[j] && Colors.distance(img.pixels[j], colour) <= 6) {
                        seen[j] = true
                        stack[n++] = j
                    }
                }
                if (x > 0) join(i - 1)
                if (x < w - 1) join(i + 1)
                if (y > 0) join(i - w)
                if (y < h - 1) join(i + w)
            }
            val bw = r - l
            val bh = b - t
            // Text and icons punch holes in a button, so require only a mostly filled box.
            if (bw >= 36 && bh in 14..h / 6 && count > bw * bh * 0.55f) {
                found.add(IRect((l * k).toInt(), (t * k).toInt(), (r * k).toInt(), (b * k).toInt()))
                if (found.size >= 120) break
            }
        }
        return found
    }
}
