package com.screenmind.app.chess

/** How the position on screen relates to the one seen before. */
data class TrackedPosition(
    val position: Position,
    /** Moves that connect the previous position to this one (empty for a fresh position). */
    val moves: List<Move>,
    val changed: Boolean,
    val turnKnown: Boolean,
    val note: String,
)

/** Turns a sequence of recognised piece placements into full positions (turn, castling, en passant). */
class BoardTracker {
    var last: Position? = null
        private set
    private var lastTurnKnown = false

    fun reset() {
        last = null
        lastTurnKnown = false
    }

    /**
     * @param board recognised pieces, a1 = 0.
     * @param turnHint side to move inferred from the screen (for example a last-move highlight).
     */
    fun update(board: Array<Piece?>, turnHint: Side? = null): TrackedPosition {
        val placement = Fen.placement(board)
        val previous = last
        if (previous != null) {
            if (previous.placement() == placement) {
                return TrackedPosition(previous, emptyList(), false, lastTurnKnown, "Board unchanged")
            }
            val path = findPath(previous, placement, turnHint)
            if (path != null) {
                var p: Position = path.first
                for (m in path.second) p = p.apply(m)
                last = p
                lastTurnKnown = true
                val text = San.line(path.first, path.second)
                return TrackedPosition(p, path.second, true, true, "Detected $text")
            }
        }
        val isStart = placement == Position.START_FEN.substringBefore(' ')
        val turn = when {
            isStart -> Side.WHITE
            turnHint != null -> turnHint
            else -> checkedSide(board) ?: Side.WHITE
        }
        val known = isStart || turnHint != null || checkedSide(board) != null
        val position = Position(board.copyOf(), turn, Position.possibleCastling(board), null, 0, 1)
        last = position
        lastTurnKnown = known
        val note = if (known) "New position" else "New position — confirm whose turn it is"
        return TrackedPosition(position, emptyList(), true, known, note)
    }

    /** A side in check must be the side to move. */
    private fun checkedSide(board: Array<Piece?>): Side? {
        val p = Position(board, Side.WHITE, 0, null, 0, 1)
        val white = p.isInCheck(Side.WHITE)
        val black = p.isInCheck(Side.BLACK)
        return if (white == black) null else if (white) Side.WHITE else Side.BLACK
    }

    /** Looks for one or two legal moves leading to [target]. */
    private fun findPath(from: Position, target: String, turnHint: Side?): Pair<Position, List<Move>>? {
        val starts = ArrayList<Position>()
        starts.add(from)
        if (!lastTurnKnown) {
            starts.add(Position(from.copyBoard(), from.sideToMove.other, from.castling, null, 0, from.fullmoveNumber))
        }
        for (s in starts) {
            for (m in s.legalMoves()) {
                if (s.apply(m).placement() == target) return s to listOf(m)
            }
        }
        for (s in starts) {
            for (m in s.legalMoves()) {
                val next = s.apply(m)
                for (n in next.legalMoves()) {
                    val end = next.apply(n)
                    if (end.placement() == target && (turnHint == null || end.sideToMove == turnHint)) {
                        return s to listOf(m, n)
                    }
                }
            }
        }
        return null
    }
}
