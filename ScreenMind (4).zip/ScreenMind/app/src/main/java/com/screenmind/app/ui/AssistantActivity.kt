package com.screenmind.app.ui

import android.os.Bundle
import android.widget.LinearLayout
import com.screenmind.app.assistant.Answer
import com.screenmind.app.assistant.CloudClient
import com.screenmind.app.assistant.OfflineAssistant
import com.screenmind.app.assistant.Redactor
import com.screenmind.app.chess.FairPlayGuard
import com.screenmind.app.history.HistoryEntry
import com.screenmind.app.history.HistoryKind
import com.screenmind.app.services.Analyzer
import com.screenmind.app.services.SessionService
import com.screenmind.app.settings.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class AssistantActivity : BaseActivity() {
    private lateinit var log: LinearLayout
    private val settings by lazy { Settings(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = page("Assistant")
        val context = page.note("")
        context.text = Analyzer.lastScreen?.let { "Using the last screen read: ${it.appName ?: "unnamed app"}" }
            ?: "No screen read yet."
        val field = input("Ask about the screen")
        page.add(field)
        page.add(button("Ask", true) { ask(field.text.toString()) })
        if (settings.cloudEnabled) page.add(button("Ask online AI…") { online(field.text.toString()) })
        for (pair in listOf("Explain this interface" to "What does this error mean?", "How do I export?" to "How do I create a new project?")) {
            page.add(row(button(pair.first) { ask(pair.first) }, button(pair.second) { ask(pair.second) }), bottom = 6)
        }
        log = page.add(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }, top = 8)
    }

    private fun post(question: String, answer: String, label: String, answerObject: Answer?) {
        val entry = card(question, "$label\n\n$answer")
        val area = answerObject?.highlight
        if (area != null) {
            entry.addView(button("Show on screen") {
                val service = SessionService.instance ?: return@button toast("Start the floating panel first")
                moveTaskToBack(true)
                window.decorView.postDelayed({ service.highlight(area) }, 700)
            })
        }
        log.addView(entry, 0)
        if (settings.saveHistory) {
            Analyzer.history(this).add(HistoryEntry(System.currentTimeMillis(), HistoryKind.ASSISTANT, question.take(80), answer))
        }
    }

    private fun ask(question: String) {
        if (question.isBlank()) return
        val answer = OfflineAssistant.answer(question, Analyzer.lastScreen)
        post(question, answer.text, "Offline · ${answer.certainty.label}", answer)
    }

    private fun online(question: String) {
        if (question.isBlank()) return toast("Type a question first")
        if (FairPlayGuard.asksForMove(question)) return ask(question)
        val screen = Analyzer.lastScreen
        val description = screen?.let { Redactor.describe(it) } ?: "(no screen read)"
        val sentQuestion = Redactor.clean(question)
        val config = settings.cloud
        confirm(
            "Send this online?",
            "To: ${config.baseUrl}\nQuestion: $sentQuestion\n\n$description\nNo picture is sent. Redaction is automatic but imperfect — check it.",
            "Send",
        ) {
            scope.launch {
                try {
                    val reply = withContext(Dispatchers.IO) { CloudClient.ask(config, sentQuestion, description) }
                    post(question, reply, "Online AI · may be wrong", null)
                } catch (e: IOException) {
                    message("Online request failed", e.message ?: "Network error")
                }
            }
        }
    }
}
