package com.screenmind.app.chess

object MoveGen {
    private val KNIGHT = arrayOf(1 to 2, 2 to 1, 2 to -1, 1 to -2, -1 to -2, -2 to -1, -2 to 1, -1 to 2)
    private val KING = arrayOf(1 to 0, 1 to 1, 0 to 1, -1 to 1, -1 to 0, -1 to -1, 0 to -1, 1 to -1)
    private val STRAIGHT = arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)
    private val DIAGONAL = arrayOf(1 to 1, 1 to -1, -1 to 1, -1 to -1)
    private val PROMOTIONS = arrayOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)

    private fun offset(square: Int, df: Int, dr: Int): Int {
        val f = Squares.file(square) + df
        val r = Squares.rank(square) + dr
        return if (f in 0..7 && r in 0..7) Squares.of(f, r) else -1
    }

    /** Squares holding pieces of [by] that attack [square]. */
    fun attackers(pos: Position, square: Int, by: Side): List<Int> {
        val result = ArrayList<Int>(4)
        val pawnRank = if (by == Side.WHITE) -1 else 1
        for (df in intArrayOf(-1, 1)) {
            val s = offset(square, df, pawnRank)
            if (s >= 0 && pos[s] == Piece(by, PieceType.PAWN)) result.add(s)
        }
        for ((df, dr) in KNIGHT) {
            val s = offset(square, df, dr)
            if (s >= 0 && pos[s] == Piece(by, PieceType.KNIGHT)) result.add(s)
        }
        for ((df, dr) in KING) {
            val s = offset(square, df, dr)
            if (s >= 0 && pos[s] == Piece(by, PieceType.KING)) result.add(s)
        }
        slide(pos, square, by, STRAIGHT, PieceType.ROOK, result)
        slide(pos, square, by, DIAGONAL, PieceType.BISHOP, result)
        return result
    }

    private fun slide(pos: Position, square: Int, by: Side, dirs: Array<Pair<Int, Int>>, type: PieceType, out: MutableList<Int>) {
        for ((df, dr) in dirs) {
            var s = offset(square, df, dr)
            while (s >= 0) {
                val p = pos[s]
                if (p != null) {
                    if (p.side == by && (p.type == type || p.type == PieceType.QUEEN)) out.add(s)
                    break
                }
                s = offset(s, df, dr)
            }
        }
    }

    fun isAttacked(pos: Position, square: Int, by: Side): Boolean = attackers(pos, square, by).isNotEmpty()

    fun legalMoves(pos: Position): List<Move> {
        val side = pos.sideToMove
        return pseudoMoves(pos).filter { !pos.apply(it).isInCheck(side) }
    }

    private fun pseudoMoves(pos: Position): List<Move> {
        val moves = ArrayList<Move>(48)
        val side = pos.sideToMove
        for (from in 0 until 64) {
            val p = pos[from] ?: continue
            if (p.side != side) continue
            when (p.type) {
                PieceType.PAWN -> pawnMoves(pos, from, moves)
                PieceType.KNIGHT -> steps(pos, from, KNIGHT, moves)
                PieceType.BISHOP -> rays(pos, from, DIAGONAL, moves)
                PieceType.ROOK -> rays(pos, from, STRAIGHT, moves)
                PieceType.QUEEN -> {
                    rays(pos, from, STRAIGHT, moves)
                    rays(pos, from, DIAGONAL, moves)
                }
                PieceType.KING -> {
                    steps(pos, from, KING, moves)
                    castles(pos, from, moves)
                }
            }
        }
        return moves
    }

    private fun steps(pos: Position, from: Int, deltas: Array<Pair<Int, Int>>, out: MutableList<Move>) {
        for ((df, dr) in deltas) {
            val to = offset(from, df, dr)
            if (to >= 0 && pos[to]?.side != pos.sideToMove) out.add(Move(from, to))
        }
    }

    private fun rays(pos: Position, from: Int, dirs: Array<Pair<Int, Int>>, out: MutableList<Move>) {
        for ((df, dr) in dirs) {
            var to = offset(from, df, dr)
            while (to >= 0) {
                val p = pos[to]
                if (p == null) {
                    out.add(Move(from, to))
                } else {
                    if (p.side != pos.sideToMove) out.add(Move(from, to))
                    break
                }
                to = offset(to, df, dr)
            }
        }
    }

    private fun pawnMoves(pos: Position, from: Int, out: MutableList<Move>) {
        val side = pos.sideToMove
        val dir = if (side == Side.WHITE) 1 else -1
        val startRank = if (side == Side.WHITE) 1 else 6
        val lastRank = if (side == Side.WHITE) 7 else 0
        fun add(to: Int) {
            if (Squares.rank(to) == lastRank) PROMOTIONS.forEach { out.add(Move(from, to, it)) } else out.add(Move(from, to))
        }
        val one = offset(from, 0, dir)
        if (one >= 0 && pos[one] == null) {
            add(one)
            if (Squares.rank(from) == startRank) {
                val two = offset(from, 0, 2 * dir)
                if (two >= 0 && pos[two] == null) add(two)
            }
        }
        for (df in intArrayOf(-1, 1)) {
            val to = offset(from, df, dir)
            if (to < 0) continue
            val target = pos[to]
            if ((target != null && target.side != side) || (target == null && to == pos.enPassant)) add(to)
        }
    }

    private fun castles(pos: Position, from: Int, out: MutableList<Move>) {
        val side = pos.sideToMove
        val home = if (side == Side.WHITE) 4 else 60
        if (from != home || isAttacked(pos, home, side.other)) return
        val kingBit = if (side == Side.WHITE) Position.WHITE_KINGSIDE else Position.BLACK_KINGSIDE
        val queenBit = if (side == Side.WHITE) Position.WHITE_QUEENSIDE else Position.BLACK_QUEENSIDE
        val rook = Piece(side, PieceType.ROOK)
        if (pos.castling and kingBit != 0 && pos[home + 3] == rook &&
            pos[home + 1] == null && pos[home + 2] == null &&
            !isAttacked(pos, home + 1, side.other) && !isAttacked(pos, home + 2, side.other)
        ) out.add(Move(home, home + 2))
        if (pos.castling and queenBit != 0 && pos[home - 4] == rook &&
            pos[home - 1] == null && pos[home - 2] == null && pos[home - 3] == null &&
            !isAttacked(pos, home - 1, side.other) && !isAttacked(pos, home - 2, side.other)
        ) out.add(Move(home, home - 2))
    }

    fun perft(pos: Position, depth: Int): Long {
        if (depth == 0) return 1
        var n = 0L
        for (m in pos.legalMoves()) n += perft(pos.apply(m), depth - 1)
        return n
    }
}
