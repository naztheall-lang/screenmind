package com.screenmind.app.chess

class FenException(message: String) : IllegalArgumentException(message)

object Fen {
    fun parse(text: String): Position {
        val parts = text.trim().split(Regex("\\s+"))
        if (parts.isEmpty() || parts[0].isEmpty()) throw FenException("The FEN is empty")
        val board = parsePlacement(parts[0])
        val side = when (parts.getOrNull(1) ?: "w") {
            "w" -> Side.WHITE
            "b" -> Side.BLACK
            else -> throw FenException("Side to move must be 'w' or 'b'")
        }
        val rightsText = parts.getOrNull(2) ?: "-"
        var rights = 0
        if (rightsText != "-") {
            for (c in rightsText) {
                rights = rights or when (c) {
                    'K' -> Position.WHITE_KINGSIDE
                    'Q' -> Position.WHITE_QUEENSIDE
                    'k' -> Position.BLACK_KINGSIDE
                    'q' -> Position.BLACK_QUEENSIDE
                    else -> throw FenException("Unknown castling flag '$c'")
                }
            }
        }
        val epText = parts.getOrNull(3) ?: "-"
        val ep = if (epText == "-") null else Squares.parse(epText) ?: throw FenException("Bad en passant square '$epText'")
        val half = parts.getOrNull(4)?.toIntOrNull() ?: 0
        val full = parts.getOrNull(5)?.toIntOrNull() ?: 1
        return Position(board, side, rights, ep, half.coerceAtLeast(0), full.coerceAtLeast(1))
    }

    fun parsePlacement(text: String): Array<Piece?> {
        val ranks = text.split("/")
        if (ranks.size != 8) throw FenException("Expected 8 ranks, found ${ranks.size}")
        val board = arrayOfNulls<Piece>(64)
        for ((i, row) in ranks.withIndex()) {
            val rank = 7 - i
            var file = 0
            for (c in row) {
                if (c in '1'..'8') {
                    file += c - '0'
                } else {
                    val piece = Piece.fromFen(c) ?: throw FenException("Unknown piece '$c'")
                    if (file > 7) throw FenException("Rank ${rank + 1} is too long")
                    board[Squares.of(file, rank)] = piece
                    file++
                }
            }
            if (file != 8) throw FenException("Rank ${rank + 1} does not have 8 squares")
        }
        return board
    }

    fun placement(board: Array<Piece?>): String = buildString {
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val p = board[Squares.of(file, rank)]
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) append(empty)
                    empty = 0
                    append(p.fenChar)
                }
            }
            if (empty > 0) append(empty)
            if (rank > 0) append('/')
        }
    }

    fun write(p: Position): String {
        val rights = buildString {
            if (p.castling and Position.WHITE_KINGSIDE != 0) append('K')
            if (p.castling and Position.WHITE_QUEENSIDE != 0) append('Q')
            if (p.castling and Position.BLACK_KINGSIDE != 0) append('k')
            if (p.castling and Position.BLACK_QUEENSIDE != 0) append('q')
        }.ifEmpty { "-" }
        val ep = p.enPassant?.let { Squares.name(it) } ?: "-"
        return "${p.placement()} ${if (p.sideToMove == Side.WHITE) "w" else "b"} $rights $ep ${p.halfmoveClock} ${p.fullmoveNumber}"
    }
}
