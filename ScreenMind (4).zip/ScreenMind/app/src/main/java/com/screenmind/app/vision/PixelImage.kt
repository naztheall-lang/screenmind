package com.screenmind.app.vision

/** An ARGB image independent of Android, so all vision code can be unit tested. */
class PixelImage(val width: Int, val height: Int, val pixels: IntArray = IntArray(width * height)) {
    init {
        require(width > 0 && height > 0 && pixels.size >= width * height)
    }

    operator fun get(x: Int, y: Int): Int = pixels[y * width + x]

    fun luma(x: Int, y: Int): Int = Colors.luma(pixels[y * width + x])

    /** Box-filtered downscale; returns this image if it is already small enough. */
    fun scaledToWidth(target: Int): PixelImage {
        if (width <= target) return this
        val h = maxOf(1, height * target / width)
        val out = PixelImage(target, h)
        for (y in 0 until h) {
            val y0 = y * height / h
            val y1 = maxOf(y0 + 1, (y + 1) * height / h)
            for (x in 0 until target) {
                val x0 = x * width / target
                val x1 = maxOf(x0 + 1, (x + 1) * width / target)
                var r = 0
                var g = 0
                var b = 0
                for (yy in y0 until y1) for (xx in x0 until x1) {
                    val p = pixels[yy * width + xx]
                    r += p shr 16 and 255
                    g += p shr 8 and 255
                    b += p and 255
                }
                val n = (y1 - y0) * (x1 - x0)
                out.pixels[y * target + x] = Colors.rgb(r / n, g / n, b / n)
            }
        }
        return out
    }
}

object Colors {
    fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b
    fun luma(c: Int): Int = ((c shr 16 and 255) * 77 + (c shr 8 and 255) * 150 + (c and 255) * 29) shr 8
    fun distance(a: Int, b: Int): Int = maxOf(
        kotlin.math.abs((a shr 16 and 255) - (b shr 16 and 255)),
        kotlin.math.abs((a shr 8 and 255) - (b shr 8 and 255)),
        kotlin.math.abs((a and 255) - (b and 255)),
    )

    fun median(colors: IntArray, count: Int = colors.size): Int {
        val channel = IntArray(count)
        fun mid(shift: Int): Int {
            for (i in 0 until count) channel[i] = colors[i] shr shift and 255
            channel.sort()
            return channel[count / 2]
        }
        return rgb(mid(16), mid(8), mid(0))
    }
}

/** Cheap test for "did the screen change?" so expensive analysis can be skipped. */
class FrameChangeDetector(private val threshold: Float = 0.008f) {
    private var previous: IntArray? = null

    fun reset() {
        previous = null
    }

    fun hasChanged(image: PixelImage): Boolean {
        val cols = 24
        val rows = 48
        val now = IntArray(cols * rows)
        for (r in 0 until rows) for (c in 0 until cols) {
            var sum = 0
            for (j in 0 until 3) for (i in 0 until 3) {
                val x = (c * 3 + i) * image.width / (cols * 3)
                val y = (r * 3 + j) * image.height / (rows * 3)
                sum += image.luma(x, y)
            }
            now[r * cols + c] = sum / 9
        }
        val before = previous
        val changed = before == null || now.indices.count { kotlin.math.abs(now[it] - before[it]) > 8 } > now.size * threshold
        if (changed) previous = now
        return changed
    }
}
