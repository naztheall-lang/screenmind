package com.screenmind.app.capture

import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import com.screenmind.app.vision.PixelImage
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * One MediaProjection session. Only the newest frame is held, and pixels are copied only when
 * [grab] is called. All image access happens on one background thread.
 */
class CaptureSession(
    private val projection: MediaProjection,
    screenWidth: Int,
    screenHeight: Int,
    private val densityDpi: Int,
    private val targetWidth: Int,
    onStopped: () -> Unit,
) {
    private val thread = HandlerThread("capture").apply { start() }
    private val handler = Handler(thread.looper)
    private var reader: ImageReader
    private var display: VirtualDisplay? = null
    private var held: Image? = null
    private var closed = false

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            Handler(android.os.Looper.getMainLooper()).post { onStopped() }
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            resize(width, height)
        }
    }

    init {
        val (w, h) = scaled(screenWidth, screenHeight)
        reader = newReader(w, h)
        // Android 14 requires the callback to be registered before the display is created.
        projection.registerCallback(callback, handler)
        display = projection.createVirtualDisplay(
            "ScreenMind", w, h, densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler,
        )
    }

    private fun scaled(width: Int, height: Int): Pair<Int, Int> {
        // Limit the short side so landscape costs the same as portrait.
        val short = minOf(width, height).coerceAtLeast(1)
        val k = minOf(1f, targetWidth.toFloat() / short)
        return maxOf(2, (width * k).toInt()) to maxOf(2, (height * k).toInt())
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3).apply {
            setOnImageAvailableListener({ source ->
                if (!closed && source === reader) {
                    val next = source.acquireLatestImage()
                    if (next != null) {
                        held?.close()
                        held = next
                    }
                }
            }, handler)
        }

    fun resize(width: Int, height: Int) {
        handler.post {
            if (closed) return@post
            val (w, h) = scaled(width, height)
            if (w == reader.width && h == reader.height) return@post
            val old = reader
            held?.close()
            held = null
            reader = newReader(w, h)
            display?.resize(w, h, densityDpi)
            display?.setSurface(reader.surface)
            old.close()
        }
    }

    suspend fun grab(): PixelImage? = suspendCancellableCoroutine { continuation ->
        val posted = handler.post {
            val image = if (closed) null else held
            val result = image?.let { copy(it) }
            if (continuation.isActive) continuation.resume(result)
        }
        if (!posted && continuation.isActive) continuation.resume(null)
    }

    private fun copy(image: Image): PixelImage {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val out = PixelImage(image.width, image.height)
        val row = ByteArray(image.width * 4)
        for (y in 0 until image.height) {
            buffer.position(y * plane.rowStride)
            buffer.get(row, 0, row.size)
            for (x in 0 until image.width) {
                val i = x * 4
                out.pixels[y * image.width + x] = (255 shl 24) or ((row[i].toInt() and 255) shl 16) or
                    ((row[i + 1].toInt() and 255) shl 8) or (row[i + 2].toInt() and 255)
            }
        }
        return out
    }

    fun close() {
        handler.post {
            if (closed) return@post
            closed = true
            display?.release()
            held?.close()
            held = null
            reader.close()
            projection.unregisterCallback(callback)
            projection.stop()
            thread.quitSafely()
        }
    }
}
