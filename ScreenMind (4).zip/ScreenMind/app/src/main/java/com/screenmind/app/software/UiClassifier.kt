package com.screenmind.app.software

/**
 * Combines the accessibility tree (reliable types), OCR (text) and image regions (shape)
 * into one list of elements, each with a confidence that reflects how it was identified.
 */
object UiClassifier {
    fun build(
        appName: String?,
        packageName: String?,
        width: Int,
        height: Int,
        roots: List<RawNode>,
        ocr: List<OcrLine>,
        regions: List<IRect> = emptyList(),
        usedOcr: Boolean = true,
    ): ScreenModel {
        val elements = ArrayList<UiElement>()
        for (root in roots) walk(root, width, height, false, elements)
        val fromTree = elements.size
        for (line in ocr) {
            val text = line.text.trim()
            if (text.isEmpty()) continue
            val duplicate = elements.take(fromTree).any {
                it.bounds.overlap(line.bounds) > line.bounds.area / 2 &&
                    (it.label.contains(text, true) || text.contains(it.label, true))
            }
            if (!duplicate) elements.add(fromOcr(line, ocr, regions, width, height))
        }
        // An error is an error however it was found.
        val marked = elements.map {
            if (it.type != ElementType.TEXT_FIELD && Knowledge.looksLikeError(it.label)) it.copy(type = ElementType.ERROR) else it
        }
        return ScreenModel(
            appName, packageName, width, height,
            marked.distinctBy { it.type to (it.label to it.bounds) }
                .sortedWith(compareBy({ it.bounds.top }, { it.bounds.left })),
            roots.isNotEmpty(), usedOcr,
        )
    }

    private fun textOf(n: RawNode): String {
        if (n.password) return ""
        return listOf(n.text, n.description, n.hint).firstOrNull { it.isNotBlank() }?.trim() ?: ""
    }

    private fun descendantText(n: RawNode, depth: Int = 0): String {
        val own = textOf(n)
        if (own.isNotEmpty() || depth > 3) return own
        return n.children.asSequence().map { descendantText(it, depth + 1) }.filter { it.isNotEmpty() }.take(2).joinToString(" · ")
    }

    private fun idName(viewId: String) = viewId.substringAfterLast('/').replace('_', ' ').trim()

    private fun walk(n: RawNode, w: Int, h: Int, inList: Boolean, out: MutableList<UiElement>) {
        if (out.size >= 400) return
        val cls = n.className.substringAfterLast('.')
        val id = n.viewId.substringAfterLast('/').lowercase()
        val isList = cls.contains("RecyclerView") || cls.contains("ListView")
        val b = n.bounds
        val visible = b.width > 2 && b.height > 2 && b.right > 0 && b.bottom > 0 && b.left < w && b.top < h
        if (visible) {
            if (cls.contains("Dialog") || (cls.contains("AlertDialog"))) {
                out.add(UiElement(ElementType.DIALOG, "Dialogue", b, 0.9f, Source.ACCESSIBILITY))
            }
            val type = when {
                n.editable || cls.contains("EditText") -> ElementType.TEXT_FIELD
                n.checkable || cls.contains("Switch") || cls.contains("CheckBox") || cls.contains("RadioButton") -> ElementType.TOGGLE
                cls.contains("Tab") && !cls.contains("Table") -> ElementType.TAB
                id.contains("tab") && n.clickable -> ElementType.TAB
                (id.contains("bottom_nav") || id.contains("navigation_bar")) && n.clickable -> ElementType.NAV_BAR
                n.clickable && b.top > h * 0.88 && b.width < w / 2 -> ElementType.NAV_BAR
                n.clickable && (cls.contains("MenuItem") || id.contains("menu_item")) -> ElementType.MENU
                n.clickable && b.top < h * 0.13 && b.width < w / 3 -> ElementType.TOOLBAR
                cls.contains("Button") && cls.contains("Image") -> ElementType.ICON
                cls.contains("Button") -> ElementType.BUTTON
                n.clickable && inList -> ElementType.LIST_ITEM
                n.clickable && cls.contains("Image") -> ElementType.ICON
                n.clickable -> ElementType.BUTTON
                textOf(n).isNotEmpty() -> ElementType.TEXT
                else -> null
            }
            if (type != null) {
                var label = if (n.clickable || type == ElementType.TOGGLE) descendantText(n) else textOf(n)
                var confidence = 0.95f
                if (n.password) label = "Password field"
                if (label.isEmpty() && id.isNotEmpty()) {
                    label = idName(n.viewId)
                    confidence = 0.6f
                }
                if (label.isEmpty()) {
                    label = "Unlabelled ${type.label.lowercase()}"
                    confidence = 0.4f
                }
                out.add(UiElement(type, label, b, confidence, Source.ACCESSIBILITY, n.enabled, if (n.checkable) n.checked else null))
                // The clickable parent already carries the text of plain children.
                if (n.clickable && n.children.all { !it.clickable && !it.checkable && !it.editable }) return
            }
        }
        for (c in n.children) walk(c, w, h, inList || isList, out)
    }

    private val ACTIONS = setOf(
        "ok", "cancel", "yes", "no", "save", "done", "next", "back", "skip", "continue", "submit", "send", "share",
        "export", "import", "delete", "remove", "allow", "deny", "retry", "try again", "close", "sign in", "log in",
        "sign up", "register", "apply", "confirm", "accept", "decline", "install", "update", "open", "download",
        "upload", "create", "add", "edit", "search", "start", "stop", "got it", "not now", "later", "agree", "buy", "play",
    )

    private fun fromOcr(line: OcrLine, all: List<OcrLine>, regions: List<IRect>, w: Int, h: Int): UiElement {
        val text = line.text.trim()
        val b = line.bounds
        val region = regions.filter { it.contains(b.centreX, b.centreY) && it.height < b.height * 5 && it.width < w * 0.96 }
            .minByOrNull { it.area }
        val rowPeers = all.count { it !== line && kotlin.math.abs(it.bounds.centreY - b.centreY) < b.height && it.text.length < 20 }
        val action = text.lowercase().trim('.', '…', '>', ' ') in ACTIONS
        val (type, confidence) = when {
            b.centreY > h * 0.87 && rowPeers >= 2 && text.length < 20 -> ElementType.NAV_BAR to 0.65f
            b.centreY < h * 0.28 && rowPeers >= 2 && text.length < 18 && b.centreY > h * 0.07 -> ElementType.TAB to 0.5f
            action && region != null -> ElementType.BUTTON to 0.75f
            action -> ElementType.BUTTON to 0.55f
            region != null && text.length < 30 && region.width < w * 0.6 -> ElementType.BUTTON to 0.45f
            region != null && Regex("^(enter|type|search|email|password|username)\\b.*", RegexOption.IGNORE_CASE).matches(text) ->
                ElementType.TEXT_FIELD to 0.55f
            b.centreY < h * 0.12 && b.centreX > w * 0.75 && text.length < 16 -> ElementType.TOOLBAR to 0.45f
            else -> ElementType.TEXT to 0.8f
        }
        return UiElement(type, text, if (type == ElementType.BUTTON && region != null) region else b, confidence, Source.OCR)
    }
}
