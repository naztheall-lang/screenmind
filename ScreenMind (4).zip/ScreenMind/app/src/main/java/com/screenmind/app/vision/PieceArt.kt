package com.screenmind.app.vision

import com.screenmind.app.chess.PieceType

/** ScreenMind's own flat piece shapes, as polygons in a 100 x 100 box (x,y pairs). */
object PieceArt {
    fun outline(type: PieceType): List<FloatArray> = when (type) {
        PieceType.PAWN -> listOf(circle(50f, 36f, 13f), poly(41, 46, 59, 46, 67, 76, 33, 76), base(30, 70))
        PieceType.ROOK -> listOf(
            poly(27, 20, 37, 20, 37, 28, 45, 28, 45, 20, 55, 20, 55, 28, 63, 28, 63, 20, 73, 20, 73, 40, 65, 44, 68, 76, 32, 76, 35, 44, 27, 40),
            base(24, 76),
        )
        PieceType.KNIGHT -> listOf(
            poly(32, 76, 36, 58, 48, 48, 30, 54, 20, 46, 26, 36, 42, 22, 46, 11, 54, 19, 68, 28, 75, 46, 72, 76),
            base(25, 77),
        )
        PieceType.BISHOP -> listOf(
            circle(50f, 14f, 6f), poly(50, 19, 63, 33, 67, 46, 61, 58, 39, 58, 33, 46, 37, 33),
            poly(41, 57, 59, 57, 65, 76, 35, 76), base(24, 76),
        )
        PieceType.QUEEN -> listOf(
            poly(30, 76, 16, 28, 33, 46, 34, 17, 45, 43, 50, 11, 55, 43, 66, 17, 67, 46, 84, 28, 70, 76), base(25, 75),
        )
        PieceType.KING -> listOf(
            poly(45, 6, 55, 6, 55, 13, 63, 13, 63, 22, 55, 22, 55, 32, 45, 32, 45, 22, 37, 22, 37, 13, 45, 13),
            poly(34, 76, 18, 48, 24, 34, 38, 30, 50, 40, 62, 30, 76, 34, 82, 48, 66, 76), base(27, 73),
        )
    }

    private fun poly(vararg v: Int) = FloatArray(v.size) { v[it].toFloat() }
    private fun base(l: Int, r: Int) = poly(l + 4, 75, r - 4, 75, r, 90, l, 90)
    private fun circle(cx: Float, cy: Float, r: Float) = FloatArray(40) {
        val a = (it / 2) * Math.PI * 2 / 20
        if (it % 2 == 0) cx + r * kotlin.math.cos(a).toFloat() else cy + r * kotlin.math.sin(a).toFloat()
    }
}
