package com.screenmind.app.chess

/** An immutable chess position. [board] must never be mutated after construction. */
class Position(
    private val board: Array<Piece?>,
    val sideToMove: Side,
    val castling: Int,
    val enPassant: Int?,
    val halfmoveClock: Int,
    val fullmoveNumber: Int,
) {
    init {
        require(board.size == 64) { "A board has 64 squares" }
    }

    operator fun get(square: Int): Piece? = board[square]

    fun copyBoard(): Array<Piece?> = board.copyOf()

    fun kingSquare(side: Side): Int? {
        for (i in 0 until 64) {
            val p = board[i]
            if (p != null && p.type == PieceType.KING && p.side == side) return i
        }
        return null
    }

    fun isInCheck(side: Side = sideToMove): Boolean {
        val k = kingSquare(side) ?: return false
        return MoveGen.isAttacked(this, k, side.other)
    }

    fun legalMoves(): List<Move> = MoveGen.legalMoves(this)

    fun findLegal(uci: String): Move? = legalMoves().firstOrNull { it.uci() == uci.lowercase() }

    /** Applies a pseudo-legal move and returns the resulting position. */
    fun apply(move: Move): Position {
        val b = board.copyOf()
        val piece = b[move.from] ?: error("No piece on ${Squares.name(move.from)}")
        val isPawn = piece.type == PieceType.PAWN
        var capture = b[move.to] != null

        // En passant removes the pawn beside the destination.
        if (isPawn && move.to == enPassant && Squares.file(move.from) != Squares.file(move.to) && b[move.to] == null) {
            b[Squares.of(Squares.file(move.to), Squares.rank(move.from))] = null
            capture = true
        }
        b[move.to] = if (move.promotion != null) Piece(piece.side, move.promotion) else piece
        b[move.from] = null

        // Castling also moves the rook.
        if (piece.type == PieceType.KING && kotlin.math.abs(move.to - move.from) == 2) {
            val rank = Squares.rank(move.from)
            val kingside = move.to > move.from
            val rookFrom = Squares.of(if (kingside) 7 else 0, rank)
            val rookTo = Squares.of(if (kingside) 5 else 3, rank)
            b[rookTo] = b[rookFrom]
            b[rookFrom] = null
        }

        var rights = castling
        for (sq in intArrayOf(move.from, move.to)) {
            rights = when (sq) {
                4 -> rights and (WHITE_KINGSIDE or WHITE_QUEENSIDE).inv()
                60 -> rights and (BLACK_KINGSIDE or BLACK_QUEENSIDE).inv()
                7 -> rights and WHITE_KINGSIDE.inv()
                0 -> rights and WHITE_QUEENSIDE.inv()
                63 -> rights and BLACK_KINGSIDE.inv()
                56 -> rights and BLACK_QUEENSIDE.inv()
                else -> rights
            }
        }

        val ep = if (isPawn && kotlin.math.abs(move.to - move.from) == 16) (move.to + move.from) / 2 else null
        return Position(
            b,
            sideToMove.other,
            rights,
            ep,
            if (isPawn || capture) 0 else halfmoveClock + 1,
            if (sideToMove == Side.BLACK) fullmoveNumber + 1 else fullmoveNumber,
        )
    }

    fun placement(): String = Fen.placement(board)

    fun toFen(): String = Fen.write(this)

    /** Identity used for threefold repetition (clocks excluded). */
    fun repetitionKey(): String {
        // The en passant square only matters if a capture is really possible.
        val ep = enPassant?.takeIf { target -> legalMoves().any { it.to == target && board[it.from]?.type == PieceType.PAWN } }
        return "${placement()} $sideToMove $castling $ep"
    }

    companion object {
        const val WHITE_KINGSIDE = 1
        const val WHITE_QUEENSIDE = 2
        const val BLACK_KINGSIDE = 4
        const val BLACK_QUEENSIDE = 8
        const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun start(): Position = Fen.parse(START_FEN)

        /** Castling rights that the piece placement still allows. */
        fun possibleCastling(board: Array<Piece?>): Int {
            var rights = 0
            fun has(sq: Int, side: Side, type: PieceType) = board[sq] == Piece(side, type)
            if (has(4, Side.WHITE, PieceType.KING)) {
                if (has(7, Side.WHITE, PieceType.ROOK)) rights = rights or WHITE_KINGSIDE
                if (has(0, Side.WHITE, PieceType.ROOK)) rights = rights or WHITE_QUEENSIDE
            }
            if (has(60, Side.BLACK, PieceType.KING)) {
                if (has(63, Side.BLACK, PieceType.ROOK)) rights = rights or BLACK_KINGSIDE
                if (has(56, Side.BLACK, PieceType.ROOK)) rights = rights or BLACK_QUEENSIDE
            }
            return rights
        }
    }
}
