package com.screenmind.app.engine

import com.screenmind.app.chess.Move
import com.screenmind.app.chess.Position

object UciParser {
    /** Parses an "info ... multipv N score ... pv ..." line; other lines return null. */
    fun parseInfo(line: String, root: Position): CandidateLine? {
        if (!line.startsWith("info ")) return null
        val t = line.trim().split(Regex("\\s+"))
        var depth = 0
        var multiPv = 1
        var score: Score? = null
        var bounded = false
        var pv: List<String> = emptyList()
        var i = 1
        while (i < t.size) {
            when (t[i]) {
                "depth" -> depth = t.getOrNull(++i)?.toIntOrNull() ?: 0
                "multipv" -> multiPv = t.getOrNull(++i)?.toIntOrNull() ?: 1
                "score" -> {
                    val kind = t.getOrNull(++i)
                    val n = t.getOrNull(++i)?.toIntOrNull()
                    if (n != null) score = if (kind == "mate") Score(mateIn = n) else Score(centipawns = n)
                }
                "lowerbound", "upperbound" -> bounded = true
                "pv" -> {
                    pv = t.subList(i + 1, t.size)
                    i = t.size
                }
                "string" -> return null
            }
            i++
        }
        val s = score ?: return null
        if (bounded || pv.isEmpty()) return null
        val moves = ArrayList<Move>()
        var pos = root
        for (uci in pv.take(12)) {
            val m = pos.findLegal(uci) ?: break
            moves.add(m)
            pos = pos.apply(m)
        }
        if (moves.isEmpty()) return null
        return CandidateLine(multiPv, s, depth, moves)
    }
}
