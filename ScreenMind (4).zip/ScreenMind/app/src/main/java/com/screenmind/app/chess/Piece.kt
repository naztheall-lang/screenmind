package com.screenmind.app.chess

enum class Side {
    WHITE, BLACK;

    val other: Side get() = if (this == WHITE) BLACK else WHITE
    val title: String get() = if (this == WHITE) "White" else "Black"
}

enum class PieceType(val letter: Char, val value: Int, val word: String) {
    PAWN('p', 100, "pawn"),
    KNIGHT('n', 320, "knight"),
    BISHOP('b', 330, "bishop"),
    ROOK('r', 500, "rook"),
    QUEEN('q', 900, "queen"),
    KING('k', 0, "king");

    companion object {
        fun fromLetter(c: Char): PieceType? = values().firstOrNull { it.letter == c.lowercaseChar() }
    }
}

data class Piece(val side: Side, val type: PieceType) {
    val fenChar: Char get() = if (side == Side.WHITE) type.letter.uppercaseChar() else type.letter

    companion object {
        fun fromFen(c: Char): Piece? {
            val type = PieceType.fromLetter(c) ?: return null
            return Piece(if (c.isUpperCase()) Side.WHITE else Side.BLACK, type)
        }
    }
}

/** Squares are 0..63 with a1 = 0, h1 = 7 and h8 = 63. */
object Squares {
    fun of(file: Int, rank: Int): Int = rank * 8 + file
    fun file(square: Int): Int = square % 8
    fun rank(square: Int): Int = square / 8
    fun name(square: Int): String = "${'a' + file(square)}${'1' + rank(square)}"

    fun parse(text: String): Int? {
        if (text.length != 2) return null
        val f = text[0] - 'a'
        val r = text[1] - '1'
        return if (f in 0..7 && r in 0..7) of(f, r) else null
    }
}

data class Move(val from: Int, val to: Int, val promotion: PieceType? = null) {
    fun uci(): String = Squares.name(from) + Squares.name(to) + (promotion?.letter?.toString() ?: "")
}
