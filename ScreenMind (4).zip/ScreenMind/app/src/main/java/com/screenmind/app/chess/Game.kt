package com.screenmind.app.chess

enum class GameStatus(val message: String) {
    ONGOING("Game in progress"),
    CHECKMATE("Checkmate"),
    STALEMATE("Draw by stalemate"),
    INSUFFICIENT_MATERIAL("Draw: insufficient material"),
    FIFTY_MOVES("Draw: fifty-move rule"),
    REPETITION("Draw: threefold repetition");

    val isOver: Boolean get() = this != ONGOING
}

/** A move list from a starting position, with undo/redo style navigation. */
class Game(val start: Position = Position.start()) {
    private val positions = ArrayList<Position>().apply { add(start) }
    private val played = ArrayList<Move>()

    var ply = 0
        private set

    val current: Position get() = positions[ply]
    val moves: List<Move> get() = played
    val movesToCurrent: List<Move> get() = played.subList(0, ply).toList()
    val lastMove: Move? get() = if (ply > 0) played[ply - 1] else null
    val length: Int get() = played.size

    fun positionAt(index: Int): Position = positions[index]

    /** Plays a legal move from the current ply, discarding any later moves. */
    fun play(move: Move): Boolean {
        if (move !in current.legalMoves()) return false
        while (played.size > ply) {
            played.removeAt(played.size - 1)
            positions.removeAt(positions.size - 1)
        }
        positions.add(current.apply(move))
        played.add(move)
        ply++
        return true
    }

    fun goTo(index: Int) {
        ply = index.coerceIn(0, played.size)
    }

    fun sanList(): List<String> = played.indices.map { San.write(positions[it], played[it]) }

    fun status(): GameStatus {
        val key = current.repetitionKey()
        val repeats = (0..ply).count { positions[it].placement() == current.placement() && positions[it].repetitionKey() == key }
        return statusOf(current, repeats)
    }

    companion object {
        fun statusOf(p: Position, repetitions: Int = 1): GameStatus {
            if (p.legalMoves().isEmpty()) return if (p.isInCheck()) GameStatus.CHECKMATE else GameStatus.STALEMATE
            if (insufficientMaterial(p)) return GameStatus.INSUFFICIENT_MATERIAL
            if (p.halfmoveClock >= 100) return GameStatus.FIFTY_MOVES
            if (repetitions >= 3) return GameStatus.REPETITION
            return GameStatus.ONGOING
        }

        fun insufficientMaterial(p: Position): Boolean {
            val minors = ArrayList<Pair<PieceType, Int>>()
            for (i in 0 until 64) {
                val piece = p[i] ?: continue
                when (piece.type) {
                    PieceType.KING -> {}
                    PieceType.KNIGHT, PieceType.BISHOP -> minors.add(piece.type to (Squares.file(i) + Squares.rank(i)) % 2)
                    else -> return false
                }
            }
            if (minors.size <= 1) return true
            // Any number of bishops all on one colour cannot mate.
            return minors.all { it.first == PieceType.BISHOP && it.second == minors[0].second }
        }
    }
}
