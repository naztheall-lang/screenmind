package com.screenmind.app.engine

import com.screenmind.app.chess.Game
import com.screenmind.app.chess.Move
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.Side
import com.screenmind.app.chess.Squares
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

/**
 * A small alpha-beta searcher used only when the Stockfish binary is unavailable.
 * It is far weaker than Stockfish and the UI labels it as such.
 */
class BuiltinEngine : ChessEngine {
    override val name = "Basic built-in engine (weak)"

    private class OutOfTime : RuntimeException()

    private class Search(val context: CoroutineContext, val deadline: Long) {
        var nodes = 0
        fun tick() {
            if (++nodes and 255 == 0) {
                context.ensureActive()
                if (System.nanoTime() > deadline) throw OutOfTime()
            }
        }
    }

    override suspend fun analyse(
        request: AnalysisRequest,
        settings: EngineSettings,
        onUpdate: (AnalysisResult) -> Unit,
    ): AnalysisResult = withContext(Dispatchers.Default) {
        val root = request.position
        var moves = order(root, root.legalMoves().filter { request.searchMoves.isEmpty() || it in request.searchMoves })
        if (moves.isEmpty()) return@withContext AnalysisResult(emptyList(), 0, name)
        val started = System.nanoTime()
        val deadline = started + settings.moveTimeMs * 1_000_000
        var result: AnalysisResult? = null
        val maxDepth = settings.depth.coerceIn(1, 6)
        for (depth in 1..maxDepth) {
            // Depth 1 always completes so there is always an answer.
            val search = Search(coroutineContext, if (depth == 1) Long.MAX_VALUE else deadline)
            val scored = ArrayList<Pair<Int, List<Move>>>()
            try {
                for (m in moves) {
                    // Only moves that can enter the top N need an exact score.
                    val floor = if (scored.size >= settings.multiPv) scored[settings.multiPv - 1].first else -INF
                    val pv = ArrayList<Move>()
                    val score = -negamax(search, root.apply(m), depth - 1, -INF, -floor, 1, pv)
                    if (score > floor) {
                        scored.add(score to listOf(m) + pv)
                        scored.sortByDescending { it.first }
                    }
                }
            } catch (_: OutOfTime) {
                break
            }
            val top = scored.take(settings.multiPv)
            result = AnalysisResult(
                top.mapIndexed { i, (v, pv) -> CandidateLine(i + 1, toScore(v), depth, pv) },
                depth,
                name,
            )
            onUpdate(result)
            val first = top.map { it.second.first() }
            moves = first + moves.filter { it !in first }
            if (System.nanoTime() > deadline) break
        }
        result ?: throw EngineException("No result")
    }

    private fun toScore(v: Int): Score = when {
        v > MATE - 1000 -> Score(mateIn = (MATE - v + 1) / 2)
        v < -MATE + 1000 -> Score(mateIn = -(MATE + v) / 2)
        else -> Score(centipawns = v)
    }

    private fun negamax(s: Search, p: Position, depth: Int, alpha: Int, beta: Int, ply: Int, pv: MutableList<Move>): Int {
        s.tick()
        val moves = p.legalMoves()
        if (moves.isEmpty()) return if (p.isInCheck()) -MATE + ply else 0
        if (p.halfmoveClock >= 100 || Game.insufficientMaterial(p)) return 0
        if (depth <= 0) return quiesce(s, p, alpha, beta, 0)
        var a = alpha
        for (m in order(p, moves)) {
            val childPv = ArrayList<Move>()
            val v = -negamax(s, p.apply(m), depth - 1, -beta, -a, ply + 1, childPv)
            if (v >= beta) return beta
            if (v > a) {
                a = v
                pv.clear()
                pv.add(m)
                pv.addAll(childPv)
            }
        }
        return a
    }

    private fun quiesce(s: Search, p: Position, alpha: Int, beta: Int, depth: Int): Int {
        s.tick()
        val stand = evaluate(p)
        if (stand >= beta) return beta
        var a = maxOf(alpha, stand)
        if (depth >= 6) return a
        for (m in order(p, p.legalMoves().filter { p[it.to] != null || it.promotion == PieceType.QUEEN })) {
            val v = -quiesce(s, p.apply(m), -beta, -a, depth + 1)
            if (v >= beta) return beta
            if (v > a) a = v
        }
        return a
    }

    private fun order(p: Position, moves: List<Move>): List<Move> = moves.sortedByDescending { m ->
        val victim = p[m.to]
        var s = 0
        if (victim != null) s += 10 * victim.type.value - (p[m.from]?.type?.value ?: 0) / 10 + 1000
        if (m.promotion != null) s += m.promotion.value
        s
    }

    /** Material plus simple placement terms, from the side to move's point of view. */
    fun evaluate(p: Position): Int {
        var white = 0
        var nonPawn = 0
        for (i in 0 until 64) {
            val piece = p[i] ?: continue
            if (piece.type != PieceType.PAWN) nonPawn += piece.type.value
        }
        val endgame = nonPawn < 2600
        for (i in 0 until 64) {
            val piece = p[i] ?: continue
            val file = Squares.file(i)
            val rank = if (piece.side == Side.WHITE) Squares.rank(i) else 7 - Squares.rank(i)
            val centre = 6 - (kotlin.math.abs(2 * file - 7) + kotlin.math.abs(2 * Squares.rank(i) - 7)) / 2
            val bonus = when (piece.type) {
                PieceType.PAWN -> rank * (if (endgame) 12 else 4) + if (file in 3..4) rank * 4 else 0
                PieceType.KNIGHT -> centre * 8 - if (rank == 0) 15 else 0
                PieceType.BISHOP -> centre * 5 - if (rank == 0) 15 else 0
                PieceType.ROOK -> if (rank == 6) 20 else 0
                PieceType.QUEEN -> centre * 2
                PieceType.KING -> if (endgame) centre * 10 else -rank * 20 + if (rank == 0 && (file <= 2 || file >= 6)) 30 else 0
            }
            val v = piece.type.value + bonus
            white += if (piece.side == Side.WHITE) v else -v
        }
        return if (p.sideToMove == Side.WHITE) white else -white
    }

    override fun close() {}

    private companion object {
        const val INF = 1_000_000
        const val MATE = Score.MATE
    }
}
