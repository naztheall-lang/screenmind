package com.screenmind.app.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS
import android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
import android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION
import android.provider.Settings.canDrawOverlays
import com.screenmind.app.capture.ProjectionPermissionActivity
import com.screenmind.app.services.ScreenAccessibilityService
import com.screenmind.app.services.SessionService
import com.screenmind.app.settings.Settings

class ControlsActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        build()
    }

    private fun build() {
        val settings = Settings(this)
        val page = page("Screen reading")
        val overlay = canDrawOverlays(this)
        val notify = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val access = ScreenAccessibilityService.instance != null
        fun mark(on: Boolean) = if (on) "✓ " else "○ "

        page.heading("Permissions")
        page.add(card("${mark(overlay)}Display over other apps", "Needed for the floating panel.") {
            settingsScreen(Intent(ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        page.add(card("${mark(notify)}Notifications", "Shows when ScreenMind is active, with a stop button.") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        page.add(card("${mark(access)}Accessibility access (optional)", "Reads button and field types. ScreenMind never taps or types.") {
            confirm(
                "Accessibility access",
                "ScreenMind reads the visible interface only when you ask for analysis. Password contents are skipped. " +
                    "In the next screen choose ScreenMind and turn it on.",
                "Open settings",
            ) { settingsScreen(Intent(ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        page.add(card("Accessibility greyed out?", "Open app info, tap ⋮, choose Allow restricted settings, then try again.") {
            settingsScreen(Intent(ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        page.heading("Session")
        val reading = SessionService.instance?.isReading == true
        page.add(button("Show floating panel", true) {
            if (canDrawOverlays(this)) SessionService.showPanel(this) else toast("Allow display over other apps first")
        })
        page.add(button(if (reading) "Stop screen reading" else "Start screen reading") {
            if (reading) {
                SessionService.stopReading(this)
                window.decorView.postDelayed({ build() }, 400)
            } else {
                startActivity(Intent(this, ProjectionPermissionActivity::class.java))
            }
        })
        page.add(button("Close panel and session") {
            SessionService.stop(this)
            window.decorView.postDelayed({ build() }, 400)
        })
        page.heading("Mode")
        page.add(toggle("Chess mode (off = software mode)", settings.chessMode) { settings.chessMode = it })
        page.add(toggle("Analyse automatically when the screen changes", settings.autoAnalyse) { settings.autoAnalyse = it })
        page.note("Automatic analysis uses more battery. With it off, nothing is processed until you tap Analyse.")
    }

    private fun settingsScreen(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            toast("Open this permission from the phone's Settings app")
        }
    }
}
