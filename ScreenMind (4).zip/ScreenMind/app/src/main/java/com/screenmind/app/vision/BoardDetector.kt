package com.screenmind.app.vision

/** A detected board in the coordinates of the image passed to [BoardDetector.detect]. */
data class BoardLocation(val left: Float, val top: Float, val size: Float, val confidence: Float) {
    val square: Float get() = size / 8f
}

/**
 * Finds an axis-aligned chessboard anywhere in a screenshot:
 * 1. proposes 8x8 lattices whose inner grid lines coincide with strong edges,
 * 2. verifies that square backgrounds alternate between two consistent colours.
 */
object BoardDetector {
    private const val WORK_WIDTH = 480
    private const val EDGE = 10

    private class Candidate(val x: Int, val y: Int, val s: Float, val score: Float)

    fun detect(source: PixelImage): BoardLocation? {
        val image = source.scaledToWidth(WORK_WIDTH)
        val w = image.width
        val h = image.height
        // Prefix sums of edge pixels along each column (vertical lines) and row (horizontal lines).
        val vert = IntArray(w * (h + 1))
        val horz = IntArray(h * (w + 1))
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = image[x, y]
                val v = if (x > 0 && Colors.distance(c, image[x - 1, y]) > EDGE) 1 else 0
                val u = if (y > 0 && Colors.distance(c, image[x, y - 1]) > EDGE) 1 else 0
                vert[(y + 1) * w + x] = vert[y * w + x] + v
                horz[y * (w + 1) + x + 1] = horz[y * (w + 1) + x] + u
            }
        }

        val best = ArrayList<Candidate>()
        var s = maxOf(18f, minOf(w, h) / 20f)
        val maxS = minOf(w, h) / 8f
        val offsets = IntArray(9)
        while (s <= maxS + 0.01f) {
            for (i in 0..8) offsets[i] = Math.round(i * s)
            val span = offsets[8]
            var y = 0
            while (y + span <= h) {
                for (x in 0..w - span) {
                    var total = 0f
                    var weakest = 1f
                    for (i in 1..7) {
                        // A line may be blurred over two adjacent pixels after scaling.
                        val cx = x + offsets[i]
                        var n = 0
                        for (d in -1..1) n = maxOf(n, vert[(y + span) * w + cx + d] - vert[y * w + cx + d])
                        val cy = y + offsets[i]
                        var m = 0
                        for (d in -1..1) {
                            val row = (cy + d).coerceIn(0, h - 1) * (w + 1)
                            m = maxOf(m, horz[row + x + span] - horz[row + x])
                        }
                        val a = n.toFloat() / span
                        val b = m.toFloat() / span
                        total += a + b
                        weakest = minOf(weakest, a, b)
                        if (i == 3 && total < 1.2f) break
                    }
                    val score = total / 14f + weakest * 0.5f
                    if (score > 0.4f) keep(best, Candidate(x, y, s, score))
                }
                y += 2
            }
            s += 0.25f
        }

        var winner: BoardLocation? = null
        var winnerScore = 0f
        for (c in best) {
            // Refine around the proposal because the coarse pass steps two rows at a time.
            for (dy in -2..2) for (dx in -1..1) {
                val x = c.x + dx
                val y = c.y + dy
                val size = c.s * 8
                if (x < 0 || y < 0 || x + size > w + 0.5f || y + size > h + 0.5f) continue
                val checker = checkerScore(image, x.toFloat(), y.toFloat(), c.s)
                if (checker < 0.8f) continue
                val line = lineScore(image, x.toFloat(), y.toFloat(), c.s)
                val score = checker * checker * (0.3f + line)
                if (score > winnerScore) {
                    winnerScore = score
                    val k = source.width.toFloat() / w
                    winner = BoardLocation(x * k, y * k, size * k, (checker * minOf(1f, 0.5f + line)).coerceIn(0f, 1f))
                }
            }
        }
        return winner
    }

    private fun keep(best: ArrayList<Candidate>, c: Candidate) {
        val near = best.indexOfFirst {
            kotlin.math.abs(it.x - c.x) < 6 && kotlin.math.abs(it.y - c.y) < 6 && kotlin.math.abs(it.s - c.s) < 1.5f
        }
        if (near >= 0) {
            if (best[near].score < c.score) best[near] = c
            return
        }
        if (best.size < 80) {
            best.add(c)
        } else {
            var low = 0
            for (i in 1 until best.size) if (best[i].score < best[low].score) low = i
            if (best[low].score < c.score) best[low] = c
        }
    }

    /** Fraction of pixels along all nine grid lines that show an edge exactly there. */
    private fun lineScore(img: PixelImage, x: Float, y: Float, s: Float): Float {
        var hit = 0
        var all = 0
        val steps = 48
        for (i in 0..8) {
            val lx = Math.round(x + i * s)
            val ly = Math.round(y + i * s)
            for (k in 0 until steps) {
                val t = (k + 0.5f) * s * 8 / steps
                val py = (y + t).toInt().coerceIn(0, img.height - 1)
                val px = (x + t).toInt().coerceIn(0, img.width - 1)
                all += 2
                if (lx <= 0 || lx >= img.width - 1 || Colors.distance(img[lx - 1, py], img[lx + 1, py]) > EDGE) hit++
                if (ly <= 0 || ly >= img.height - 1 || Colors.distance(img[px, ly - 1], img[px, ly + 1]) > EDGE) hit++
            }
        }
        return hit.toFloat() / all
    }

    /** Background colour of one square from patches near its four corners, which pieces rarely cover. */
    fun squareColour(img: PixelImage, left: Float, top: Float, s: Float): Int {
        val samples = IntArray(36)
        var n = 0
        for (fy in floatArrayOf(0.09f, 0.91f)) for (fx in floatArrayOf(0.09f, 0.91f)) {
            for (j in -1..1) for (i in -1..1) {
                val x = (left + fx * s + i * s * 0.025f).toInt().coerceIn(0, img.width - 1)
                val y = (top + fy * s + j * s * 0.025f).toInt().coerceIn(0, img.height - 1)
                samples[n++] = img[x, y]
            }
        }
        return Colors.median(samples, n)
    }

    private fun checkerScore(img: PixelImage, x: Float, y: Float, s: Float): Float {
        val colours = IntArray(64) { squareColour(img, x + it % 8 * s, y + it / 8 * s, s) }
        val groups = Array(2) { parity -> colours.filterIndexed { i, _ -> (i % 8 + i / 8) % 2 == parity }.toIntArray() }
        val light = Colors.median(groups[0])
        val dark = Colors.median(groups[1])
        if (Colors.distance(light, dark) < 24) return 0f
        var good = 0
        for (i in 0 until 64) {
            val expected = if ((i % 8 + i / 8) % 2 == 0) light else dark
            if (Colors.distance(colours[i], expected) <= 20) good++
        }
        return good / 64f
    }
}
