package com.screenmind.app.vision

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.screenmind.app.software.IRect
import com.screenmind.app.software.OcrLine
import com.screenmind.app.utils.Bitmaps
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** On-device Latin text recognition. The model is loaded on first use and can be released. */
class OcrEngine {
    private var client: TextRecognizer? = null

    suspend fun read(image: PixelImage): List<OcrLine> = suspendCancellableCoroutine { continuation ->
        val recognizer = client ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).also { client = it }
        val bitmap = Bitmaps.toBitmap(image)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val lines = result.textBlocks.flatMap { it.lines }.mapNotNull { line ->
                    val box = line.boundingBox ?: return@mapNotNull null
                    OcrLine(line.text, IRect(box.left, box.top, box.right, box.bottom))
                }
                if (continuation.isActive) continuation.resume(lines)
            }
            .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
            .addOnCompleteListener { bitmap.recycle() }
    }

    fun release() {
        client?.close()
        client = null
    }
}
