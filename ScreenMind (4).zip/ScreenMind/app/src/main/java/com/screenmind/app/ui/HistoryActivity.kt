package com.screenmind.app.ui

import android.app.AlertDialog
import android.content.Intent
import com.screenmind.app.history.HistoryKind
import com.screenmind.app.services.Analyzer
import java.text.DateFormat
import java.util.Date

class HistoryActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val page = page("Analysis history")
        val entries = Analyzer.history(this).all()
        if (entries.isEmpty()) {
            page.note("No saved results.")
            return
        }
        page.add(button("Clear all") {
            confirm("Clear history?", "This cannot be undone.", "Clear") {
                Analyzer.history(this).clear()
                build()
            }
        })
        val format = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        for (e in entries) {
            page.add(card(e.title, "${e.kind.name.lowercase()} · ${format.format(Date(e.time))}") {
                val dialog = AlertDialog.Builder(this).setTitle(e.title).setMessage(e.detail).setPositiveButton("Close", null)
                if (e.kind == HistoryKind.CHESS) {
                    dialog.setNeutralButton("Open on board") { _, _ ->
                        startActivity(Intent(this, ChessActivity::class.java).putExtra(ChessActivity.EXTRA_FEN, e.detail))
                    }
                }
                dialog.show()
            }, bottom = 4)
        }
    }
}
