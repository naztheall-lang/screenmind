package com.screenmind.app.engine

/** Remembers finished analyses so a position seen before is answered at once. */
class AnalysisCache(private val limit: Int = 64) {
    private val entries = LinkedHashMap<String, DeepAnalysis>()

    fun key(request: AnalysisRequest): String = request.startFen + " " + request.moves.joinToString(" ") { it.uci() }

    @Synchronized
    fun get(request: AnalysisRequest): DeepAnalysis? {
        val k = key(request)
        val found = entries.remove(k) ?: return null
        entries[k] = found
        return found
    }

    @Synchronized
    fun put(request: AnalysisRequest, analysis: DeepAnalysis) {
        // A stand-in engine's answers are not worth keeping.
        if (analysis.main.lines.isEmpty() || analysis.main.engineName.startsWith("Basic")) return
        val k = key(request)
        entries.remove(k)
        entries[k] = analysis
        while (entries.size > limit) entries.remove(entries.keys.first())
    }
}
