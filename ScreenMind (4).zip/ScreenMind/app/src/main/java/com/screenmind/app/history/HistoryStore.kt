package com.screenmind.app.history

import com.screenmind.app.utils.Json
import java.io.File
import java.io.IOException

enum class HistoryKind { CHESS, SOFTWARE, ASSISTANT }

data class HistoryEntry(val time: Long, val kind: HistoryKind, val title: String, val detail: String)

/** Stores text results only, never screenshots. Newest entries come first. */
class HistoryStore(private val file: File, private val limit: Int = 100) {
    @Synchronized
    fun all(): List<HistoryEntry> = try {
        if (!file.exists()) emptyList() else file.readLines().mapNotNull { decode(it) }.reversed()
    } catch (_: IOException) {
        emptyList()
    }

    @Synchronized
    fun add(entry: HistoryEntry) {
        val keep = (all().reversed() + entry).takeLast(limit)
        try {
            file.writeText(keep.joinToString("") { encode(it) + "\n" })
        } catch (_: IOException) {
            // History is optional; a full disk must not break analysis.
        }
    }

    @Synchronized
    fun clear() {
        file.delete()
    }

    private fun encode(e: HistoryEntry) =
        Json.write(mapOf("t" to e.time, "k" to e.kind.name, "h" to e.title, "d" to e.detail.take(4000)))

    private fun decode(line: String): HistoryEntry? = try {
        val m = Json.parse(line) as Map<*, *>
        HistoryEntry(
            (m["t"] as Double).toLong(),
            HistoryKind.valueOf(m["k"] as String),
            m["h"] as String,
            m["d"] as String,
        )
    } catch (_: RuntimeException) {
        null
    }
}
