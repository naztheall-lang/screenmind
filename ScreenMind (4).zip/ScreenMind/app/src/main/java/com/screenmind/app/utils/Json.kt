package com.screenmind.app.utils

/** A very small JSON reader and writer for maps, lists, strings, numbers and booleans. */
object Json {
    fun write(v: Any?): String = StringBuilder().also { write(v, it) }.toString()

    private fun write(v: Any?, out: StringBuilder) {
        when (v) {
            null -> out.append("null")
            is Boolean, is Int, is Long -> out.append(v)
            is Number -> out.append(v.toDouble())
            is Map<*, *> -> {
                out.append('{')
                v.entries.forEachIndexed { i, e ->
                    if (i > 0) out.append(',')
                    write(e.key.toString(), out)
                    out.append(':')
                    write(e.value, out)
                }
                out.append('}')
            }
            is Iterable<*> -> {
                out.append('[')
                v.forEachIndexed { i, e ->
                    if (i > 0) out.append(',')
                    write(e, out)
                }
                out.append(']')
            }
            else -> {
                out.append('"')
                for (c in v.toString()) {
                    when {
                        c == '"' || c == '\\' -> out.append('\\').append(c)
                        c == '\n' -> out.append("\\n")
                        c < ' ' -> out.append("\\u").append(c.code.toString(16).padStart(4, '0'))
                        else -> out.append(c)
                    }
                }
                out.append('"')
            }
        }
    }

    /** Throws IllegalArgumentException on malformed input. */
    fun parse(text: String): Any? {
        val p = Parser(text)
        val v = p.value(0)
        p.space()
        require(p.i == text.length) { "Unexpected text after JSON" }
        return v
    }

    private class Parser(val s: String) {
        var i = 0
        fun space() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun peek(): Char {
            space()
            require(i < s.length) { "Unexpected end of JSON" }
            return s[i]
        }

        fun expect(c: Char) {
            require(peek() == c) { "Expected $c at $i" }
            i++
        }

        fun value(depth: Int): Any? {
            require(depth < 64) { "JSON nested too deeply" }
            return when (peek()) {
                '{' -> {
                    i++
                    val m = LinkedHashMap<String, Any?>()
                    while (peek() != '}') {
                        val k = string()
                        expect(':')
                        m[k] = value(depth + 1)
                        if (peek() == ',') i++ else break
                    }
                    expect('}')
                    m
                }
                '[' -> {
                    i++
                    val l = ArrayList<Any?>()
                    while (peek() != ']') {
                        l.add(value(depth + 1))
                        if (peek() == ',') i++ else break
                    }
                    expect(']')
                    l
                }
                '"' -> string()
                else -> {
                    val start = i
                    while (i < s.length && s[i] !in ",]} \n\r\t") i++
                    when (val word = s.substring(start, i)) {
                        "true" -> true
                        "false" -> false
                        "null" -> null
                        else -> requireNotNull(word.toDoubleOrNull()) { "Bad value '$word'" }
                    }
                }
            }
        }

        fun string(): String {
            expect('"')
            val out = StringBuilder()
            while (true) {
                require(i < s.length) { "Unterminated string" }
                val c = s[i++]
                if (c == '"') return out.toString()
                if (c != '\\') {
                    out.append(c)
                    continue
                }
                require(i < s.length) { "Unterminated escape" }
                when (val e = s[i++]) {
                    'n' -> out.append('\n')
                    't' -> out.append('\t')
                    'r' -> out.append('\r')
                    'b' -> out.append('\b')
                    'f' -> out.append('\u000c')
                    'u' -> {
                        require(i + 4 <= s.length) { "Bad unicode escape" }
                        out.append(s.substring(i, i + 4).toInt(16).toChar())
                        i += 4
                    }
                    else -> out.append(e)
                }
            }
        }
    }
}
