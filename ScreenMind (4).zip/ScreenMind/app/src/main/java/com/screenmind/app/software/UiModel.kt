package com.screenmind.app.software

data class IRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centreX: Int get() = (left + right) / 2
    val centreY: Int get() = (top + bottom) / 2
    val area: Long get() = maxOf(0, width).toLong() * maxOf(0, height)

    fun contains(x: Int, y: Int) = x >= left && x < right && y >= top && y < bottom

    fun overlap(o: IRect): Long =
        IRect(maxOf(left, o.left), maxOf(top, o.top), minOf(right, o.right), minOf(bottom, o.bottom)).area
}

enum class ElementType(val label: String) {
    BUTTON("Button"), TEXT_FIELD("Text field"), MENU("Menu"), NAV_BAR("Navigation bar item"), TAB("Tab"),
    ICON("Icon"), DIALOG("Dialogue"), TOGGLE("Switch or checkbox"), SETTING("Setting"), TOOLBAR("Toolbar item"),
    ERROR("Error message"), LIST_ITEM("List item"), TEXT("Text"),
}

enum class Source(val label: String) { ACCESSIBILITY("accessibility"), OCR("text recognition"), VISION("image analysis") }

data class UiElement(
    val type: ElementType,
    val label: String,
    val bounds: IRect,
    val confidence: Float,
    val source: Source,
    val enabled: Boolean = true,
    val checked: Boolean? = null,
)

/** A node copied from the accessibility tree. */
data class RawNode(
    val className: String,
    val text: String = "",
    val description: String = "",
    val hint: String = "",
    val viewId: String = "",
    val bounds: IRect,
    val clickable: Boolean = false,
    val editable: Boolean = false,
    val checkable: Boolean = false,
    val checked: Boolean = false,
    val enabled: Boolean = true,
    val password: Boolean = false,
    val selected: Boolean = false,
    val children: List<RawNode> = emptyList(),
)

data class OcrLine(val text: String, val bounds: IRect)

data class ScreenModel(
    val appName: String?,
    val packageName: String?,
    val width: Int,
    val height: Int,
    val elements: List<UiElement>,
    val usedAccessibility: Boolean,
    val usedOcr: Boolean,
) {
    val errors: List<UiElement> get() = elements.filter { it.type == ElementType.ERROR }
    val isDialog: Boolean get() = elements.any { it.type == ElementType.DIALOG }

    fun position(r: IRect): String {
        val v = when {
            r.centreY < height * 0.33 -> "top"
            r.centreY > height * 0.67 -> "bottom"
            else -> "middle"
        }
        val h = when {
            r.centreX < width * 0.33 -> "left"
            r.centreX > width * 0.67 -> "right"
            else -> "centre"
        }
        return if (v == "middle" && h == "centre") "centre of the screen" else "$v $h"
    }

    fun summary(): String {
        if (elements.isEmpty()) return "Nothing recognisable was found on this screen."
        val head = StringBuilder()
        head.append(if (appName != null) "App: $appName. " else "App name not identified. ")
        val title = elements.filter { it.bounds.centreY < height * 0.16 && it.label.length in 2..40 }
            .maxByOrNull { it.bounds.height }?.label
        if (title != null) head.append("Heading appears to be \"$title\". ")
        if (isDialog) head.append("A dialogue is open. ")
        if (errors.isNotEmpty()) head.append("An error or warning is shown. ")
        val counts = elements.filter { it.type != ElementType.TEXT && it.type != ElementType.DIALOG }
            .groupingBy { it.type }.eachCount().entries.sortedByDescending { it.value }
        if (counts.isNotEmpty()) head.append("Found: " + counts.joinToString { "${it.value} × ${it.key.label.lowercase()}" } + ".")
        if (!usedAccessibility) head.append("\nControl types are estimates because accessibility access is not in use.")
        return head.toString()
    }
}
