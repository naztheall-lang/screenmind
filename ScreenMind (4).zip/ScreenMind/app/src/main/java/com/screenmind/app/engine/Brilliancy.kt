package com.screenmind.app.engine

import com.screenmind.app.chess.Move
import com.screenmind.app.chess.MoveGen
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Position

/**
 * A "Brilliant" move here is a real sacrifice that the engine still rates (almost) as highly as
 * its best move. Most positions have none, and an unsound sacrifice is never labelled.
 */
object Brilliancy {
    const val MIN_DEPTH = 10
    private const val MIN_SACRIFICE = 150

    /** Best material the side to move can win by capturing on [square], with recaptures. */
    private fun exchange(p: Position, square: Int, ply: Int = 0): Int {
        val victim = p[square] ?: return 0
        if (ply > 8 || victim.type == PieceType.KING) return 0
        if (!MoveGen.isAttacked(p, square, p.sideToMove)) return 0
        val capture = p.legalMoves().filter { it.to == square }
            .minByOrNull { m -> p[m.from]!!.type.let { if (it == PieceType.KING) 10_000 else it.value } } ?: return 0
        return maxOf(0, victim.type.value - exchange(p.apply(capture), square, ply + 1))
    }

    /** Net centipawns of material that [move] newly offers to the opponent. */
    fun sacrifice(position: Position, move: Move): Int {
        val us = position.sideToMove
        val captured = position[move.to]?.type?.value ?: 0
        val after = position.apply(move)
        val passed = Position(position.copyBoard(), us.other, 0, null, 0, 1)
        var offered = 0
        for (square in 0 until 64) {
            val piece: Piece = after[square] ?: continue
            if (piece.side != us || piece.type == PieceType.PAWN || piece.type == PieceType.KING) continue
            var gain = exchange(after, square)
            // A piece that was already hanging elsewhere is not offered by this move.
            if (square != move.to && position[square] == piece) gain -= exchange(passed, square)
            offered = maxOf(offered, gain)
        }
        return offered - captured
    }

    fun isBrilliant(position: Position, line: CandidateLine, lines: List<CandidateLine>): Boolean {
        if (line.depth < MIN_DEPTH || position.legalMoves().size < 2) return false
        val value = line.score.value()
        val best = lines.maxOf { it.score.value() }
        if (value < best - 60 || value < -50) return false
        if (sacrifice(position, line.move) < MIN_SACRIFICE) return false
        // Not brilliant if a quiet move already wins just as well.
        return lines.none {
            it !== line && it.score.value() > 700 && it.score.value() >= value - 60 &&
                sacrifice(position, it.move) < MIN_SACRIFICE
        }
    }

    /** Every legal move that offers material, whether or not it is any good. */
    fun candidates(position: Position): List<Move> =
        position.legalMoves().filter { sacrifice(position, it) >= MIN_SACRIFICE }

    /** All Brilliant moves, strongest first. */
    fun all(position: Position, lines: List<CandidateLine>): List<CandidateLine> =
        lines.filter { isBrilliant(position, it, lines) }.sortedByDescending { it.score.value() }

    fun pick(position: Position, lines: List<CandidateLine>): CandidateLine? = all(position, lines).firstOrNull()
}
