package com.screenmind.app.services

import android.accessibilityservice.AccessibilityService
import android.content.pm.PackageManager
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.screenmind.app.software.IRect
import com.screenmind.app.software.RawNode

class TreeSnapshot(val packageName: String?, val appName: String?, val roots: List<RawNode>)

/** Reads the interface tree only when an analysis asks for it. It never clicks or types. */
class ScreenAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun snapshot(): TreeSnapshot {
        var budget = 600
        fun copy(node: AccessibilityNodeInfo, depth: Int): RawNode? {
            if (budget-- <= 0 || depth > 40 || !node.isVisibleToUser) return null
            val r = Rect()
            node.getBoundsInScreen(r)
            val children = ArrayList<RawNode>()
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                copy(child, depth + 1)?.let { children.add(it) }
            }
            val secret = node.isPassword
            return RawNode(
                className = node.className?.toString() ?: "",
                text = if (secret) "" else node.text?.toString()?.take(300) ?: "",
                description = node.contentDescription?.toString()?.take(200) ?: "",
                hint = node.hintText?.toString()?.take(100) ?: "",
                viewId = node.viewIdResourceName ?: "",
                bounds = IRect(r.left, r.top, r.right, r.bottom),
                clickable = node.isClickable,
                editable = node.isEditable,
                checkable = node.isCheckable,
                checked = node.isChecked,
                enabled = node.isEnabled,
                password = secret,
                selected = node.isSelected,
                children = children,
            )
        }

        val candidates = windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .sortedByDescending { it.layer }
            .mapNotNull { it.root }
            .toMutableList()
        if (candidates.isEmpty()) rootInActiveWindow?.let { candidates.add(it) }
        // ScreenMind's own windows are never part of the analysis.
        val others = candidates.filter { it.packageName?.toString() != packageName }
        val pkg = others.firstOrNull()?.packageName?.toString()
        val roots = others.filter { it.packageName?.toString() == pkg }.mapNotNull { copy(it, 0) }
        return TreeSnapshot(pkg, pkg?.let { label(it) }, roots)
    }

    private fun label(pkg: String): String? = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }

    companion object {
        @Volatile
        var instance: ScreenAccessibilityService? = null
            private set
    }
}
