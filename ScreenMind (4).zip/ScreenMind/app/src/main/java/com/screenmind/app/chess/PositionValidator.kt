package com.screenmind.app.chess

/** Rejects positions that could not occur in a game, so the engine is never given nonsense. */
object PositionValidator {
    fun problems(p: Position): List<String> {
        val out = ArrayList<String>()
        for (side in Side.values()) {
            val counts = IntArray(PieceType.values().size)
            for (i in 0 until 64) {
                val piece = p[i] ?: continue
                if (piece.side == side) counts[piece.type.ordinal]++
            }
            val name = side.title
            val kings = counts[PieceType.KING.ordinal]
            if (kings != 1) out.add("$name has $kings kings (needs exactly 1)")
            val pawns = counts[PieceType.PAWN.ordinal]
            if (pawns > 8) out.add("$name has $pawns pawns (maximum 8)")
            if (counts.sum() > 16) out.add("$name has more than 16 pieces")
            val extra = maxOf(0, counts[PieceType.QUEEN.ordinal] - 1) +
                maxOf(0, counts[PieceType.ROOK.ordinal] - 2) +
                maxOf(0, counts[PieceType.BISHOP.ordinal] - 2) +
                maxOf(0, counts[PieceType.KNIGHT.ordinal] - 2)
            if (pawns <= 8 && extra > 8 - pawns) out.add("$name has more promoted pieces than missing pawns")
        }
        for (i in 0 until 64) {
            if (p[i]?.type == PieceType.PAWN && (Squares.rank(i) == 0 || Squares.rank(i) == 7)) {
                out.add("A pawn cannot stand on ${Squares.name(i)}")
            }
        }
        if (out.isEmpty() && p.isInCheck(p.sideToMove.other)) {
            out.add("${p.sideToMove.other.title} is in check but it is ${p.sideToMove.title}'s turn")
        }
        if (p.castling and Position.possibleCastling(p.copyBoard()).inv() != 0) {
            out.add("Castling rights do not match the king and rook squares")
        }
        val ep = p.enPassant
        if (ep != null) {
            val white = p.sideToMove == Side.WHITE
            val expectedRank = if (white) 5 else 2
            val pawnSquare = ep + if (white) -8 else 8
            if (Squares.rank(ep) != expectedRank || p[ep] != null || p[pawnSquare] != Piece(p.sideToMove.other, PieceType.PAWN)) {
                out.add("En passant square ${Squares.name(ep)} is impossible here")
            }
        }
        return out
    }

    fun isValid(p: Position): Boolean = problems(p).isEmpty()
}
