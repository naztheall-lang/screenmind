package com.screenmind.app.engine

/** Uses [primary] and switches permanently to [backup] if the primary engine cannot run. */
class FallbackEngine(private val primary: ChessEngine, private val backup: ChessEngine) : ChessEngine {
    private var failed: String? = null
    override val name: String get() = if (failed == null) primary.name else "${backup.name} — Stockfish failed: $failed"

    override suspend fun analyse(request: AnalysisRequest, settings: EngineSettings, onUpdate: (AnalysisResult) -> Unit): AnalysisResult {
        if (failed == null) {
            try {
                return primary.analyse(request, settings, onUpdate)
            } catch (e: EngineException) {
                failed = e.message
            }
        }
        return backup.analyse(request, settings, onUpdate).copy(engineName = name)
    }

    override fun close() {
        primary.close()
        backup.close()
    }
}
