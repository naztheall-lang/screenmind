package com.screenmind.app.ui

import android.content.Intent
import android.net.Uri
import com.screenmind.app.services.Analyzer
import com.screenmind.app.software.ElementType
import com.screenmind.app.software.Knowledge
import com.screenmind.app.utils.Bitmaps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class SoftwareActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val page = page("Software recognition")
        page.add(row(
            button("Ask about it", true) { startActivity(Intent(this, AssistantActivity::class.java)) },
            button("Open screenshot") {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 1,
                )
            },
        ))
        val screen = Analyzer.lastScreen
        if (screen == null) {
            page.note("Nothing read yet. Start the floating panel, open another app and tap Analyse, or open a screenshot.")
            return
        }
        page.note(screen.summary(), Ui.TEXT)
        for (type in ElementType.values()) {
            val items = screen.elements.filter { it.type == type }.take(30)
            if (items.isEmpty()) continue
            page.heading(type.label)
            for (e in items) {
                val sure = when {
                    e.confidence >= 0.85f -> "reliable"
                    e.confidence >= 0.6f -> "likely"
                    else -> "guess"
                }
                val detail = "${screen.position(e.bounds)} · $sure, from ${e.source.label}" +
                    (e.checked?.let { if (it) " · on" else " · off" } ?: "")
                page.add(card(e.label.take(100), detail) {
                    val meaning = if (type == ElementType.ERROR) {
                        Knowledge.explainError(e.label)?.let { it.meaning + "\n\n" + it.steps.joinToString("\n") }
                    } else Knowledge.explainControl(e.label)
                    message(e.label.take(60), meaning ?: "ScreenMind does not know what this does.")
                }, bottom = 4)
            }
        }
    }

    @Deprecated("Framework callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val uri: Uri = data?.data?.takeIf { resultCode == RESULT_OK } ?: return
        scope.launch {
            try {
                val image = withContext(Dispatchers.IO) { Bitmaps.load(contentResolver, uri) }
                Analyzer.software(this@SoftwareActivity, image, image.width, image.height, null, true)
                build()
            } catch (e: IOException) {
                message("Could not open picture", e.message ?: "")
            } catch (e: SecurityException) {
                message("Could not open picture", "Permission was refused.")
            }
        }
    }
}
