package com.screenmind.app.utils

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.screenmind.app.vision.PixelImage
import java.io.IOException

object Bitmaps {
    fun toBitmap(image: PixelImage): Bitmap =
        Bitmap.createBitmap(image.pixels, image.width, image.height, Bitmap.Config.ARGB_8888)

    /** Decodes a user-chosen picture, downsampled so a large file cannot exhaust memory. */
    fun load(resolver: ContentResolver, uri: Uri): PixelImage {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("That file is not a readable picture")
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 2400) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: throw IOException("Could not open the picture")
        val image = PixelImage(bitmap.width, bitmap.height)
        bitmap.getPixels(image.pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        bitmap.recycle()
        return image
    }
}
