package com.screenmind.app.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DeepAnalysis(val main: AnalysisResult, val brilliant: List<CandidateLine>)

/**
 * Spends most of the time on the single best move, which is where an engine is strongest,
 * then takes two short passes: one for alternatives and one for sacrifices.
 */
object DeepSearch {
    private const val SACRIFICE_LINES = 4
    private const val DEPTH_MARGIN = 6

    suspend fun run(
        engine: ChessEngine,
        request: AnalysisRequest,
        settings: EngineSettings,
        onUpdate: (AnalysisResult) -> Unit = {},
        onHunt: () -> Unit = {},
    ): DeepAnalysis = withContext(Dispatchers.Default) {
        val first = engine.analyse(request, settings.copy(multiPv = 1), onUpdate)
        val best = first.lines.firstOrNull() ?: return@withContext DeepAnalysis(first, emptyList())
        val short = settings.copy(depth = maxOf(1, first.depth), moveTimeMs = settings.moveTimeMs / 3)

        var main = first
        val rest = request.position.legalMoves().filter { it != best.move }
        val wanted = minOf(settings.multiPv - 1, rest.size)
        if (wanted > 0) {
            val others = engine.analyse(request.copy(searchMoves = rest), short.copy(multiPv = wanted)).lines
            // The longer search decides which move is best; the others follow it.
            main = first.copy(lines = listOf(best) + others.mapIndexed { i, line -> line.copy(rank = i + 2) })
            onUpdate(main)
        }

        var extra = emptyList<CandidateLine>()
        if (first.depth >= Brilliancy.MIN_DEPTH) {
            val known = main.lines.map { it.move }
            val offers = Brilliancy.candidates(request.position).filter { it !in known }
            if (offers.isNotEmpty()) {
                onHunt()
                val narrow = short.copy(multiPv = minOf(SACRIFICE_LINES, offers.size))
                // A much shallower result is not trustworthy enough to call a sacrifice sound.
                extra = engine.analyse(request.copy(searchMoves = offers), narrow).lines
                    .filter { it.depth >= first.depth - DEPTH_MARGIN }
            }
        }
        DeepAnalysis(main, Brilliancy.all(request.position, main.lines + extra))
    }
}
