package com.screenmind.app.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings.canDrawOverlays
import com.screenmind.app.R
import com.screenmind.app.services.Analyzer
import com.screenmind.app.services.ScreenAccessibilityService
import com.screenmind.app.services.SessionService
import com.screenmind.app.settings.Settings

/** Home dashboard. */
class MainActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        val page = page("ScreenMind")
        val reading = SessionService.instance?.isReading == true
        page.add(tile(R.drawable.ic_chess, "Chess analysis", "Instant best moves, Brilliant finder, game review", true) {
            open(ChessActivity::class.java)
        }.apply { background = Ui.frost(context, Color.argb(240, 52, 118, 172), Color.argb(228, 20, 52, 96), Ui.ACCENT) }, bottom = 12)
        page.add(button(if (canDrawOverlays(this)) "❄  Start floating panel" else "❄  Set up permissions", true) {
            if (canDrawOverlays(this)) SessionService.showPanel(this) else open(ControlsActivity::class.java)
        }, bottom = 12)
        page.add(
            card(
                if (reading) "● Screen reading is ON" else "○ Screen reading is off",
                "Floating panel: ${if (!canDrawOverlays(this)) "needs permission" else if (SessionService.instance != null) "running" else "stopped"}\n" +
                    "Accessibility: ${if (ScreenAccessibilityService.instance != null) "enabled" else "not enabled"}\n" +
                    "Performance: ${Settings(this).performance.label}",
            ) { open(ControlsActivity::class.java) }
        )
        page.heading("Explore")
        page.add(row(
            tile(R.drawable.ic_scan, "Recognition", "What was on screen") { open(SoftwareActivity::class.java) },
            tile(R.drawable.ic_chat, "Assistant", "Ask where things are") { open(AssistantActivity::class.java) },
        ))
        page.add(row(
            tile(R.drawable.ic_controls, "Controls", "Permissions and mode") { open(ControlsActivity::class.java) },
            tile(R.drawable.ic_history, "History", "Past results") { open(HistoryActivity::class.java) },
        ))
        page.add(row(
            tile(R.drawable.ic_settings, "Settings", "Speed and snow") { open(SettingsActivity::class.java) },
            tile(R.drawable.ic_info, "About", "Help and licences") { open(AboutActivity::class.java) },
        ))
        Analyzer.history(this).all().firstOrNull()?.let {
            page.heading("Latest result")
            page.add(card(it.title, it.detail.take(120)) { open(HistoryActivity::class.java) })
        }
    }

    private fun open(target: Class<*>) = startActivity(Intent(this, target))
}
