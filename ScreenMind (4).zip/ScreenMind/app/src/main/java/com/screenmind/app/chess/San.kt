package com.screenmind.app.chess

object San {
    fun write(pos: Position, move: Move): String {
        val piece = pos[move.from] ?: return move.uci()
        val legal = pos.legalMoves()
        val body = if (piece.type == PieceType.KING && kotlin.math.abs(move.to - move.from) == 2) {
            if (move.to > move.from) "O-O" else "O-O-O"
        } else {
            val capture = pos[move.to] != null ||
                (piece.type == PieceType.PAWN && Squares.file(move.from) != Squares.file(move.to))
            buildString {
                if (piece.type == PieceType.PAWN) {
                    if (capture) append('a' + Squares.file(move.from))
                } else {
                    append(piece.type.letter.uppercaseChar())
                    val rivals = legal.filter { it.to == move.to && it.from != move.from && pos[it.from] == piece }
                    if (rivals.isNotEmpty()) {
                        val sameFile = rivals.any { Squares.file(it.from) == Squares.file(move.from) }
                        val sameRank = rivals.any { Squares.rank(it.from) == Squares.rank(move.from) }
                        if (!sameFile) {
                            append('a' + Squares.file(move.from))
                        } else if (!sameRank) {
                            append('1' + Squares.rank(move.from))
                        } else {
                            append(Squares.name(move.from))
                        }
                    }
                }
                if (capture) append('x')
                append(Squares.name(move.to))
                move.promotion?.let { append('=').append(it.letter.uppercaseChar()) }
            }
        }
        val after = pos.apply(move)
        val suffix = when {
            !after.isInCheck() -> ""
            after.legalMoves().isEmpty() -> "#"
            else -> "+"
        }
        return body + suffix
    }

    private fun normalise(s: String): String =
        s.replace('0', 'O').replace(Regex("[+#!?=x]"), "").replace("e.p.", "").trim()

    /** Accepts standard algebraic notation or UCI. Returns null if illegal or ambiguous. */
    fun parse(pos: Position, text: String): Move? {
        val legal = pos.legalMoves()
        legal.firstOrNull { it.uci() == text }?.let { return it }
        val wanted = normalise(text)
        val exact = legal.filter { normalise(write(pos, it)) == wanted }
        if (exact.size == 1) return exact[0]
        // Tolerate over-disambiguated input such as "Ngf3" or "Ng1f3".
        val m = Regex("([KQRBN])([a-h]?)([1-8]?)([a-h][1-8])").matchEntire(wanted) ?: return null
        val (letter, file, rank, target) = m.destructured
        val candidates = legal.filter {
            pos[it.from]?.type?.letter?.uppercaseChar() == letter[0] &&
                Squares.name(it.to) == target &&
                (file.isEmpty() || Squares.name(it.from)[0] == file[0]) &&
                (rank.isEmpty() || Squares.name(it.from)[1] == rank[0])
        }
        return candidates.singleOrNull()
    }

    /** Formats an engine line as numbered SAN, e.g. "12. Nf3 Nc6 13. d4". */
    fun line(start: Position, moves: List<Move>, limit: Int = 8): String {
        var pos = start
        val out = StringBuilder()
        for ((i, move) in moves.take(limit).withIndex()) {
            if (move !in pos.legalMoves()) break
            if (pos.sideToMove == Side.WHITE) {
                out.append(pos.fullmoveNumber).append(". ")
            } else if (i == 0) {
                out.append(pos.fullmoveNumber).append("... ")
            }
            out.append(write(pos, move)).append(' ')
            pos = pos.apply(move)
        }
        return out.toString().trim()
    }
}
