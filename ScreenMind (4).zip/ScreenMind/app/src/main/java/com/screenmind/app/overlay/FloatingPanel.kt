package com.screenmind.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.screenmind.app.software.IRect
import com.screenmind.app.ui.Ui

interface PanelActions {
    fun toggleReading()
    fun togglePause()
    fun analyse()
    fun openAssistant()
    fun switchMode()
    fun review()
    fun close()
}

/** The movable window shown over other apps. It never takes keyboard focus. */
class FloatingPanel(private val context: Context, private val actions: PanelActions) {
    private val windows = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val params = baseParams(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE).apply {
        x = 0
        y = Ui.dp(context, 120)
    }
    private val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.frost(context, Color.rgb(34, 70, 112), Ui.BG, Ui.ACCENT)
        val edge = Ui.dp(context, 4)
        setPadding(edge, edge, edge, edge)
    }
    private val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val status = Ui.text(context, "Ready", 12f, Ui.ACCENT)
    private val result = Ui.text(context, "Open an app, then tap Analyse.", 12f)
    private val resultScroll = ScrollView(context).apply { addView(result) }
    private lateinit var readButton: TextView
    private lateinit var pauseButton: TextView
    private lateinit var modeButton: TextView
    private lateinit var reviewButton: TextView
    private var attached = false
    private var highlight: View? = null
    var size = 1
        set(value) {
            field = value.mod(3)
            layout()
        }

    private fun baseParams(flags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun key(label: String, onClick: () -> Unit): TextView =
        Ui.text(context, label, 12f).apply {
            gravity = Gravity.CENTER
            background = Ui.box(context, Color.argb(70, 140, 205, 250), Color.argb(90, 180, 225, 255))
            setPadding(Ui.dp(context, 4), Ui.dp(context, 9), Ui.dp(context, 4), Ui.dp(context, 9))
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: View) = LinearLayout(context).apply {
        for (v in views) addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = Ui.dp(context, 2)
            rightMargin = Ui.dp(context, 2)
            topMargin = Ui.dp(context, 4)
        })
    }

    init {
        val title = Ui.text(context, "❄ ScreenMind", 13f, Ui.FROST).apply {
            setPadding(Ui.dp(context, 8), Ui.dp(context, 8), 0, Ui.dp(context, 8))
        }
        val header = LinearLayout(context).apply {
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(key("  –  ") { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
            addView(key("  ×  ") { actions.close() })
        }
        makeDraggable(title)
        readButton = key("Start") { actions.toggleReading() }
        pauseButton = key("Pause") { actions.togglePause() }
        modeButton = key("Software") { actions.switchMode() }
        reviewButton = key("Review") { actions.review() }
        status.setPadding(Ui.dp(context, 8), 0, Ui.dp(context, 8), 0)
        result.setPadding(Ui.dp(context, 8), Ui.dp(context, 4), Ui.dp(context, 8), Ui.dp(context, 4))
        body.addView(status)
        body.addView(resultScroll)
        body.addView(row(readButton, pauseButton, key("Analyse") { actions.analyse() }))
        body.addView(row(modeButton, key("Ask") { actions.openAssistant() }, reviewButton))
        body.addView(row(key("Hide 10s") { hideFor(10_000) }, key("Resize") { size += 1 }))
        root.addView(header)
        root.addView(body)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(handle: View) {
        var startX = 0f
        var startY = 0f
        var originX = 0
        var originY = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX
                    startY = e.rawY
                    originX = params.x
                    originY = params.y
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = originX + (e.rawX - startX).toInt()
                    params.y = originY + (e.rawY - startY).toInt()
                    update()
                }
            }
            true
        }
    }

    private fun layout() {
        val metrics = context.resources.displayMetrics
        val width = Ui.dp(context, intArrayOf(190, 240, 310)[size])
        params.width = minOf(width, metrics.widthPixels)
        resultScroll.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(context, intArrayOf(56, 100, 180)[size]),
        )
        update()
    }

    private fun update() {
        val metrics = context.resources.displayMetrics
        params.x = params.x.coerceIn(0, maxOf(0, metrics.widthPixels - params.width))
        params.y = params.y.coerceIn(0, maxOf(0, metrics.heightPixels - Ui.dp(context, 80)))
        if (attached) windows.updateViewLayout(root, params)
    }

    /** Returns false if Android refused the window (permission missing or revoked). */
    fun show(): Boolean {
        handler.removeCallbacks(reappear)
        if (attached) {
            root.visibility = View.VISIBLE
            return true
        }
        return try {
            layout()
            windows.addView(root, params)
            attached = true
            root.alpha = 0f
            root.animate().alpha(1f).setDuration(180).start()
            true
        } catch (_: RuntimeException) {
            false
        }
    }

    private val reappear = Runnable { root.visibility = View.VISIBLE }

    fun hideFor(millis: Long) {
        root.visibility = View.INVISIBLE
        handler.removeCallbacks(reappear)
        handler.postDelayed(reappear, millis)
    }

    fun unhide() {
        handler.removeCallbacks(reappear)
        root.visibility = View.VISIBLE
    }

    fun bounds(): IRect? {
        if (!attached || root.visibility != View.VISIBLE) return null
        val at = IntArray(2)
        root.getLocationOnScreen(at)
        return IRect(at[0], at[1], at[0] + root.width, at[1] + root.height)
    }

    fun render(statusText: String, resultText: String?, reading: Boolean, paused: Boolean, chess: Boolean) {
        status.text = statusText
        if (resultText != null) result.text = resultText
        readButton.text = if (reading) "Stop" else "Start"
        pauseButton.text = if (paused) "Resume" else "Pause"
        modeButton.text = if (chess) "Chess" else "Software"
        reviewButton.text = if (chess) "Review" else "Details"
    }

    /** Draws a pass-through outline around a control for a few seconds. */
    fun highlight(area: IRect) {
        clearHighlight()
        val view = View(context).apply {
            background = GradientDrawable().apply { setStroke(Ui.dp(context, 3), Ui.ACCENT) }
        }
        val p = baseParams(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        p.x = area.left
        p.y = area.top
        p.width = maxOf(area.width, Ui.dp(context, 24))
        p.height = maxOf(area.height, Ui.dp(context, 24))
        // Android only passes touches through overlays that are at most 80% opaque.
        p.alpha = 0.75f
        try {
            windows.addView(view, p)
            highlight = view
            handler.postDelayed({ clearHighlight() }, 5000)
        } catch (_: RuntimeException) {
            highlight = null
        }
    }

    private fun clearHighlight() {
        highlight?.let { if (it.isAttachedToWindow) windows.removeView(it) }
        highlight = null
    }

    fun remove() {
        handler.removeCallbacksAndMessages(null)
        clearHighlight()
        if (attached) windows.removeView(root)
        attached = false
    }
}
