package com.screenmind.app.services

import android.content.Context
import com.screenmind.app.chess.BoardTracker
import com.screenmind.app.chess.FairPlayGuard
import com.screenmind.app.chess.FairPlayVerdict
import com.screenmind.app.chess.Fen
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.PositionValidator
import com.screenmind.app.chess.ScreenText
import com.screenmind.app.history.HistoryEntry
import com.screenmind.app.history.HistoryKind
import com.screenmind.app.history.HistoryStore
import com.screenmind.app.settings.Settings
import com.screenmind.app.software.IRect
import com.screenmind.app.software.OcrLine
import com.screenmind.app.software.RegionDetector
import com.screenmind.app.software.ScreenModel
import com.screenmind.app.software.UiClassifier
import com.screenmind.app.vision.BoardDetector
import com.screenmind.app.vision.OcrEngine
import com.screenmind.app.vision.PieceProfile
import com.screenmind.app.vision.PieceRecognizer
import com.screenmind.app.vision.PixelImage
import com.screenmind.app.vision.SquareFeature
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class ChessSnapshot(
    val position: Position,
    val features: List<SquareFeature>,
    val whiteAtBottom: Boolean,
    val styleName: String?,
    val unknown: Int,
    val uncertain: List<Int>,
    val turnKnown: Boolean,
    val problems: List<String>,
    val verdict: FairPlayVerdict,
    val note: String,
) {
    fun report(): String = buildString {
        if (unknown > 0) {
            append("$unknown pieces could not be named. Scan a starting position once to teach this piece style.")
            return@buildString
        }
        append(note).append('.')
        if (uncertain.isNotEmpty()) append(" Check ${uncertain.size} doubtful squares.")
        if (!turnKnown) append(" Side to move is a guess.")
        if (problems.isNotEmpty()) append(" Problem: ${problems.first()}.")
    }
}

/** Runs one analysis at a time and keeps the most recent results for the screens to show. */
object Analyzer {
    private val mutex = Mutex()
    private val ocr = OcrEngine()
    private val tracker = BoardTracker()

    @Volatile var lastScreen: ScreenModel? = null
        private set
    @Volatile var lastChess: ChessSnapshot? = null
        private set

    fun history(context: Context) = HistoryStore(File(context.filesDir, "history.jsonl"))

    private fun record(context: Context, kind: HistoryKind, title: String, detail: String) {
        if (Settings(context).saveHistory) {
            history(context).add(HistoryEntry(System.currentTimeMillis(), kind, title, detail))
        }
    }

    private fun styleDir(context: Context) = File(context.filesDir, "styles").apply { mkdirs() }

    fun styles(context: Context): List<PieceProfile> =
        (styleDir(context).listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }
            .mapNotNull { PieceProfile.parse(it.readText()) }

    fun saveStyle(context: Context, profile: PieceProfile) {
        val dir = styleDir(context)
        File(dir, "${profile.name}.txt").writeText(profile.serialise())
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(5)?.forEach { it.delete() }
    }

    fun forgetStyles(context: Context) {
        styleDir(context).listFiles()?.forEach { it.delete() }
    }

    /** Releases the text model; it reloads on the next analysis. */
    suspend fun releaseModels() = mutex.withLock { ocr.release() }

    private suspend fun text(image: PixelImage): List<OcrLine>? = try {
        ocr.read(image)
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        // ML Kit reports many unrelated failure types; analysis continues without text.
        null
    }

    /**
     * @param frame captured screen, or null when only accessibility access is available.
     * @param exclude area of the floating panel in screen pixels.
     */
    suspend fun software(
        context: Context, frame: PixelImage?, screenWidth: Int, screenHeight: Int, exclude: IRect?, keep: Boolean,
    ): String = mutex.withLock {
        val tree = ScreenAccessibilityService.instance?.snapshot()
        if (frame == null && (tree == null || tree.roots.isEmpty())) {
            return@withLock "Nothing to read. Start screen reading or enable accessibility access."
        }
        withContext(Dispatchers.Default) {
            val lines = frame?.let { text(it) }
            val kx = if (frame != null) screenWidth.toFloat() / frame.width else 1f
            val ky = if (frame != null) screenHeight.toFloat() / frame.height else 1f
            fun scale(r: IRect) =
                IRect((r.left * kx).toInt(), (r.top * ky).toInt(), (r.right * kx).toInt(), (r.bottom * ky).toInt())
            fun visible(r: IRect) = exclude == null || !exclude.contains(r.centreX, r.centreY)
            val model = UiClassifier.build(
                tree?.appName, tree?.packageName, screenWidth, screenHeight, tree?.roots ?: emptyList(),
                lines.orEmpty().map { OcrLine(it.text, scale(it.bounds)) }.filter { visible(it.bounds) },
                frame?.let { f -> RegionDetector.detect(f).map { scale(it) }.filter { visible(it) } } ?: emptyList(),
                lines != null,
            )
            lastScreen = model
            val summary = model.summary()
            if (keep) {
                val detail = summary + "\n" + model.elements.take(60).joinToString("\n") { "${it.type.label}: ${it.label}" }
                record(context, HistoryKind.SOFTWARE, model.appName ?: "Unknown app", detail)
            }
            summary
        }
    }

    suspend fun chess(context: Context, frame: PixelImage, keep: Boolean): ChessSnapshot? = mutex.withLock {
        withContext(Dispatchers.Default) {
            val board = BoardDetector.detect(frame) ?: return@withContext null
            val lines = text(frame)
            // Without text the live-game check cannot run, so engine use is refused.
            val verdict = if (lines == null) {
                FairPlayVerdict.Blocked("Text could not be read, so the live-game check could not run.")
            } else {
                FairPlayGuard.assess(lines.map { ScreenText(it.text, it.bounds.centreY.toFloat() / frame.height) })
            }
            if (verdict is FairPlayVerdict.Blocked) {
                Settings(context).engineLockedUntil = System.currentTimeMillis() + FairPlayGuard.LOCK_MILLIS
            }
            val features = PieceRecognizer.extract(frame, board)
            var reading = PieceRecognizer.read(features, styles(context))
            val startPlacement = Position.START_FEN.substringBefore(' ')
            var learned = false
            if (PieceRecognizer.looksLikeStart(features) &&
                (Fen.placement(reading.board()) != startPlacement || reading.uncertain.isNotEmpty())
            ) {
                PieceRecognizer.calibrateFromStart(features, "style-${System.currentTimeMillis()}")?.let {
                    saveStyle(context, it)
                    reading = PieceRecognizer.read(features, listOf(it))
                    learned = true
                }
            }
            val pieces: Array<Piece?> = reading.board()
            val position: Position
            var turnKnown = false
            var note = "Board found"
            if (reading.unknownCount == 0) {
                val tracked = tracker.update(pieces, reading.turnHint())
                position = tracked.position
                turnKnown = tracked.turnKnown
                note = if (learned) "Learned this piece style" else tracked.note
                if (keep) record(context, HistoryKind.CHESS, note, position.toFen())
            } else {
                position = Position(pieces, com.screenmind.app.chess.Side.WHITE, 0, null, 0, 1)
            }
            ChessSnapshot(
                position, features, reading.whiteAtBottom, reading.profileName, reading.unknownCount,
                reading.uncertain, turnKnown, PositionValidator.problems(position), verdict, note,
            ).also { lastChess = it }
        }
    }
}
