package com.screenmind.app.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.random.Random

/** A night sky with northern lights, snowy mountains, pine trees and falling snow. */
@SuppressLint("ViewConstructor")
class WinterBackground(context: Context, private val falling: Boolean) : View(context) {
    private class Flake(var x: Float, var y: Float, val radius: Float, val speed: Float, val phase: Float)
    private class Layer(val path: Path, val colour: Int)

    private val sky = Paint()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(7)
    private var flakes = emptyList<Flake>()
    private var layers = emptyList<Layer>()
    private var aurora = Path()
    private var last = 0L

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val width = w.toFloat()
        val height = h.toFloat()
        val density = resources.displayMetrics.density
        sky.shader = LinearGradient(0f, 0f, 0f, height, Color.rgb(6, 14, 32), Color.rgb(24, 62, 98), Shader.TileMode.CLAMP)
        glow.shader = LinearGradient(0f, 0f, 0f, height * 0.34f, Color.argb(0, 80, 240, 200), Color.argb(46, 90, 230, 210), Shader.TileMode.CLAMP)
        aurora = Path().apply {
            moveTo(0f, height * 0.06f)
            cubicTo(width * 0.3f, height * 0.0f, width * 0.55f, height * 0.17f, width, height * 0.05f)
            lineTo(width, height * 0.2f)
            cubicTo(width * 0.6f, height * 0.34f, width * 0.35f, height * 0.16f, 0f, height * 0.27f)
            close()
        }
        fun ridge(base: Float, rise: Float, peaks: Int) = Path().apply {
            moveTo(0f, height)
            lineTo(0f, height * base)
            for (i in 0 until peaks) {
                lineTo(width * (i + 0.5f) / peaks, height * (base - rise * (0.6f + random.nextFloat() * 0.4f)))
                lineTo(width * (i + 1f) / peaks, height * (base + random.nextFloat() * 0.02f))
            }
            lineTo(width, height)
            close()
        }
        val trees = Path()
        var x = -10f * density
        while (x < width) {
            val tall = (34f + random.nextFloat() * 46f) * density
            val half = tall * 0.28f
            val ground = height * 0.975f
            for (tier in 0..2) {
                val top = ground - tall + tier * tall * 0.25f
                val wide = half * (0.55f + tier * 0.25f)
                trees.moveTo(x, top)
                trees.lineTo(x + wide, top + tall * 0.42f)
                trees.lineTo(x - wide, top + tall * 0.42f)
                trees.close()
            }
            x += half * (1.3f + random.nextFloat())
        }
        val snow = Path().apply {
            moveTo(0f, height)
            lineTo(0f, height * 0.965f)
            cubicTo(width * 0.3f, height * 0.93f, width * 0.65f, height, width, height * 0.95f)
            lineTo(width, height)
            close()
        }
        layers = listOf(
            Layer(ridge(0.86f, 0.14f, 3), Color.argb(150, 44, 86, 128)),
            Layer(ridge(0.92f, 0.1f, 4), Color.argb(190, 26, 58, 94)),
            Layer(trees, Color.rgb(9, 30, 48)),
            Layer(snow, Color.rgb(196, 222, 244)),
        )
        flakes = List(70) {
            val radius = (0.8f + random.nextFloat() * 2.2f) * density
            Flake(random.nextFloat() * width, random.nextFloat() * height, radius, radius * 11f, random.nextFloat() * 6.28f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val width = width.toFloat()
        val height = height.toFloat()
        canvas.drawRect(0f, 0f, width, height, sky)
        canvas.drawPath(aurora, glow)
        paint.style = Paint.Style.FILL
        for (layer in layers) {
            paint.color = layer.colour
            canvas.drawPath(layer.path, paint)
        }
        val now = SystemClock.uptimeMillis()
        // A long gap (screen off) must not teleport the flakes.
        val step = if (last == 0L) 0f else minOf(now - last, 100L) / 1000f
        last = now
        val moving = falling && ValueAnimator.areAnimatorsEnabled()
        for (f in flakes) {
            if (moving) {
                f.y += f.speed * step
                f.x += kotlin.math.sin(now / 900f + f.phase) * f.radius * 4f * step
                if (f.y > height) {
                    f.y = -f.radius
                    f.x = random.nextFloat() * width
                }
            }
            paint.color = Color.argb((70 + f.radius * 20).toInt().coerceAtMost(200), 235, 246, 255)
            canvas.drawCircle(f.x, f.y, f.radius, paint)
        }
        if (moving) postInvalidateDelayed(40)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate()
    }
}
