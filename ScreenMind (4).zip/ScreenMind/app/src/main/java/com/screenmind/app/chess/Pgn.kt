package com.screenmind.app.chess

data class PgnGame(
    val headers: Map<String, String>,
    val game: Game,
    /** Set when a move could not be read; [game] holds everything before it. */
    val error: String?,
) {
    val title: String
        get() = "${headers["White"] ?: "White"} – ${headers["Black"] ?: "Black"}  ${headers["Result"] ?: ""}".trim()
}

object Pgn {
    const val MAX_CHARS = 2_000_000
    private val HEADER = Regex("^\\s*\\[(\\w+)\\s+\"((?:\\\\.|[^\"\\\\])*)\"\\s*]\\s*$")
    private val RESULTS = setOf("1-0", "0-1", "1/2-1/2", "*")

    fun parse(text: String, maxGames: Int = 50): List<PgnGame> {
        val games = ArrayList<PgnGame>()
        var headers = LinkedHashMap<String, String>()
        val body = StringBuilder()

        fun flush() {
            if (headers.isEmpty() && body.isBlank()) return
            val built = build(headers, body.toString())
            if (built.game.length > 0 || headers.isNotEmpty()) games.add(built)
            headers = LinkedHashMap()
            body.setLength(0)
        }

        var inComment = false
        for (line in text.take(MAX_CHARS).removePrefix("﻿").lineSequence()) {
            if (games.size >= maxGames) break
            val header = if (inComment) null else HEADER.matchEntire(line)
            if (header != null) {
                if (body.isNotBlank()) flush()
                headers[header.groupValues[1]] = header.groupValues[2].replace("\\\"", "\"").replace("\\\\", "\\")
            } else if (!line.startsWith("%")) {
                body.append(line).append('\n')
                for (c in line) {
                    if (c == '{') inComment = true
                    if (c == '}') inComment = false
                }
            }
        }
        if (games.size < maxGames) flush()
        return games
    }

    /** Removes comments, variations and annotation glyphs from movetext. */
    private fun tokens(body: String): List<String> {
        val clean = StringBuilder()
        var depth = 0
        var brace = false
        var lineComment = false
        for (c in body) {
            when {
                lineComment -> if (c == '\n') {
                    lineComment = false
                    clean.append(' ')
                }
                brace -> if (c == '}') brace = false
                c == '{' -> {
                    brace = true
                    clean.append(' ')
                }
                c == ';' -> lineComment = true
                c == '(' -> depth++
                c == ')' -> {
                    if (depth > 0) depth--
                    clean.append(' ')
                }
                depth == 0 -> clean.append(c)
            }
        }
        return clean.toString()
            .replace(Regex("\\$\\d+"), " ")
            .replace(Regex("(\\d+)\\.+"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() && it !in RESULTS && it.any { ch -> ch.isLetter() || ch == '0' } }
    }

    private fun build(headers: Map<String, String>, body: String): PgnGame {
        var error: String? = null
        val start = try {
            headers["FEN"]?.let { Fen.parse(it) }?.also {
                val problems = PositionValidator.problems(it)
                if (problems.isNotEmpty()) throw FenException(problems.first())
            } ?: Position.start()
        } catch (e: FenException) {
            return PgnGame(headers, Game(), "Invalid start position: ${e.message}")
        }
        val game = Game(start)
        for (token in tokens(body)) {
            if (token == "e.p.") continue
            val move = San.parse(game.current, token)
            if (move == null) {
                error = "Could not read move '$token' (move ${game.current.fullmoveNumber})"
                break
            }
            game.play(move)
        }
        return PgnGame(headers, game, error)
    }

    fun write(game: Game, headers: Map<String, String> = emptyMap()): String = buildString {
        val all = LinkedHashMap(headers)
        if (game.start.toFen() != Position.START_FEN) {
            all["SetUp"] = "1"
            all["FEN"] = game.start.toFen()
        }
        for ((k, v) in all) append('[').append(k).append(" \"").append(v.replace("\\", "\\\\").replace("\"", "\\\"")).append("\"]\n")
        if (all.isNotEmpty()) append('\n')
        for ((i, san) in game.sanList().withIndex()) {
            val p = game.positionAt(i)
            if (p.sideToMove == Side.WHITE) {
                append(p.fullmoveNumber).append(". ")
            } else if (i == 0) {
                append(p.fullmoveNumber).append("... ")
            }
            append(san).append(' ')
        }
        append(all["Result"] ?: "*").append('\n')
    }
}
