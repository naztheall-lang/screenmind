package com.screenmind.app.engine

import android.content.Context
import java.io.File

object EngineProvider {
    /** Android only allows executing binaries that were installed in the native library folder. */
    private fun binary(context: Context) = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")

    fun hasStockfish(context: Context): Boolean = binary(context).canExecute()

    fun create(context: Context): ChessEngine =
        if (hasStockfish(context)) FallbackEngine(StockfishEngine(binary(context)), BuiltinEngine()) else BuiltinEngine()
}
