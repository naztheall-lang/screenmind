package com.screenmind.app.chess

/** A line of on-screen text with its vertical centre as a fraction of screen height. */
data class ScreenText(val text: String, val yFraction: Float)

sealed class FairPlayVerdict {
    /** The screen looks like a game still being played. Engine help is refused. */
    data class Blocked(val reason: String) : FairPlayVerdict()

    /** No live-game signs; the user must still confirm this is practice or review. */
    data class NeedsConfirmation(val note: String) : FairPlayVerdict()
}

/**
 * Heuristic protection against using ScreenMind during live competitive games.
 * It errs towards refusing. It cannot detect every platform, which is why the overlay
 * never shows engine moves at all and review needs an explicit confirmation.
 */
object FairPlayGuard {
    const val LOCK_MILLIS = 3 * 60 * 1000L

    private val CLOCK = Regex("^\\W{0,2}(\\d{1,2}:)?[0-5]?\\d:[0-5]\\d(\\.\\d)?$|^\\W{0,2}0?:?[0-5]?\\d\\.\\d$")
    private val FINISHED = listOf(
        "game over", "you won", "you lost", "white wins", "black wins", "white won", "black won",
        "won by", "won on time", "by checkmate", "by resignation", "by timeout", "game review",
        "rematch", "game drawn", "draw by", "white is victorious", "black is victorious",
    )
    private val LIVE = listOf(
        Regex("\\bresign\\b"), Regex("\\boffer draw\\b"), Regex("\\bdraw offer\\b"), Regex("\\babort\\b"),
        Regex("\\byour (turn|move)\\b"), Regex("\\btake ?back\\b"), Regex("\\bberserk\\b"), Regex("waiting for opponent"),
    )

    fun assess(texts: List<ScreenText>): FairPlayVerdict {
        // The top strip holds the phone's own clock, which must not count as a chess clock.
        val body = texts.filter { it.yFraction > 0.05f }
        val joined = body.joinToString("\n") { it.text.lowercase() }
        val finished = FINISHED.firstOrNull { it in joined }
        if (finished != null) {
            return FairPlayVerdict.NeedsConfirmation("This game appears to be over (\"$finished\").")
        }
        val live = LIVE.firstOrNull { it.containsMatchIn(joined) }
        if (live != null) {
            return FairPlayVerdict.Blocked("Live-game controls are visible (\"${live.find(joined)?.value}\").")
        }
        val clocks = body.count { CLOCK.matches(it.text.trim()) }
        if (clocks >= 2) return FairPlayVerdict.Blocked("Two game clocks are visible.")
        return FairPlayVerdict.NeedsConfirmation("No live-game signs were found.")
    }

    /** Assistant questions that ask for a move. */
    fun asksForMove(question: String): Boolean {
        val q = question.lowercase()
        return Regex(
            "(best|next|good|winning|which|what) (chess )?move|what (should|do|would|can) (i|you) (play|move)|" +
                "(should i|can i) (take|capture|castle|move)|how (do|can) i (win|checkmate|mate)|hint for (this|the) (game|position)|" +
                "(analyse|analyze|evaluate|solve) (this|the|my) (position|board|game)"
        ).containsMatchIn(q)
    }
}
