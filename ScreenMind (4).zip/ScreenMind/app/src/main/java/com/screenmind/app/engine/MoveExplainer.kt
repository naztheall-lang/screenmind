package com.screenmind.app.engine

import com.screenmind.app.chess.Move
import com.screenmind.app.chess.MoveGen
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.San
import com.screenmind.app.chess.Side
import com.screenmind.app.chess.Squares
import java.util.Locale

/** Explains a candidate move from facts on the board. It never invents plans it cannot verify. */
object MoveExplainer {
    fun explain(position: Position, line: CandidateLine, best: CandidateLine? = null): String {
        val move = line.move
        val piece = position[move.from] ?: return ""
        val after = position.apply(move)
        val us = position.sideToMove
        val them = us.other
        val points = ArrayList<String>()

        if (after.legalMoves().isEmpty()) {
            return if (after.isInCheck()) "Delivers checkmate." else "Stalemates the opponent, so the game is drawn."
        }

        val enPassantCapture = piece.type == PieceType.PAWN && move.to == position.enPassant
        val victim = position[move.to] ?: if (enPassantCapture) Piece(them, PieceType.PAWN) else null

        if (piece.type == PieceType.KING && kotlin.math.abs(move.to - move.from) == 2) {
            points.add("Castles, moving the king to safety and bringing a rook into play.")
        }
        if (move.promotion != null) points.add("Promotes the pawn to a ${move.promotion.word}.")
        if (victim != null) {
            val defended = MoveGen.attackers(after, move.to, them).isNotEmpty()
            val where = Squares.name(move.to)
            points.add(
                when {
                    enPassantCapture -> "Captures the pawn en passant."
                    !defended -> "Wins the undefended ${victim.type.word} on $where."
                    victim.type.value > piece.type.value + 50 -> "Takes the ${victim.type.word} on $where with a less valuable piece."
                    victim.type.value >= piece.type.value - 50 -> "Trades on $where."
                    else -> "Captures the ${victim.type.word} on $where, giving up material if recaptured."
                }
            )
        }
        if (after.isInCheck()) points.add("Gives check.")

        val targets = attackedBy(after, move.to, us).filter { square ->
            val t = after[square] ?: return@filter false
            t.type == PieceType.KING || t.type.value > piece.type.value + 50 ||
                (t.type != PieceType.PAWN && MoveGen.attackers(after, square, them).isEmpty())
        }
        val destinationAttackers = MoveGen.attackers(after, move.to, them)
        val destinationDefenders = MoveGen.attackers(after, move.to, us)
        val exposed = destinationAttackers.isNotEmpty() &&
            (destinationDefenders.isEmpty() || destinationAttackers.any { (after[it]?.type?.value ?: 0) in 1 until piece.type.value })
        if (targets.size >= 2 && !exposed) {
            points.add("Forks the " + targets.joinToString(" and the ") { "${after[it]!!.type.word} on ${Squares.name(it)}" } + ".")
        } else if (targets.size == 1 && after[targets[0]]!!.type != PieceType.KING) {
            points.add("Attacks the ${after[targets[0]]!!.type.word} on ${Squares.name(targets[0])}.")
        }

        val wasThreatened = MoveGen.attackers(position, move.from, them).let { list ->
            list.isNotEmpty() && (MoveGen.attackers(position, move.from, us).isEmpty() ||
                list.any { (position[it]?.type?.value ?: 0) in 1 until piece.type.value })
        }
        if (wasThreatened && !exposed && piece.type != PieceType.KING) points.add("Moves the threatened ${piece.type.word} to safety.")
        if (exposed && victim == null && move.promotion == null) {
            points.add("The ${piece.type.word} can be captured on ${Squares.name(move.to)}; check the follow-up line.")
        }

        if (points.isEmpty()) {
            val homeRank = if (us == Side.WHITE) 0 else 7
            val file = Squares.file(move.to)
            val rank = Squares.rank(move.to)
            points.add(
                when {
                    (piece.type == PieceType.KNIGHT || piece.type == PieceType.BISHOP) && Squares.rank(move.from) == homeRank ->
                        "Develops the ${piece.type.word}."
                    piece.type == PieceType.PAWN && file in 3..4 && rank in 2..5 -> "Takes space in the centre."
                    piece.type == PieceType.PAWN && isPassed(after, move.to, us) -> "Advances a passed pawn."
                    piece.type == PieceType.ROOK && (0..7).none { after[Squares.of(file, it)]?.type == PieceType.PAWN } ->
                        "Puts the rook on an open file."
                    piece.type == PieceType.KING -> "Repositions the king."
                    file in 2..5 && rank in 2..5 -> "Brings the ${piece.type.word} towards the centre."
                    else -> "A quiet move that improves the ${piece.type.word}'s placement."
                }
            )
        }

        val mate = line.score.mateIn
        if (mate != null) {
            points.add(if (mate > 0) "Forces mate in $mate." else "The opponent can force mate in ${-mate}.")
        } else if (best != null && best.rank != line.rank) {
            val gap = best.score.value() - line.score.value()
            points.add(
                when {
                    gap <= 20 -> "About as good as the first choice."
                    best.score.mateIn != null -> "Misses a faster route: the first choice forces mate."
                    else -> "About ${String.format(Locale.US, "%.1f", gap / 100.0)} pawns worse than the first choice."
                }
            )
        }
        return points.joinToString(" ")
    }

    private fun attackedBy(p: Position, from: Int, side: Side): List<Int> =
        (0 until 64).filter { p[it]?.side == side.other && from in MoveGen.attackers(p, it, side) }

    private fun isPassed(p: Position, square: Int, side: Side): Boolean {
        val file = Squares.file(square)
        val rank = Squares.rank(square)
        val ahead = if (side == Side.WHITE) rank + 1..7 else 0 until rank
        for (f in maxOf(0, file - 1)..minOf(7, file + 1)) {
            for (r in ahead) if (p[Squares.of(f, r)] == Piece(side.other, PieceType.PAWN)) return false
        }
        return true
    }

    fun describe(score: Score, sideToMove: Side): String {
        val mate = score.mateIn
        if (mate != null) {
            val winner = if (mate > 0) sideToMove else sideToMove.other
            return "${winner.title} has a forced mate"
        }
        val white = (score.centipawns ?: 0) * if (sideToMove == Side.WHITE) 1 else -1
        val side = if (white > 0) "White" else "Black"
        return when (kotlin.math.abs(white)) {
            in 0..30 -> "The position is about equal"
            in 31..90 -> "$side is slightly better"
            in 91..250 -> "$side is clearly better"
            else -> "$side is winning"
        }
    }

    fun title(position: Position, line: CandidateLine): String =
        "${San.write(position, line.move)}  (${line.score.display(position.sideToMove)})"

    fun moveLine(position: Position, moves: List<Move>): String = San.line(position, moves)
}
