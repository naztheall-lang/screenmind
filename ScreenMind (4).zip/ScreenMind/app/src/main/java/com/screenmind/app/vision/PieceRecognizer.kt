package com.screenmind.app.vision

import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Side
import com.screenmind.app.chess.Squares

private const val N = 32

/** Shape and shading of whatever stands on one square, resampled to a fixed grid. */
class SquareFeature(val mask: BooleanArray, val luma: ByteArray, val medianLuma: Int, val background: Int) {
    val occupied: Boolean get() = medianLuma >= 0
}

class Template(val piece: Piece, val feature: SquareFeature)

/** Examples of one piece style ("theme"), learned from the user's own screen. */
class PieceProfile(val name: String, val templates: List<Template>) {
    fun serialise(): String = buildString {
        append(name.replace('\n', ' ')).append('\n')
        for (t in templates) {
            append(t.piece.fenChar).append(' ').append(t.feature.medianLuma).append(' ')
            for (i in 0 until N * N) {
                val v = if (t.feature.mask[i]) 1 + (t.feature.luma[i].toInt() and 255) * 253 / 255 else 0
                append(HEX[v shr 4]).append(HEX[v and 15])
            }
            append('\n')
        }
    }

    companion object {
        private const val HEX = "0123456789abcdef"

        fun parse(text: String): PieceProfile? {
            val lines = text.lines().filter { it.isNotBlank() }
            val templates = lines.drop(1).mapNotNull { line ->
                val p = line.split(' ')
                val piece = p.getOrNull(0)?.firstOrNull()?.let { Piece.fromFen(it) } ?: return@mapNotNull null
                val median = p.getOrNull(1)?.toIntOrNull() ?: return@mapNotNull null
                val data = p.getOrNull(2)?.takeIf { it.length == N * N * 2 } ?: return@mapNotNull null
                val mask = BooleanArray(N * N)
                val luma = ByteArray(N * N)
                for (i in 0 until N * N) {
                    val v = HEX.indexOf(data[i * 2]) * 16 + HEX.indexOf(data[i * 2 + 1])
                    if (v > 0) {
                        mask[i] = true
                        luma[i] = ((v - 1) * 255 / 253).toByte()
                    }
                }
                Template(piece, SquareFeature(mask, luma, median, 0))
            }
            return if (templates.isEmpty()) null else PieceProfile(lines[0], templates)
        }
    }
}

data class RecognisedSquare(
    val occupied: Boolean,
    /** Null for an empty square, or when no learned style can name the piece. */
    val piece: Piece?,
    val side: Side?,
    val confidence: Float,
)

data class BoardReading(
    /** Screen order: index = row * 8 + column, row 0 at the top. */
    val squares: List<RecognisedSquare>,
    val whiteAtBottom: Boolean,
    val profileName: String?,
    val highlighted: List<Int>,
) {
    val unknownCount: Int get() = squares.count { it.occupied && it.piece == null }

    /** Board squares (a1 = 0) whose identification should be checked by the user. */
    val uncertain: List<Int>
        get() = squares.indices.filter { squares[it].occupied && squares[it].confidence < PieceRecognizer.SURE }
            .map { PieceRecognizer.toSquare(it, whiteAtBottom) }

    fun board(): Array<Piece?> {
        val out = arrayOfNulls<Piece>(64)
        for (i in 0 until 64) out[PieceRecognizer.toSquare(i, whiteAtBottom)] = squares[i].piece
        return out
    }

    /** The side to move if a two-square last-move highlight shows who just moved. */
    fun turnHint(): Side? {
        if (highlighted.size != 2) return null
        val mover = highlighted.mapNotNull { squares[it].side }.singleOrNull() ?: return null
        return mover.other
    }
}

object PieceRecognizer {
    const val SURE = 0.72f
    private const val MINIMUM = 0.5f

    fun toSquare(screenIndex: Int, whiteAtBottom: Boolean): Int {
        val row = screenIndex / 8
        val col = screenIndex % 8
        return if (whiteAtBottom) Squares.of(col, 7 - row) else Squares.of(7 - col, row)
    }

    fun extract(image: PixelImage, board: BoardLocation): List<SquareFeature> = List(64) { i ->
        square(image, board.left + i % 8 * board.square, board.top + i / 8 * board.square, board.square)
    }

    private fun square(img: PixelImage, left: Float, top: Float, s: Float): SquareFeature {
        val bg = BoardDetector.squareColour(img, left, top, s)
        val colour = IntArray(N * N)
        for (y in 0 until N) for (x in 0 until N) {
            // 3% inset keeps neighbouring squares and grid lines out.
            val px = (left + s * (0.03f + 0.94f * (x + 0.5f) / N)).toInt().coerceIn(0, img.width - 1)
            val py = (top + s * (0.03f + 0.94f * (y + 0.5f) / N)).toInt().coerceIn(0, img.height - 1)
            colour[y * N + x] = img[px, py]
        }
        val differs = BooleanArray(N * N) { Colors.distance(colour[it], bg) > 22 }

        // Everything not reachable from the border through background is part of the piece.
        val outside = BooleanArray(N * N)
        val stack = IntArray(N * N)
        var top0 = 0
        fun visit(i: Int) {
            if (!outside[i] && !differs[i]) {
                outside[i] = true
                stack[top0++] = i
            }
        }
        for (k in 0 until N) {
            visit(k)
            visit((N - 1) * N + k)
            visit(k * N)
            visit(k * N + N - 1)
        }
        while (top0 > 0) {
            val i = stack[--top0]
            if (i % N > 0) visit(i - 1)
            if (i % N < N - 1) visit(i + 1)
            if (i >= N) visit(i - N)
            if (i < N * N - N) visit(i + N)
        }

        // Keep the largest blob, which discards coordinate labels and move dots.
        val label = IntArray(N * N)
        var bestLabel = 0
        var bestSize = 0
        var next = 0
        for (start in 0 until N * N) {
            if (outside[start] || label[start] != 0) continue
            next++
            var size = 0
            var n = 0
            label[start] = next
            stack[n++] = start
            while (n > 0) {
                val i = stack[--n]
                size++
                fun join(j: Int) {
                    if (!outside[j] && label[j] == 0) {
                        label[j] = next
                        stack[n++] = j
                    }
                }
                if (i % N > 0) join(i - 1)
                if (i % N < N - 1) join(i + 1)
                if (i >= N) join(i - N)
                if (i < N * N - N) join(i + N)
            }
            if (size > bestSize) {
                bestSize = size
                bestLabel = next
            }
        }
        val mask = BooleanArray(N * N) { bestSize > 0 && label[it] == bestLabel }
        val luma = ByteArray(N * N)
        val values = IntArray(bestSize)
        var n = 0
        for (i in 0 until N * N) if (mask[i]) {
            val l = Colors.luma(colour[i])
            luma[i] = l.toByte()
            values[n++] = l
        }
        values.sort()
        // A piece covers a good part of the square and sits near its middle.
        val centre = (N / 3 until 2 * N / 3).sumOf { y -> (N / 3 until 2 * N / 3).count { x -> mask[y * N + x] } }
        val occupied = bestSize > N * N * 0.09 && centre > (N / 3) * (N / 3) * 0.3
        return SquareFeature(mask, luma, if (occupied) values[n / 2] else -1, bg)
    }

    fun similarity(a: SquareFeature, b: SquareFeature): Float {
        var best = 0f
        for (dy in -1..1) for (dx in -1..1) {
            var inter = 0
            var union = 0
            var diff = 0
            for (y in 0 until N) for (x in 0 until N) {
                val i = y * N + x
                val bx = x + dx
                val by = y + dy
                val j = by * N + bx
                val inA = a.mask[i]
                val inB = bx in 0 until N && by in 0 until N && b.mask[j]
                if (inA && inB) {
                    inter++
                    diff += kotlin.math.abs((a.luma[i].toInt() and 255) - (b.luma[j].toInt() and 255))
                }
                if (inA || inB) union++
            }
            if (inter == 0) continue
            val score = 0.75f * inter / union + 0.25f * (1f - diff / (inter * 255f))
            best = maxOf(best, score)
        }
        return best
    }

    private class Match(val piece: Piece?, val side: Side, val score: Float)

    private fun classify(f: SquareFeature, profile: PieceProfile?): Match {
        if (profile == null) return Match(null, if (f.medianLuma > 135) Side.WHITE else Side.BLACK, 0.3f)
        fun typical(side: Side): Double? =
            profile.templates.filter { it.piece.side == side }.map { it.feature.medianLuma }.takeIf { it.isNotEmpty() }?.average()
        val white = typical(Side.WHITE)
        val black = typical(Side.BLACK)
        val side = if (white != null && black != null) {
            if (kotlin.math.abs(f.medianLuma - white) < kotlin.math.abs(f.medianLuma - black)) Side.WHITE else Side.BLACK
        } else if (f.medianLuma > 135) Side.WHITE else Side.BLACK
        val scores = HashMap<PieceType, Float>()
        for (t in profile.templates) {
            if (t.piece.side != side) continue
            val s = similarity(f, t.feature)
            if (s > (scores[t.piece.type] ?: 0f)) scores[t.piece.type] = s
        }
        val ranked = scores.entries.sortedByDescending { it.value }
        val first = ranked.firstOrNull() ?: return Match(null, side, 0f)
        if (first.value < MINIMUM) return Match(null, side, first.value)
        // Two near-equal types means the answer is doubtful even if both match well.
        val margin = first.value - (ranked.getOrNull(1)?.value ?: 0f)
        val confidence = if (margin < 0.03f) minOf(first.value, SURE - 0.05f) else first.value
        return Match(Piece(side, first.key), side, confidence)
    }

    /**
     * @param whiteAtBottom force the orientation, or null to infer it.
     */
    fun read(features: List<SquareFeature>, profiles: List<PieceProfile>, whiteAtBottom: Boolean? = null): BoardReading {
        var chosen: PieceProfile? = null
        var matches: List<Match?> = features.map { if (it.occupied) classify(it, null) else null }
        var bestTotal = -1.0
        for (profile in profiles) {
            val m = features.map { if (it.occupied) classify(it, profile) else null }
            val total = m.filterNotNull().map { if (it.piece == null) 0.0 else it.score.toDouble() }.sum()
            if (total > bestTotal) {
                bestTotal = total
                chosen = profile
                matches = m
            }
        }
        val squares = matches.map {
            if (it == null) RecognisedSquare(false, null, null, 1f) else RecognisedSquare(true, it.piece, it.side, it.score)
        }
        return BoardReading(squares, whiteAtBottom ?: inferOrientation(squares), chosen?.name, highlights(features))
    }

    private fun inferOrientation(squares: List<RecognisedSquare>): Boolean {
        fun meanRow(side: Side, type: PieceType): Double? =
            squares.indices.filter { squares[it].piece == Piece(side, type) }.map { it / 8 }.takeIf { it.isNotEmpty() }?.average()
        for (type in listOf(PieceType.PAWN, PieceType.KING)) {
            val w = meanRow(Side.WHITE, type)
            val b = meanRow(Side.BLACK, type)
            if (w != null && b != null && w != b) return w > b
        }
        fun anyRow(side: Side) = squares.indices.filter { squares[it].side == side }.map { it / 8 }.takeIf { it.isNotEmpty() }?.average()
        val w = anyRow(Side.WHITE)
        val b = anyRow(Side.BLACK)
        return w == null || b == null || w >= b
    }

    private fun highlights(features: List<SquareFeature>): List<Int> {
        val medians = Array(2) { parity ->
            Colors.median(features.filterIndexed { i, _ -> (i % 8 + i / 8) % 2 == parity }.map { it.background }.toIntArray())
        }
        return features.indices.filter { Colors.distance(features[it].background, medians[(it % 8 + it / 8) % 2]) > 22 }
    }

    /** True when the occupied squares look like the initial set-up (two full ranks at each end). */
    fun looksLikeStart(features: List<SquareFeature>): Boolean =
        features.indices.all { features[it].occupied == (it / 8 < 2 || it / 8 > 5) }

    /** Learns a piece style from a screenshot of the starting position. */
    fun calibrateFromStart(features: List<SquareFeature>, name: String): PieceProfile? {
        if (!looksLikeStart(features)) return null
        val topLuma = (0 until 16).map { features[it].medianLuma }.average()
        val bottomLuma = (48 until 64).map { features[it].medianLuma }.average()
        if (kotlin.math.abs(topLuma - bottomLuma) < 25) return null
        val whiteBottom = bottomLuma > topLuma
        val back = arrayOf(
            PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN,
            PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK,
        )
        val templates = features.indices.filter { features[it].occupied }.map { i ->
            val square = toSquare(i, whiteBottom)
            val rank = Squares.rank(square)
            val type = if (rank == 1 || rank == 6) PieceType.PAWN else back[Squares.file(square)]
            Template(Piece(if (rank < 2) Side.WHITE else Side.BLACK, type), features[i])
        }
        return PieceProfile(name, templates)
    }

    /** Adds corrected examples, so recognition improves when the user fixes a mistake. */
    fun learn(profile: PieceProfile, features: List<SquareFeature>, board: Array<Piece?>, whiteAtBottom: Boolean): PieceProfile {
        val added = features.indices.mapNotNull { i ->
            val piece = board[toSquare(i, whiteAtBottom)]
            if (piece == null || !features[i].occupied) return@mapNotNull null
            val known = profile.templates.any { it.piece == piece && similarity(features[i], it.feature) > 0.9f }
            if (known) null else Template(piece, features[i])
        }
        // Keep the newest examples per piece to bound memory and matching time.
        val all = (added + profile.templates).groupBy { it.piece }.values.flatMap { it.take(6) }
        return PieceProfile(profile.name, all)
    }
}
