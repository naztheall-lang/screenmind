package com.screenmind.app.ui

import android.app.Activity
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import com.screenmind.app.settings.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel

/** Presses a view down slightly while touched, without consuming the click. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        val down = e.actionMasked == MotionEvent.ACTION_DOWN
        if (down || e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            v.animate().scaleX(if (down) 0.96f else 1f).scaleY(if (down) 0.96f else 1f).setDuration(90).start()
        }
        false
    }
}

/** The winter design system: night-blue skies, frosted glass cards and ice-blue accents. */
object Ui {
    val BG = Color.rgb(10, 20, 38)
    val SURFACE = Color.argb(214, 20, 40, 70)
    val LINE = Color.argb(105, 150, 206, 245)
    val TEXT = Color.rgb(238, 247, 255)
    val MUTED = Color.rgb(160, 188, 216)
    val ACCENT = Color.rgb(125, 211, 252)
    val ACCENT_DARK = Color.rgb(45, 120, 180)
    val FROST = Color.rgb(224, 244, 255)
    val WARN = Color.rgb(255, 188, 128)
    val BRILLIANT = Color.rgb(94, 240, 214)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun text(c: Context, value: CharSequence, sp: Float = 15f, colour: Int = TEXT): TextView = TextView(c).apply {
        text = value
        textSize = sp
        setTextColor(colour)
    }

    fun box(c: Context, fill: Int, border: Int = LINE) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(c, 1), border)
        cornerRadius = dp(c, 18).toFloat()
    }

    /** A top-to-bottom gradient with a frosted edge. */
    fun frost(c: Context, top: Int, bottom: Int, border: Int = LINE) =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            setStroke(dp(c, 1), border)
            cornerRadius = dp(c, 18).toFloat()
        }

    fun panel(c: Context, border: Int = LINE) = frost(c, Color.argb(224, 36, 66, 108), Color.argb(214, 15, 31, 58), border)
}

abstract class BaseActivity : Activity() {
    protected val scope = MainScope()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    protected fun page(title: String, snow: Boolean = true): LinearLayout {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(context, 16)
            setPadding(p, p, p, p)
        }
        column.add(Ui.text(this, title, 28f, Ui.FROST).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
            setShadowLayer(18f, 0f, 0f, Ui.ACCENT)
        }, bottom = 2)
        column.add(Ui.text(this, "❄  ·  ·  ·", 13f, Ui.ACCENT), bottom = 10)
        val scroll = ScrollView(this).apply { addView(column) }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Ui.BG)
            addView(WinterBackground(context, snow && Settings(context).snow))
            addView(scroll.apply { fitsSystemWindows = true })
        })
        return column
    }

    /** A menu entry with a picture; [wide] puts the picture beside the words. */
    protected fun tile(icon: Int, title: String, detail: String, wide: Boolean = false, onClick: () -> Unit): LinearLayout {
        val entry = LinearLayout(this).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.panel(context)
            val p = Ui.dp(context, 15)
            setPadding(p, p, p, p)
            setOnClickListener { onClick() }
            pressable()
        }
        val picture = ImageView(this).apply { setImageResource(icon) }
        val size = Ui.dp(this, if (wide) 54 else 32)
        entry.addView(picture, LinearLayout.LayoutParams(size, size))
        val words = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        words.addView(Ui.text(this, title, if (wide) 20f else 16f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        words.addView(Ui.text(this, detail, 13f, Ui.MUTED))
        val across = if (wide) 0 else LinearLayout.LayoutParams.WRAP_CONTENT
        entry.addView(words, LinearLayout.LayoutParams(across, LinearLayout.LayoutParams.WRAP_CONTENT, if (wide) 1f else 0f).apply {
            if (wide) leftMargin = Ui.dp(this@BaseActivity, 14) else topMargin = Ui.dp(this@BaseActivity, 8)
        })
        return entry
    }

    protected fun <T : View> LinearLayout.add(view: T, top: Int = 0, bottom: Int = 8): T {
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.topMargin = Ui.dp(context, top)
        p.bottomMargin = Ui.dp(context, bottom)
        addView(view, p)
        // Items rise into place one after another.
        view.alpha = 0f
        view.translationY = Ui.dp(context, 14).toFloat()
        view.animate().alpha(1f).translationY(0f).setStartDelay(minOf(childCount, 10) * 30L).setDuration(220).start()
        return view
    }

    protected fun LinearLayout.heading(value: String) =
        add(Ui.text(context, value.uppercase(), 12f, Ui.MUTED).apply { letterSpacing = 0.08f }, top = 12, bottom = 6)

    protected fun LinearLayout.note(value: CharSequence, colour: Int = Ui.MUTED) = add(Ui.text(context, value, 14f, colour))

    protected fun button(label: String, primary: Boolean = false, onClick: () -> Unit): TextView =
        Ui.text(this, label, 14f, if (primary) Ui.BG else Ui.TEXT).apply {
            gravity = Gravity.CENTER
            minHeight = Ui.dp(context, 50)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8))
            val face = if (primary) Ui.frost(context, Ui.FROST, Ui.ACCENT, Ui.FROST) else Ui.panel(context)
            val under = Ui.box(context, if (primary) Ui.ACCENT_DARK else Color.argb(160, 5, 12, 26), Color.TRANSPARENT)
            background = LayerDrawable(arrayOf(under, face)).apply {
                // The darker layer shows below the face, giving the button some depth.
                setLayerInset(1, 0, 0, 0, Ui.dp(context, 3))
            }
            pressable()
            isFocusable = true
            setOnClickListener { onClick() }
        }

    protected fun card(title: String, detail: String, onClick: (() -> Unit)? = null): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.panel(context)
            val p = Ui.dp(context, 15)
            setPadding(p, p, p, p)
            addView(Ui.text(context, title, 16f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
            if (detail.isNotEmpty()) addView(Ui.text(context, detail, 13f, Ui.MUTED))
            if (onClick != null) {
                setOnClickListener { onClick() }
                pressable()
            }
        }

    protected fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        for ((i, v) in views.withIndex()) {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) p.leftMargin = Ui.dp(context, 6)
            addView(v, p)
        }
    }

    protected fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(this).apply {
        text = label
        setTextColor(Ui.TEXT)
        textSize = 15f
        isChecked = value
        minHeight = Ui.dp(context, 44)
        setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    protected fun input(hint: String, value: String = "", lines: Int = 1, secret: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or when {
                secret -> InputType.TYPE_TEXT_VARIATION_PASSWORD
                lines > 1 -> InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> 0
            }
            if (lines > 1) {
                minLines = lines
                maxLines = lines * 2
                gravity = Gravity.TOP
            }
        }

    protected fun choose(title: String, options: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(options.toTypedArray()) { _, i -> onPick(i) }.show()
    }

    protected fun message(title: String, body: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("Close", null).show()
    }

    protected fun confirm(title: String, body: String, yes: String, onYes: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body)
            .setPositiveButton(yes) { _, _ -> onYes() }.setNegativeButton("Cancel", null).show()
    }

    protected fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
