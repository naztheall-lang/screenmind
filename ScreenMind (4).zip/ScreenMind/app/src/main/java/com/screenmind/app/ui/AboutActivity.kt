package com.screenmind.app.ui

import android.os.Build
import android.os.Bundle
import com.screenmind.app.engine.EngineProvider

class AboutActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = page("About and permissions")
        page.note("ScreenMind ${packageManager.getPackageInfo(packageName, 0).versionName}", Ui.TEXT)
        page.note("Engine: " + if (EngineProvider.hasStockfish(this)) "Stockfish (on device)" else "basic built-in engine only — Stockfish is not in this build")
        page.note("Processors: ${Build.SUPPORTED_ABIS.joinToString()} · Android ${Build.VERSION.RELEASE}")
        page.heading("What the permissions do")
        page.add(card("Screen capture", "Android asks every time. A notification stays visible while reading. Pictures are processed in memory and not saved."))
        page.add(card("Display over other apps", "Draws the floating panel and outlines."))
        page.add(card("Accessibility", "Optional. Reads the visible interface when you ask. No taps, typing or password contents."))
        page.add(card("Internet", "Used only for the online AI you enable and confirm. Google's ML Kit library may send its own usage diagnostics; text recognition itself runs on the phone."))
        page.heading("Limits")
        page.note(
            "Recognition can be wrong, especially without accessibility access, with non-Latin text, games, videos or custom drawn screens. " +
                "Apps that block capture appear black. Chess piece styles must be learned from a starting position. " +
                "The live-game check is a heuristic: using engine help during a rated or competitive game is cheating."
        )
        page.heading("Licences")
        page.note("Stockfish is GPL v3 (stockfishchess.org); ScreenMind is released under GPL v3 so builds that include it can be shared with source. Google ML Kit and Kotlin coroutines have their own licences.")
    }
}
