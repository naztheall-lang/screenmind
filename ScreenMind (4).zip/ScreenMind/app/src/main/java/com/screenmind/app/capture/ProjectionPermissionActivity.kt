package com.screenmind.app.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import com.screenmind.app.services.SessionService

/** Shows Android's own screen-capture consent dialog. Nothing is captured unless the user agrees. */
class ProjectionPermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST)
        }
    }

    @Deprecated("Framework callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQUEST) return
        if (resultCode == RESULT_OK && data != null) {
            SessionService.startCapture(this, resultCode, data)
        } else {
            Toast.makeText(this, "Screen reading was not allowed", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private companion object {
        const val REQUEST = 1
    }
}
