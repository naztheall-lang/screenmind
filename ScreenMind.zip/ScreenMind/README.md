# ScreenMind

On-device screen assistant for Android 10+ with two modes: chess review/practice and software recognition.
Target phone: Honor X7a (Helio G37, 4 GB, Android 14).

## Status — read first
| What | Checked? |
|---|---|
| Chess rules, PGN, tracking, fair-play guard, built-in engine, board/piece vision, recognition, assistant, history | 32 unit tests pass (plain JVM) |
| Android code (capture, overlay, accessibility, OCR, screens) | Type-checked only against hand-written stand-ins for the Android APIs |
| Gradle build, APK, Stockfish download, anything on a real phone | **Not run.** No Android SDK was available |
| Piece recognition on real chess apps | **Not tested.** Tests use synthetic boards drawn with ScreenMind's own pieces |

Expect that the first build or first run may reveal something to fix.

## Build the APK from your phone (free, GitHub Actions)
1. Create a free account at github.com, then a new repository (any name).
2. In the repository choose **uploading an existing file**, select `ScreenMind.zip`, and commit.
3. Choose **Add file > Create new file**. Type the name `.github/workflows/build-apk.yml`
   (the slashes create the folders), paste the contents of the supplied `build-apk.yml`, and commit.
4. Open the **Actions** tab and wait for "Build APK" to finish (several minutes).
5. Open the finished run and download the **ScreenMind-apk** artifact. Extract it in your Files app.

If the run fails, open the red step and copy the first lines containing `error` or `e:`.
The unzip step overwrites files with those in `ScreenMind.zip`, so to change code upload a new zip
(or delete the zip after extracting the project into the repository).

Private repositories have a monthly free-minutes limit; check GitHub's current terms.

## Build on a computer instead
Android Studio (JDK 17, SDK 35): open this folder, then
```
bash scripts/fetch_stockfish.sh
./gradlew testDebugUnitTest assembleDebug
```
APKs appear in `app/build/outputs/apk/debug/`. Without the script the app still builds, using only the weak
built-in engine. AndroidIDE was archived in 2024; neither it nor its successor has been tried.

## Install on the Honor X7a
1. Tap `app-arm64-v8a-debug.apk`. Allow "install unknown apps" for your Files app when asked.
   If it says the app is not compatible, use `app-armeabi-v7a-debug.apk`.
2. Open ScreenMind > **Screen-reading controls**.
3. Allow **Display over other apps** and **Notifications**.
4. Optional but recommended: **Accessibility access**. If greyed out: App info > ⋮ > **Allow restricted settings**.
5. If the panel disappears: phone Settings > Battery > App launch > ScreenMind > manage manually, allow background activity
   (menu names vary between MagicOS versions).

Each cloud build is signed with a new debug key, so uninstall the old copy before installing a newer build.
This also erases history and learned piece styles.

## Use
**Software mode:** show the panel, tap Start (Android asks permission; choose the whole screen), open another app,
tap **Analyse**, then **Ask** ("Where is the export button?"). "Show on screen" outlines the control.
With accessibility enabled, analysis also works without screen capture.

**Chess mode:**
1. Teach each piece style once: show a board in the **starting position** and tap Analyse.
2. After a game, or on a practice position, tap Analyse then **Review**. Confirm it is not live.
3. Fix wrong squares with **Edit board**, then **Save corrections to piece style**.
4. **Analyse position** gives up to five moves with explanations. **Review game** grades an imported PGN.

**Fair play:** the panel never shows moves or evaluations. The engine will not run while the screen is being read,
and locks for 3 minutes if resign/draw controls or two clocks are seen. This is a heuristic, not a guarantee.
Engine help during a live competitive game is cheating.

## Performance profiles
| Profile | Capture width | Auto check | Depth / time cap | Threads | Hash |
|---|---|---|---|---|---|
| Battery saver | 540 | 3 s | 10 / 3 s | 1 | 16 MB |
| Balanced | 720 | 1.5 s | 14 / 6 s | 2 | 32 MB |
| Performance | 1080 | 0.7 s | 18 / 10 s | 4 | 64 MB |

Search stops at whichever limit comes first. These are untuned starting values. Stockfish's network is large,
so expect high memory use while it runs; it is closed when you leave the chess screen.

## Design notes
- No OpenCV or ONNX Runtime: board finding and piece matching are Kotlin (`vision/`), keeping size and memory down.
  Pieces are recognised by shape and shading against examples learned from your screen.
- Dependencies: Kotlin coroutines, ML Kit bundled Latin text recognition.
- The offline assistant is rule-based (`software/Knowledge.kt`), not a language model. It says when it is unsure.
- Optional online AI: any OpenAI-compatible https endpoint. Off by default; shows the redacted text before sending.

## Limitations
- Boards must be flat, upright and fully visible. Unusual themes, animations, move arrows or 3D sets may fail.
- Chess960 start positions would teach wrong piece names; learn from standard chess only.
- Side to move is sometimes a guess; castling and en passant may need setting under **Turn / rights**.
- Without accessibility, control types are estimates. Unlabelled icons cannot be identified.
- Latin-script text only. Apps that block capture appear black.

## Layout
`app/src/main/java/com/screenmind/app/`: ui, overlay, capture, vision, chess, engine, assistant, software,
settings, history, services, utils. Tests are in `app/src/test/`.
