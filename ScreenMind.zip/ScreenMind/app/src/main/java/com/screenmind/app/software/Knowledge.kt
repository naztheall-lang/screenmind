package com.screenmind.app.software

data class ErrorRule(val pattern: Regex, val meaning: String, val steps: List<String>)

data class ControlInfo(val names: List<String>, val explanation: String)

/** [targets] are labels that complete the task; [paths] are places that usually lead to it. */
data class TaskGuide(
    val title: String,
    val triggers: List<String>,
    val targets: List<String>,
    val paths: List<String>,
    val steps: List<String>,
)

/** Curated offline knowledge about common interfaces. */
object Knowledge {
    private fun rule(p: String, meaning: String, vararg steps: String) =
        ErrorRule(Regex(p, RegexOption.IGNORE_CASE), meaning, steps.toList())

    val errors = listOf(
        rule("no (internet|network)|offline|network (error|unavailable)|check your connection|unable to connect|connection (failed|lost|error|timed out)|ERR_(INTERNET|NETWORK|CONNECTION)",
            "The app could not reach the internet or its server.",
            "Check Wi-Fi or mobile data and open a web page to test it.", "Turn aeroplane mode on and off.", "Try again; the service itself may be down."),
        rule("(not enough|insufficient|low on) (storage|space)|storage (is )?(almost )?full|no space left",
            "The phone does not have enough free storage for this action.",
            "Open Settings > Storage.", "Delete large videos, downloads or unused apps, or clear app caches.", "Retry."),
        rule("out of memory|not enough (memory|ram)", "The phone ran short of working memory.",
            "Close other apps.", "Use a smaller file or lower quality setting.", "Restart the phone if it persists."),
        rule("keeps stopping|has stopped|unfortunately|crashed", "The app crashed.",
            "Reopen it.", "Update the app.", "Settings > Apps > the app > Storage > Clear cache.", "Clearing data also helps but removes local app data."),
        rule("isn.?t responding|not responding", "The app froze.",
            "Choose Wait once.", "If it stays frozen, choose Close app and reopen it."),
        rule("permission (denied|required)|access denied|don.?t have permission|not authori[sz]ed|\\b403\\b|forbidden",
            "The app or your account is not allowed to do this.",
            "If it mentions camera, files, location or similar, enable it in Settings > Apps > the app > Permissions.", "Otherwise check you are signed in to the right account."),
        rule("(incorrect|wrong|invalid) (password|username|email|credentials)|password (is )?incorrect|login failed|sign.?in failed",
            "The sign-in details were not accepted.",
            "Check for typos and Caps Lock.", "Use 'Forgot password' if needed."),
        rule("session (has )?expired|signed out|log in again|\\b401\\b", "Your sign-in has timed out.", "Sign in again."),
        rule("\\b404\\b|page not found|file not found", "The page or file requested does not exist at that address.",
            "Check the address or search for the item.", "It may have been moved or deleted."),
        rule("\\b50[0234]\\b|server error|service unavailable|bad gateway", "The service's server had a problem. It is not your phone.",
            "Wait a few minutes and retry."),
        rule("certificate|not private|not secure|SSL", "A secure connection could not be verified.",
            "Check the phone's date and time are automatic.", "Do not enter passwords on this page until it is resolved."),
        rule("too many (requests|attempts)|try again later|rate limit", "You have been temporarily limited.", "Wait before trying again."),
        rule("(invalid|unsupported) (file|format)|corrupt|can.?t (open|play) (this )?file", "The file type is unsupported or the file is damaged.",
            "Download the file again.", "Convert it or open it with another app."),
        rule("app not installed|parse(ing)? (the )?package", "Android could not install the package.",
            "Check storage space.", "Download the APK again.", "Uninstall an older copy signed with a different key.", "Check it suits your processor type."),
        rule("required field|cannot be (empty|blank)|please (enter|fill)", "A form field is missing or empty.",
            "Fill in the highlighted field and submit again."),
        rule("update required|version.{0,20}no longer supported|please update", "This app version is too old.", "Update it from your app store."),
    )

    private val generic = Regex("\\b(error|failed|failure|couldn.?t|could not|cannot|can.?t|unable to|something went wrong)\\b", RegexOption.IGNORE_CASE)

    fun looksLikeError(text: String): Boolean =
        text.length in 5..300 && (generic.containsMatchIn(text) || errors.take(7).any { it.pattern.containsMatchIn(text) })

    fun explainError(text: String): ErrorRule? = errors.firstOrNull { it.pattern.containsMatchIn(text) }

    private fun control(explanation: String, vararg names: String) = ControlInfo(names.toList(), explanation)

    val controls = listOf(
        control("Opens extra actions that do not fit on screen.", "more options", "more", "overflow", "⋮", "..."),
        control("Opens the main menu or navigation drawer.", "menu", "navigation drawer", "open drawer", "hamburger", "≡"),
        control("Returns to the previous screen.", "back", "navigate up"),
        control("Closes this panel or dialogue.", "close", "dismiss"),
        control("Sends a copy or link to another app or person.", "share"),
        control("Saves the work as a file in a chosen format.", "export", "save as"),
        control("Brings an existing file or data into this app.", "import"),
        control("Keeps your changes.", "save", "apply", "done"),
        control("Abandons this action without applying it.", "cancel", "not now"),
        control("Removes the item; check whether it can be undone.", "delete", "remove", "trash", "bin"),
        control("Finds items by typing words.", "search", "find"),
        control("Opens the app's preferences.", "settings", "preferences", "options"),
        control("Starts something new.", "new", "create", "add", "+", "compose"),
        control("Changes the existing item.", "edit", "rename"),
        control("Reverses the last change.", "undo"),
        control("Restores the change you just undid.", "redo"),
        control("Reloads the content.", "refresh", "reload", "sync"),
        control("Narrows or reorders the list.", "filter", "sort"),
        control("Marks the item so you can find it again.", "favourite", "favorite", "bookmark", "star"),
        control("Shows your account and profile choices.", "account", "profile", "me"),
        control("Saves a copy to your phone.", "download"),
        control("Sends a file from your phone to the service.", "upload", "attach"),
        control("Shows guidance or support.", "help", "support", "about"),
        control("Sends what you have written.", "send", "submit", "post"),
        control("Ends your session on this account.", "sign out", "log out", "logout"),
    )

    fun explainControl(label: String): String? {
        val l = label.lowercase().trim()
        return (controls.firstOrNull { c -> c.names.any { it == l } }
            ?: controls.firstOrNull { c -> c.names.any { it.length > 3 && Regex("\\b${Regex.escape(it)}\\b").containsMatchIn(l) } })
            ?.explanation
    }

    private val OVERFLOW = listOf("more options", "more", "menu", "navigation drawer", "⋮")

    val guides = listOf(
        TaskGuide("Export", listOf("export", "save as", "render"), listOf("export", "save as", "render", "download"),
            listOf("share", "file") + OVERFLOW,
            listOf("Open the project or file.", "Look for Export or Share in the top bar, File menu or ⋮ menu.", "Choose a format, then confirm.")),
        TaskGuide("Create something new", listOf("new project", "create", "new file", "new document", "start a new", "add a new"),
            listOf("new project", "create project", "new", "create", "add", "+"), listOf("projects", "home", "file") + OVERFLOW,
            listOf("Go to the app's home or projects screen.", "Tap New, Create or the + button.", "Name it and confirm.")),
        TaskGuide("Change a setting", listOf("setting", "preference", "change", "turn on", "turn off", "enable", "disable"),
            listOf("settings", "preferences"), listOf("account", "profile", "me") + OVERFLOW,
            listOf("Open Settings, usually behind a gear icon, your profile picture or the ⋮ menu.", "Use settings search if there is one.", "Change the option and go back; most save automatically.")),
        TaskGuide("Dark mode", listOf("dark mode", "dark theme", "night mode"), listOf("dark mode", "dark theme", "theme", "appearance", "display"),
            listOf("settings") + OVERFLOW, listOf("Open Settings.", "Look under Appearance, Display or Theme.", "Choose Dark.")),
        TaskGuide("Share", listOf("share", "send to"), listOf("share", "send"), OVERFLOW,
            listOf("Open or select the item.", "Tap Share.", "Pick the app or contact.")),
        TaskGuide("Search", listOf("search", "find", "look for"), listOf("search", "find"), OVERFLOW,
            listOf("Tap the magnifying glass or search box.", "Type what you need.")),
        TaskGuide("Delete", listOf("delete", "remove"), listOf("delete", "remove", "trash"), listOf("edit", "select") + OVERFLOW,
            listOf("Long-press the item to select it, or open it.", "Tap Delete or the bin.", "Confirm.")),
        TaskGuide("Save", listOf("save"), listOf("save", "done", "apply"), listOf("file") + OVERFLOW,
            listOf("Tap Save, Done or the tick, usually top right.")),
        TaskGuide("Undo", listOf("undo", "revert"), listOf("undo"), listOf("edit") + OVERFLOW,
            listOf("Tap the curved back arrow, or Undo in the Edit menu.")),
        TaskGuide("Sign out", listOf("sign out", "log out", "logout"), listOf("sign out", "log out", "logout"),
            listOf("account", "profile", "settings") + OVERFLOW, listOf("Open your profile or Settings.", "Scroll to the bottom.", "Tap Sign out.")),
        TaskGuide("Go back", listOf("go back", "return", "previous screen"), listOf("back", "navigate up"), emptyList(),
            listOf("Swipe in from either screen edge, or tap the back arrow at the top left.")),
    )
}
