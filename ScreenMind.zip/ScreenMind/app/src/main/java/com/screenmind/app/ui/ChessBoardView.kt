package com.screenmind.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import com.screenmind.app.chess.Move
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.Side
import com.screenmind.app.chess.Squares
import com.screenmind.app.vision.PieceArt

@SuppressLint("ViewConstructor")
class ChessBoardView(context: Context, private val onSquare: (Int) -> Unit) : View(context) {
    var position: Position = Position.start()
        set(v) {
            field = v
            invalidate()
        }
    var flipped = false
        set(v) {
            field = v
            invalidate()
        }
    var selected: Int? = null
    var targets: Set<Int> = emptySet()
    var lastMove: Move? = null
    var arrow: Move? = null
    var doubtful: Set<Int> = emptySet()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val paths: Map<PieceType, List<Path>> = PieceType.values().associateWith { type ->
        PieceArt.outline(type).map { points ->
            Path().apply {
                moveTo(points[0], points[1])
                for (i in 2 until points.size step 2) lineTo(points[i], points[i + 1])
                close()
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val max = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        val side = minOf(w, max)
        setMeasuredDimension(w, side)
    }

    private val cell: Float get() = minOf(width, height) / 8f
    private val offset: Float get() = (width - cell * 8) / 2

    private fun column(sq: Int) = if (flipped) 7 - Squares.file(sq) else Squares.file(sq)
    private fun line(sq: Int) = if (flipped) Squares.rank(sq) else 7 - Squares.rank(sq)

    fun refresh() = invalidate()

    override fun onDraw(canvas: Canvas) {
        val s = cell
        for (sq in 0 until 64) {
            val x = offset + column(sq) * s
            val y = line(sq) * s
            val light = (Squares.file(sq) + Squares.rank(sq)) % 2 == 1
            paint.style = Paint.Style.FILL
            paint.color = when {
                sq == selected -> Color.rgb(112, 162, 132)
                lastMove?.let { it.from == sq || it.to == sq } == true -> Color.rgb(186, 186, 100)
                light -> Color.rgb(214, 208, 192)
                else -> Color.rgb(118, 132, 120)
            }
            canvas.drawRect(x, y, x + s, y + s, paint)
            if (sq in doubtful) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.08f
                paint.color = Ui.WARN
                canvas.drawRect(x + s * 0.05f, y + s * 0.05f, x + s * 0.95f, y + s * 0.95f, paint)
            }
            position[sq]?.let { drawPiece(canvas, it, x, y, s) }
            if (sq in targets) {
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(130, 30, 60, 40)
                canvas.drawCircle(x + s / 2, y + s / 2, s * 0.15f, paint)
            }
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(40, 40, 40)
        paint.textSize = s * 0.2f
        for (i in 0..7) {
            val file = if (flipped) 7 - i else i
            val rank = if (flipped) i else 7 - i
            canvas.drawText(('a' + file).toString(), offset + i * s + s * 0.82f, s * 8 - s * 0.05f, paint)
            canvas.drawText(('1' + rank).toString(), offset + s * 0.04f, i * s + s * 0.22f, paint)
        }
        arrow?.let { drawArrow(canvas, it, s) }
    }

    private fun drawPiece(canvas: Canvas, piece: Piece, x: Float, y: Float, s: Float) {
        canvas.save()
        canvas.translate(x, y)
        canvas.scale(s / 100f, s / 100f)
        val white = piece.side == Side.WHITE
        // Outline first, then fill, so overlapping parts merge into one silhouette.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 7f
        paint.color = Color.rgb(20, 20, 20)
        paths.getValue(piece.type).forEach { canvas.drawPath(it, paint) }
        paint.style = Paint.Style.FILL
        paint.color = if (white) Color.rgb(250, 250, 250) else Color.rgb(45, 42, 40)
        paths.getValue(piece.type).forEach { canvas.drawPath(it, paint) }
        canvas.restore()
    }

    private fun drawArrow(canvas: Canvas, move: Move, s: Float) {
        val x1 = offset + column(move.from) * s + s / 2
        val y1 = line(move.from) * s + s / 2
        val x2 = offset + column(move.to) * s + s / 2
        val y2 = line(move.to) * s + s / 2
        val angle = kotlin.math.atan2(y2 - y1, x2 - x1)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.14f
        paint.color = Color.argb(200, 40, 120, 190)
        canvas.drawLine(x1, y1, x2, y2, paint)
        for (turn in floatArrayOf(2.5f, -2.5f)) {
            canvas.drawLine(x2, y2, x2 + s * 0.38f * kotlin.math.cos(angle + turn), y2 + s * 0.38f * kotlin.math.sin(angle + turn), paint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val col = ((event.x - offset) / cell).toInt()
            val row = (event.y / cell).toInt()
            if (event.x >= offset && col in 0..7 && row in 0..7) {
                onSquare(Squares.of(if (flipped) 7 - col else col, if (flipped) row else 7 - row))
            }
        }
        return true
    }
}
