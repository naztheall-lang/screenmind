package com.screenmind.app.assistant

import com.screenmind.app.chess.FairPlayGuard
import com.screenmind.app.software.ElementType
import com.screenmind.app.software.IRect
import com.screenmind.app.software.Knowledge
import com.screenmind.app.software.ScreenModel
import com.screenmind.app.software.UiElement

enum class Certainty(val label: String) { SURE("Identified on screen"), LIKELY("Likely"), UNSURE("Not certain") }

data class Answer(val text: String, val certainty: Certainty, val highlight: IRect? = null)

/** Rule-based answers from the recognised screen. Works offline and says when it does not know. */
object OfflineAssistant {
    private val STOP = setOf(
        "where", "is", "the", "a", "an", "button", "icon", "option", "menu", "tab", "field", "how", "do", "i", "can",
        "to", "this", "that", "it", "what", "does", "mean", "find", "on", "in", "of", "my", "me", "for", "app", "screen",
    )

    fun answer(question: String, screen: ScreenModel?): Answer {
        val q = question.lowercase().trim().trimEnd('?', '.', '!')
        if (q.isEmpty()) return Answer("Ask a question about the screen.", Certainty.UNSURE)
        if (FairPlayGuard.asksForMove(q)) {
            return Answer(
                "I don't suggest moves here. For a finished game or a practice position, use the Chess screen.", Certainty.SURE,
            )
        }
        if (screen == null || screen.elements.isEmpty()) {
            val guide = guideFor(q)
            return Answer(
                "I haven't read a screen yet. Open the other app and tap Analyse on the floating panel." +
                    (guide?.let { "\n\nGeneral steps:\n" + numbered(it.steps) } ?: ""), Certainty.UNSURE,
            )
        }
        return when {
            Regex("error|warning|went wrong|problem|fail|mean(s)?$").containsMatchIn(q) &&
                (screen.errors.isNotEmpty() || q.contains("error")) -> error(screen)
            Regex("^(explain|describe|summari[sz]e)\\b|what (am i|is this|is on)|this (screen|interface|app)").containsMatchIn(q) ->
                explain(screen)
            q.startsWith("where") || q.startsWith("find") || q.startsWith("show me") || q.startsWith("locate") -> where(q, screen)
            q.startsWith("how") -> howTo(q, screen)
            q.startsWith("what does") || q.startsWith("what is") || q.startsWith("what's") -> whatIs(q, screen)
            else -> where(q, screen)
        }
    }

    private fun words(q: String) = q.split(Regex("[^a-z0-9+]+")).filter { it.isNotEmpty() && it !in STOP }

    /** 0..1 similarity between the words asked for and an element label. */
    fun matchScore(query: String, label: String): Float {
        val l = label.lowercase()
        val target = query.trim()
        if (target.isEmpty()) return 0f
        if (l == target) return 1f
        val labelWords = l.split(Regex("[^a-z0-9+]+")).filter { it.isNotEmpty() }
        val asked = target.split(' ')
        val hits = asked.count { a -> labelWords.any { it == a || (a.length > 3 && distance(a, it) <= 1) || (a.length > 4 && it.startsWith(a)) } }
        if (hits == 0) return 0f
        val coverage = hits.toFloat() / asked.size
        val focus = hits.toFloat() / maxOf(hits, labelWords.size)
        return 0.7f * coverage + 0.25f * focus
    }

    private fun distance(a: String, b: String): Int {
        var row = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val next = IntArray(b.length + 1)
            next[0] = i
            for (j in 1..b.length) {
                next[j] = minOf(next[j - 1] + 1, row[j] + 1, row[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            row = next
        }
        return row[b.length]
    }

    private fun best(query: String, screen: ScreenModel): Pair<UiElement, Float>? =
        screen.elements.filter { it.type != ElementType.DIALOG }
            .map { e ->
                // Controls beat plain text that merely mentions the word.
                val weight = if (e.type == ElementType.TEXT || e.type == ElementType.ERROR) 0.75f else 1f
                e to matchScore(query, e.label) * weight
            }
            .filter { it.second >= 0.4f }
            .maxByOrNull { it.second * (0.7f + 0.3f * it.first.confidence) }

    private fun describe(e: UiElement, s: ScreenModel) =
        "\"${e.label.take(60)}\" (${e.type.label.lowercase()}) is at the ${s.position(e.bounds)}" +
            (if (!e.enabled) ", but it is currently disabled" else "") + "."

    private fun certainty(e: UiElement, score: Float) =
        if (score > 0.85f && e.confidence > 0.7f) Certainty.SURE else if (score > 0.6f) Certainty.LIKELY else Certainty.UNSURE

    private fun where(q: String, s: ScreenModel): Answer {
        val query = words(q).joinToString(" ")
        best(query, s)?.let { (e, score) -> return Answer(describe(e, s), certainty(e, score), e.bounds) }
        val guide = guideFor(q)
        if (guide != null) return follow(guide, s)
        return Answer(
            "I can't see \"$query\" on this screen. It may be off screen, unlabelled, or inside a menu. Scroll or open a menu, then analyse again.",
            Certainty.UNSURE,
        )
    }

    private fun guideFor(q: String) = Knowledge.guides.mapNotNull { g ->
        g.triggers.filter { Regex("\\b${Regex.escape(it)}").containsMatchIn(q) }.maxByOrNull { it.length }?.let { g to it.length }
    }.let { found ->
        // A specific task ("export") wins over the generic "change a setting".
        (found.filter { it.first.title != "Change a setting" }.ifEmpty { found }).maxByOrNull { it.second }?.first
    }

    private fun follow(g: com.screenmind.app.software.TaskGuide, s: ScreenModel): Answer {
        for (target in g.targets) {
            val hit = best(target, s) ?: continue
            if (hit.second >= 0.65f && hit.first.type != ElementType.TEXT && hit.first.type != ElementType.TEXT_FIELD) {
                return Answer("${g.title}: tap it now. " + describe(hit.first, s), certainty(hit.first, hit.second), hit.first.bounds)
            }
        }
        for (path in g.paths) {
            val hit = best(path, s) ?: continue
            if (hit.second >= 0.65f && hit.first.type != ElementType.TEXT && hit.first.type != ElementType.TEXT_FIELD) {
                return Answer(
                    "${g.title}: no direct control is visible. Try this first: " + describe(hit.first, s) + " Then analyse again.",
                    Certainty.LIKELY, hit.first.bounds,
                )
            }
        }
        return Answer("I can't see the control for this here. Typical steps:\n" + numbered(g.steps), Certainty.UNSURE)
    }

    private fun howTo(q: String, s: ScreenModel): Answer {
        guideFor(q)?.let { return follow(it, s) }
        val hit = best(words(q).joinToString(" "), s)
        return if (hit != null) {
            Answer("This looks relevant: " + describe(hit.first, s), Certainty.UNSURE, hit.first.bounds)
        } else {
            Answer("I don't have offline steps for that, and I see no matching control. Open the app's menu or settings and analyse again.", Certainty.UNSURE)
        }
    }

    private fun whatIs(q: String, s: ScreenModel): Answer {
        val query = words(q).joinToString(" ")
        val hit = best(query, s)
        val label = hit?.first?.label ?: query
        val meaning = Knowledge.explainControl(label) ?: Knowledge.explainControl(query)
        return when {
            meaning != null && hit != null -> Answer("${describe(hit.first, s)} $meaning", Certainty.LIKELY, hit.first.bounds)
            meaning != null -> Answer("Usually: $meaning I don't see it on this screen.", Certainty.UNSURE)
            hit != null -> Answer("${describe(hit.first, s)} I don't know for certain what it does in this app.", Certainty.UNSURE, hit.first.bounds)
            else -> Answer("I can't identify that.", Certainty.UNSURE)
        }
    }

    private fun error(s: ScreenModel): Answer {
        if (s.errors.isEmpty()) return Answer("I don't see an error message on this screen.", Certainty.UNSURE)
        val all = s.errors.joinToString(" ") { it.label }
        val rule = Knowledge.explainError(all) ?: Knowledge.explainError(s.elements.joinToString(" ") { it.label })
        val shown = s.errors.first()
        return if (rule != null) {
            Answer("\"${shown.label.take(120)}\"\n${rule.meaning}\n${numbered(rule.steps)}", Certainty.LIKELY, shown.bounds)
        } else {
            Answer(
                "The screen says \"${shown.label.take(200)}\". I don't recognise this error. Note the exact wording and any code, retry once, then check the app's help.",
                Certainty.UNSURE, shown.bounds,
            )
        }
    }

    private fun explain(s: ScreenModel): Answer {
        val controls = s.elements.filter { it.type != ElementType.TEXT && it.type != ElementType.DIALOG && !it.label.startsWith("Unlabelled") }
        val lines = controls.distinctBy { it.label.lowercase() }.take(10).joinToString("\n") { e ->
            "• ${e.label.take(40)} — ${e.type.label.lowercase()}, ${s.position(e.bounds)}" +
                (Knowledge.explainControl(e.label)?.let { ". $it" } ?: "")
        }
        return Answer(s.summary() + if (lines.isEmpty()) "" else "\n\n$lines", if (s.usedAccessibility) Certainty.SURE else Certainty.LIKELY)
    }

    private fun numbered(steps: List<String>) = steps.mapIndexed { i, t -> "${i + 1}. $t" }.joinToString("\n")
}
