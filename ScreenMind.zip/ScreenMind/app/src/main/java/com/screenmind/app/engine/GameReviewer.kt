package com.screenmind.app.engine

import com.screenmind.app.chess.Game
import com.screenmind.app.chess.GameStatus
import com.screenmind.app.chess.Move
import com.screenmind.app.chess.San
import com.screenmind.app.chess.Side

enum class MoveQuality(val label: String, val mark: String) {
    BEST("Best", ""),
    GOOD("Good", ""),
    INACCURACY("Inaccuracy", "?!"),
    MISTAKE("Mistake", "?"),
    BLUNDER("Blunder", "??"),
}

data class ReviewedMove(
    val ply: Int,
    val side: Side,
    val san: String,
    val quality: MoveQuality,
    val lossCentipawns: Int,
    val bestSan: String?,
    /** Evaluation after the move, as White sees it. */
    val evaluation: String,
)

data class GameReview(val moves: List<ReviewedMove>) {
    fun count(side: Side, quality: MoveQuality) = moves.count { it.side == side && it.quality == quality }

    fun averageLoss(side: Side): Int {
        val own = moves.filter { it.side == side }
        return if (own.isEmpty()) 0 else own.sumOf { it.lossCentipawns } / own.size
    }

    fun summary(): String = Side.values().joinToString("\n") { s ->
        "${s.title}: average loss ${averageLoss(s)} cp · ${count(s, MoveQuality.INACCURACY)} inaccuracies · " +
            "${count(s, MoveQuality.MISTAKE)} mistakes · ${count(s, MoveQuality.BLUNDER)} blunders"
    }
}

/** Post-game review: each position is searched once and consecutive scores are compared. */
class GameReviewer(private val engine: ChessEngine) {
    private data class Eval(val score: Score, val best: Move?)

    suspend fun review(game: Game, settings: EngineSettings, onProgress: (done: Int, total: Int) -> Unit): GameReview {
        val single = settings.copy(multiPv = 1)
        val total = game.length + 1
        val moves = game.moves.toList()
        val evals = ArrayList<Eval>(total)
        for (i in 0 until total) {
            val p = game.positionAt(i)
            evals.add(
                when {
                    p.legalMoves().isEmpty() ->
                        Eval(if (Game.statusOf(p) == GameStatus.CHECKMATE) Score(mateIn = 0) else Score(0), null)
                    else -> {
                        val request = AnalysisRequest(p, game.start.toFen(), moves.subList(0, i))
                        val line = engine.analyse(request, single).lines.firstOrNull()
                            ?: throw EngineException("No evaluation for move $i")
                        Eval(line.score, line.move)
                    }
                }
            )
            onProgress(i + 1, total)
        }
        return GameReview(moves.indices.map { i ->
            val before = game.positionAt(i)
            val bestValue = clamp(evals[i].score)
            val after = evals[i + 1].score
            // Mate-in-0 means the player to move has been mated, i.e. the mover won.
            val playedValue = if (after.mateIn == 0) LIMIT else -clamp(after)
            val loss = if (moves[i] == evals[i].best) 0 else maxOf(0, bestValue - playedValue)
            val quality = when {
                loss <= 20 -> MoveQuality.BEST
                loss <= 60 -> MoveQuality.GOOD
                loss <= 120 -> MoveQuality.INACCURACY
                loss <= 250 -> MoveQuality.MISTAKE
                else -> MoveQuality.BLUNDER
            }
            ReviewedMove(
                ply = i + 1,
                side = before.sideToMove,
                san = San.write(before, moves[i]),
                quality = quality,
                lossCentipawns = loss,
                bestSan = evals[i].best?.takeIf { it != moves[i] }?.let { San.write(before, it) },
                evaluation = after.display(before.sideToMove.other),
            )
        })
    }

    private fun clamp(s: Score): Int = s.value().coerceIn(-LIMIT, LIMIT)

    private companion object {
        const val LIMIT = 1500
    }
}
