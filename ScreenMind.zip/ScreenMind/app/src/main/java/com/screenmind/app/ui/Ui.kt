package com.screenmind.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel

/** The design system: charcoal surfaces, one muted green accent, square-ish corners. */
object Ui {
    val BG = Color.rgb(27, 29, 31)
    val SURFACE = Color.rgb(37, 40, 43)
    val LINE = Color.rgb(58, 63, 68)
    val TEXT = Color.rgb(230, 228, 223)
    val MUTED = Color.rgb(154, 160, 166)
    val ACCENT = Color.rgb(143, 188, 139)
    val WARN = Color.rgb(224, 160, 100)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun text(c: Context, value: CharSequence, sp: Float = 15f, colour: Int = TEXT): TextView = TextView(c).apply {
        text = value
        textSize = sp
        setTextColor(colour)
    }

    fun box(c: Context, fill: Int, border: Int = LINE) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(c, 1), border)
        cornerRadius = dp(c, 3).toFloat()
    }
}

abstract class BaseActivity : Activity() {
    protected val scope = MainScope()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    protected fun page(title: String): LinearLayout {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(context, 16)
            setPadding(p, p, p, p)
        }
        column.add(Ui.text(this, title, 22f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }, bottom = 8)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            fitsSystemWindows = true
            addView(column)
        })
        return column
    }

    protected fun <T : View> LinearLayout.add(view: T, top: Int = 0, bottom: Int = 8): T {
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.topMargin = Ui.dp(context, top)
        p.bottomMargin = Ui.dp(context, bottom)
        addView(view, p)
        return view
    }

    protected fun LinearLayout.heading(value: String) =
        add(Ui.text(context, value.uppercase(), 12f, Ui.MUTED).apply { letterSpacing = 0.08f }, top = 12, bottom = 6)

    protected fun LinearLayout.note(value: CharSequence, colour: Int = Ui.MUTED) = add(Ui.text(context, value, 14f, colour))

    protected fun button(label: String, primary: Boolean = false, onClick: () -> Unit): TextView =
        Ui.text(this, label, 14f, if (primary) Ui.BG else Ui.TEXT).apply {
            gravity = Gravity.CENTER
            minHeight = Ui.dp(context, 46)
            setPadding(Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8))
            background = Ui.box(context, if (primary) Ui.ACCENT else Ui.SURFACE, if (primary) Ui.ACCENT else Ui.LINE)
            isFocusable = true
            setOnClickListener { onClick() }
        }

    protected fun card(title: String, detail: String, onClick: (() -> Unit)? = null): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.box(context, Ui.SURFACE)
            val p = Ui.dp(context, 12)
            setPadding(p, p, p, p)
            addView(Ui.text(context, title, 16f))
            if (detail.isNotEmpty()) addView(Ui.text(context, detail, 13f, Ui.MUTED))
            if (onClick != null) setOnClickListener { onClick() }
        }

    protected fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        for ((i, v) in views.withIndex()) {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) p.leftMargin = Ui.dp(context, 6)
            addView(v, p)
        }
    }

    protected fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(this).apply {
        text = label
        setTextColor(Ui.TEXT)
        textSize = 15f
        isChecked = value
        minHeight = Ui.dp(context, 44)
        setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    protected fun input(hint: String, value: String = "", lines: Int = 1, secret: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or when {
                secret -> InputType.TYPE_TEXT_VARIATION_PASSWORD
                lines > 1 -> InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> 0
            }
            if (lines > 1) {
                minLines = lines
                maxLines = lines * 2
                gravity = Gravity.TOP
            }
        }

    protected fun choose(title: String, options: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(options.toTypedArray()) { _, i -> onPick(i) }.show()
    }

    protected fun message(title: String, body: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("Close", null).show()
    }

    protected fun confirm(title: String, body: String, yes: String, onYes: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body)
            .setPositiveButton(yes) { _, _ -> onYes() }.setNegativeButton("Cancel", null).show()
    }

    protected fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
