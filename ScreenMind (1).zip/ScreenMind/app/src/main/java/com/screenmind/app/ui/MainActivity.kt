package com.screenmind.app.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings.canDrawOverlays
import com.screenmind.app.services.Analyzer
import com.screenmind.app.services.ScreenAccessibilityService
import com.screenmind.app.services.SessionService
import com.screenmind.app.settings.Settings

/** Home dashboard. */
class MainActivity : BaseActivity() {
    override fun onResume() {
        super.onResume()
        val page = page("ScreenMind")
        val reading = SessionService.instance?.isReading == true
        page.add(
            card(
                if (reading) "Screen reading is ON" else "Screen reading is off",
                "Floating panel: ${if (!canDrawOverlays(this)) "needs permission" else if (SessionService.instance != null) "running" else "stopped"}\n" +
                    "Accessibility: ${if (ScreenAccessibilityService.instance != null) "enabled" else "not enabled"}\n" +
                    "Performance: ${Settings(this).performance.label}",
            ) { open(ControlsActivity::class.java) }
        )
        page.add(button(if (canDrawOverlays(this)) "Start floating panel" else "Set up permissions", true) {
            if (canDrawOverlays(this)) SessionService.showPanel(this) else open(ControlsActivity::class.java)
        })
        page.heading("Play and learn")
        page.add(card("♞  Chess analysis", "Practice board, Brilliant move finder, game review") { open(ChessActivity::class.java) })
        page.heading("Screen tools")
        page.add(card("Software recognition", "What is on the last screen read") { open(SoftwareActivity::class.java) })
        page.add(card("Assistant", "Ask where things are and what they do") { open(AssistantActivity::class.java) })
        page.add(card("Screen-reading controls", "Permissions, start, stop, mode") { open(ControlsActivity::class.java) })
        page.add(row(button("History") { open(HistoryActivity::class.java) }, button("Settings") { open(SettingsActivity::class.java) }, button("About") { open(AboutActivity::class.java) }))
        Analyzer.history(this).all().firstOrNull()?.let {
            page.heading("Latest result")
            page.add(card(it.title, it.detail.take(120)) { open(HistoryActivity::class.java) })
        }
    }

    private fun open(target: Class<*>) = startActivity(Intent(this, target))
}
