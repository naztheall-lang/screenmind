package com.screenmind.app.ui

import android.annotation.SuppressLint
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.screenmind.app.chess.Move
import com.screenmind.app.chess.Piece
import com.screenmind.app.chess.PieceType
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.Side
import com.screenmind.app.chess.Squares
import com.screenmind.app.vision.PieceArt

@SuppressLint("ViewConstructor")
class ChessBoardView(context: Context, private val onSquare: (Int) -> Unit) : View(context) {
    var position: Position = Position.start()
        set(v) {
            field = v
            invalidate()
        }
    var flipped = false
        set(v) {
            field = v
            invalidate()
        }
    var selected: Int? = null
    var targets: Set<Int> = emptySet()
    var lastMove: Move? = null
    var arrow: Move? = null
    var doubtful: Set<Int> = emptySet()

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val soften = CornerPathEffect(4f)
    private var sliding: Move? = null
    private var progress = 1f
    private var animator: ValueAnimator? = null

    /** Animates the piece now on [to] travelling from [from]. */
    fun slide(from: Int, to: Int) {
        animator?.cancel()
        sliding = Move(from, to)
        progress = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
    private val paths: Map<PieceType, List<Path>> = PieceType.values().associateWith { type ->
        PieceArt.outline(type).map { points ->
            Path().apply {
                moveTo(points[0], points[1])
                for (i in 2 until points.size step 2) lineTo(points[i], points[i + 1])
                close()
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val max = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        val side = minOf(w, max)
        setMeasuredDimension(w, side)
    }

    private val cell: Float get() = minOf(width, height) / 8f
    private val offset: Float get() = (width - cell * 8) / 2

    private fun column(sq: Int) = if (flipped) 7 - Squares.file(sq) else Squares.file(sq)
    private fun line(sq: Int) = if (flipped) Squares.rank(sq) else 7 - Squares.rank(sq)

    fun refresh() = invalidate()

    override fun onDraw(canvas: Canvas) {
        val s = cell
        for (sq in 0 until 64) {
            val x = offset + column(sq) * s
            val y = line(sq) * s
            val light = (Squares.file(sq) + Squares.rank(sq)) % 2 == 1
            paint.style = Paint.Style.FILL
            paint.color = when {
                sq == selected -> Color.rgb(104, 178, 170)
                lastMove?.let { it.from == sq || it.to == sq } == true -> Color.rgb(198, 200, 92)
                light -> Color.rgb(226, 224, 200)
                else -> Color.rgb(104, 136, 78)
            }
            canvas.drawRect(x, y, x + s, y + s, paint)
            if (sq in doubtful) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.08f
                paint.color = Ui.WARN
                canvas.drawRect(x + s * 0.05f, y + s * 0.05f, x + s * 0.95f, y + s * 0.95f, paint)
            }
            if (sq != sliding?.to || progress >= 1f) position[sq]?.let { drawPiece(canvas, it, x, y, s) }
            if (sq in targets) {
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(130, 30, 60, 40)
                canvas.drawCircle(x + s / 2, y + s / 2, s * 0.15f, paint)
            }
        }
        // The moving piece is drawn last so it passes over the others.
        val move = sliding
        if (move != null && progress < 1f) {
            position[move.to]?.let {
                val x = column(move.from) + (column(move.to) - column(move.from)) * progress
                val y = line(move.from) + (line(move.to) - line(move.from)) * progress
                drawPiece(canvas, it, offset + x * s, y * s, s)
            }
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(40, 40, 40)
        paint.textSize = s * 0.2f
        for (i in 0..7) {
            val file = if (flipped) 7 - i else i
            val rank = if (flipped) i else 7 - i
            canvas.drawText(('a' + file).toString(), offset + i * s + s * 0.82f, s * 8 - s * 0.05f, paint)
            canvas.drawText(('1' + rank).toString(), offset + s * 0.04f, i * s + s * 0.22f, paint)
        }
        arrow?.let { drawArrow(canvas, it, s) }
    }

    private fun drawPiece(canvas: Canvas, piece: Piece, x: Float, y: Float, s: Float) {
        canvas.save()
        canvas.translate(x, y)
        canvas.scale(s / 100f, s / 100f)
        val white = piece.side == Side.WHITE
        paint.pathEffect = null
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(60, 0, 0, 0)
        canvas.drawOval(18f, 82f, 86f, 96f, paint)
        paint.pathEffect = soften
        // Outline first, then fill, so overlapping parts merge into one silhouette.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 6f
        paint.color = Color.rgb(28, 30, 26)
        paths.getValue(piece.type).forEach { canvas.drawPath(it, paint) }
        paint.style = Paint.Style.FILL
        paint.color = if (white) Color.rgb(248, 246, 236) else Color.rgb(58, 56, 52)
        paths.getValue(piece.type).forEach { canvas.drawPath(it, paint) }
        // Shade the right-hand half of each shape for a rounded look.
        canvas.save()
        canvas.clipRect(52f, 0f, 100f, 100f)
        paint.color = if (white) Color.rgb(214, 208, 190) else Color.rgb(40, 38, 35)
        paths.getValue(piece.type).forEach { canvas.drawPath(it, paint) }
        canvas.restore()
        paint.pathEffect = null
        // Base highlight and, on the knight, an eye.
        paint.color = if (white) Color.rgb(140, 132, 112) else Color.rgb(140, 134, 122)
        canvas.drawRect(32f, 79f, 68f, 81.5f, paint)
        if (piece.type == PieceType.KNIGHT) canvas.drawCircle(43f, 29f, 3f, paint)
        canvas.restore()
    }

    private fun drawArrow(canvas: Canvas, move: Move, s: Float) {
        val x1 = offset + column(move.from) * s + s / 2
        val y1 = line(move.from) * s + s / 2
        val x2 = offset + column(move.to) * s + s / 2
        val y2 = line(move.to) * s + s / 2
        val angle = kotlin.math.atan2(y2 - y1, x2 - x1)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.14f
        paint.color = Color.argb(200, 40, 120, 190)
        canvas.drawLine(x1, y1, x2, y2, paint)
        for (turn in floatArrayOf(2.5f, -2.5f)) {
            canvas.drawLine(x2, y2, x2 + s * 0.38f * kotlin.math.cos(angle + turn), y2 + s * 0.38f * kotlin.math.sin(angle + turn), paint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val col = ((event.x - offset) / cell).toInt()
            val row = (event.y / cell).toInt()
            if (event.x >= offset && col in 0..7 && row in 0..7) {
                onSquare(Squares.of(if (flipped) 7 - col else col, if (flipped) row else 7 - row))
            }
        }
        return true
    }
}

/** White's share of the bar grows with White's advantage. */
class EvalBar(context: Context) : View(context) {
    private val paint = Paint()
    private var share = 0.5f
    private var animator: ValueAnimator? = null

    fun show(whiteShare: Float) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(share, whiteShare.coerceIn(0.03f, 0.97f)).apply {
            duration = 450
            addUpdateListener {
                share = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), Ui.dp(context, 10))
    }

    override fun onDraw(canvas: Canvas) {
        paint.color = Color.rgb(58, 56, 52)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.color = Color.rgb(248, 246, 236)
        canvas.drawRect(0f, 0f, width * share, height.toFloat(), paint)
    }
}
