package com.screenmind.app.ui

import android.app.Activity
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel

/** Presses a view down slightly while touched, without consuming the click. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        val down = e.actionMasked == MotionEvent.ACTION_DOWN
        if (down || e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            v.animate().scaleX(if (down) 0.96f else 1f).scaleY(if (down) 0.96f else 1f).setDuration(90).start()
        }
        false
    }
}

/** The design system: dark olive surfaces, a leaf-green accent and raised primary buttons. */
object Ui {
    val BG = Color.rgb(29, 32, 28)
    val SURFACE = Color.rgb(41, 46, 39)
    val LINE = Color.rgb(62, 70, 58)
    val TEXT = Color.rgb(230, 228, 223)
    val MUTED = Color.rgb(154, 160, 166)
    val ACCENT = Color.rgb(122, 176, 76)
    val WARN = Color.rgb(224, 160, 100)
    val ACCENT_DARK = Color.rgb(76, 116, 44)
    val BRILLIANT = Color.rgb(58, 196, 190)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun text(c: Context, value: CharSequence, sp: Float = 15f, colour: Int = TEXT): TextView = TextView(c).apply {
        text = value
        textSize = sp
        setTextColor(colour)
    }

    fun box(c: Context, fill: Int, border: Int = LINE) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(c, 1), border)
        cornerRadius = dp(c, 10).toFloat()
    }
}

abstract class BaseActivity : Activity() {
    protected val scope = MainScope()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    protected fun page(title: String): LinearLayout {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(context, 16)
            setPadding(p, p, p, p)
        }
        column.add(Ui.text(this, title, 22f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }, bottom = 8)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            fitsSystemWindows = true
            addView(column)
        })
        return column
    }

    protected fun <T : View> LinearLayout.add(view: T, top: Int = 0, bottom: Int = 8): T {
        val p = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        p.topMargin = Ui.dp(context, top)
        p.bottomMargin = Ui.dp(context, bottom)
        addView(view, p)
        // Items rise into place one after another.
        view.alpha = 0f
        view.translationY = Ui.dp(context, 14).toFloat()
        view.animate().alpha(1f).translationY(0f).setStartDelay(minOf(childCount, 10) * 30L).setDuration(220).start()
        return view
    }

    protected fun LinearLayout.heading(value: String) =
        add(Ui.text(context, value.uppercase(), 12f, Ui.MUTED).apply { letterSpacing = 0.08f }, top = 12, bottom = 6)

    protected fun LinearLayout.note(value: CharSequence, colour: Int = Ui.MUTED) = add(Ui.text(context, value, 14f, colour))

    protected fun button(label: String, primary: Boolean = false, onClick: () -> Unit): TextView =
        Ui.text(this, label, 14f, if (primary) Ui.BG else Ui.TEXT).apply {
            gravity = Gravity.CENTER
            minHeight = Ui.dp(context, 50)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8), Ui.dp(context, 8))
            val face = Ui.box(context, if (primary) Ui.ACCENT else Ui.SURFACE, if (primary) Ui.ACCENT else Ui.LINE)
            background = LayerDrawable(arrayOf(Ui.box(context, if (primary) Ui.ACCENT_DARK else Ui.LINE, Ui.BG), face)).apply {
                // The darker layer shows below the face, giving the button some depth.
                setLayerInset(1, 0, 0, 0, Ui.dp(context, 3))
            }
            pressable()
            isFocusable = true
            setOnClickListener { onClick() }
        }

    protected fun card(title: String, detail: String, onClick: (() -> Unit)? = null): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.box(context, Ui.SURFACE)
            val p = Ui.dp(context, 12)
            setPadding(p, p, p, p)
            addView(Ui.text(context, title, 16f))
            if (detail.isNotEmpty()) addView(Ui.text(context, detail, 13f, Ui.MUTED))
            if (onClick != null) {
                setOnClickListener { onClick() }
                pressable()
            }
        }

    protected fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        for ((i, v) in views.withIndex()) {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) p.leftMargin = Ui.dp(context, 6)
            addView(v, p)
        }
    }

    protected fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(this).apply {
        text = label
        setTextColor(Ui.TEXT)
        textSize = 15f
        isChecked = value
        minHeight = Ui.dp(context, 44)
        setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    protected fun input(hint: String, value: String = "", lines: Int = 1, secret: Boolean = false): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or when {
                secret -> InputType.TYPE_TEXT_VARIATION_PASSWORD
                lines > 1 -> InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> 0
            }
            if (lines > 1) {
                minLines = lines
                maxLines = lines * 2
                gravity = Gravity.TOP
            }
        }

    protected fun choose(title: String, options: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(options.toTypedArray()) { _, i -> onPick(i) }.show()
    }

    protected fun message(title: String, body: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("Close", null).show()
    }

    protected fun confirm(title: String, body: String, yes: String, onYes: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(body)
            .setPositiveButton(yes) { _, _ -> onYes() }.setNegativeButton("Cancel", null).show()
    }

    protected fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
