package com.screenmind.app.settings

import com.screenmind.app.engine.EngineSettings

/** Resource limits chosen for a 4 GB phone with Cortex-A53 cores. */
enum class PerformanceProfile(
    val label: String,
    val captureWidth: Int,
    val frameIntervalMs: Long,
    val depth: Int,
    val moveTimeMs: Long,
    val threads: Int,
    val hashMb: Int,
) {
    BATTERY("Battery saver", 540, 3000, 10, 3000, 1, 16),
    BALANCED("Balanced", 720, 1500, 14, 6000, 2, 32),
    PERFORMANCE("Performance", 1080, 700, 18, 10000, 4, 64);

    fun engineSettings(depthOverride: Int = 0): EngineSettings =
        EngineSettings(if (depthOverride > 0) depthOverride else depth, moveTimeMs, threads, hashMb, 5)
}
