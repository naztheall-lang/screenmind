package com.screenmind.app.engine

import com.screenmind.app.chess.Move
import com.screenmind.app.chess.Position
import com.screenmind.app.chess.Side
import java.util.Locale

data class EngineSettings(
    val depth: Int = 14,
    val moveTimeMs: Long = 6000,
    val threads: Int = 2,
    val hashMb: Int = 32,
    val multiPv: Int = 5,
)

/** Score from the point of view of the side to move. Exactly one of [centipawns] and [mateIn] is set. */
data class Score(val centipawns: Int? = null, val mateIn: Int? = null) {
    /** A single comparable number; mates dominate any material score. */
    fun value(): Int = when {
        mateIn != null -> if (mateIn > 0) MATE - mateIn else -MATE - mateIn
        else -> centipawns ?: 0
    }

    fun negated(): Score = Score(centipawns?.let { -it }, mateIn?.let { -it })

    /** Text from White's point of view, e.g. "+0.35" or "-M3". */
    fun display(sideToMove: Side): String {
        val sign = if (sideToMove == Side.WHITE) 1 else -1
        val mate = mateIn
        if (mate != null) {
            if (mate == 0) return if (sideToMove == Side.WHITE) "-M0" else "+M0"
            return (if (mate * sign > 0) "+M" else "-M") + kotlin.math.abs(mate)
        }
        return String.format(Locale.US, "%+.2f", (centipawns ?: 0) * sign / 100.0)
    }

    companion object {
        const val MATE = 100_000
    }
}

data class CandidateLine(val rank: Int, val score: Score, val depth: Int, val pv: List<Move>) {
    val move: Move get() = pv.first()
}

data class AnalysisResult(val lines: List<CandidateLine>, val depth: Int, val engineName: String)

/** [startFen] and [moves] give the engine game history so it can see repetitions. */
data class AnalysisRequest(
    val position: Position,
    val startFen: String = position.toFen(),
    val moves: List<Move> = emptyList(),
)

class EngineException(message: String, cause: Throwable? = null) : Exception(message, cause)

interface ChessEngine {
    val name: String

    /** Cancelling the calling coroutine stops the search. */
    suspend fun analyse(
        request: AnalysisRequest,
        settings: EngineSettings,
        onUpdate: (AnalysisResult) -> Unit = {},
    ): AnalysisResult

    fun close()
}
