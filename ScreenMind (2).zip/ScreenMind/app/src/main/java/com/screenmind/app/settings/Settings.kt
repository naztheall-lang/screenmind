package com.screenmind.app.settings

import android.content.Context
import com.screenmind.app.assistant.CloudConfig

class Settings(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun str(key: String, default: String) = p.getString(key, default) ?: default
    private fun put(key: String, value: String) = p.edit().putString(key, value).apply()
    private fun put(key: String, value: Boolean) = p.edit().putBoolean(key, value).apply()
    private fun put(key: String, value: Int) = p.edit().putInt(key, value).apply()

    var performance: PerformanceProfile
        get() = PerformanceProfile.values().firstOrNull { it.name == str("performance", "") } ?: PerformanceProfile.MAXIMUM
        set(v) = put("performance", v.name)

    /** 0 means "use the performance profile". */
    var depth: Int
        get() = p.getInt("depth", 0)
        set(v) = put("depth", v)

    var panelSize: Int
        get() = p.getInt("panelSize", 1)
        set(v) = put("panelSize", v)

    var chessMode: Boolean
        get() = p.getBoolean("chessMode", false)
        set(v) = put("chessMode", v)

    var autoAnalyse: Boolean
        get() = p.getBoolean("auto", false)
        set(v) = put("auto", v)

    var saveHistory: Boolean
        get() = p.getBoolean("history", true)
        set(v) = put("history", v)

    var cloudEnabled: Boolean
        get() = p.getBoolean("cloud", false)
        set(v) = put("cloud", v)

    var cloud: CloudConfig
        get() = CloudConfig(str("cloudUrl", ""), str("cloudModel", ""), str("cloudKey", ""))
        set(v) {
            put("cloudUrl", v.baseUrl)
            put("cloudModel", v.model)
            put("cloudKey", v.apiKey)
        }

    /** Engine analysis stays locked until this time after a live game was seen. */
    var engineLockedUntil: Long
        get() = p.getLong("lockUntil", 0)
        set(v) = p.edit().putLong("lockUntil", v).apply()
}
