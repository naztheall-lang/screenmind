package com.screenmind.app.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DeepAnalysis(val main: AnalysisResult, val brilliant: List<CandidateLine>)

/**
 * First finds the strongest moves, then searches every sacrifice that was not among them,
 * so a Brilliant move cannot be missed just because it ranked low early on.
 */
object DeepSearch {
    private const val SACRIFICE_LINES = 4

    suspend fun run(
        engine: ChessEngine,
        request: AnalysisRequest,
        settings: EngineSettings,
        onUpdate: (AnalysisResult) -> Unit = {},
        onHunt: () -> Unit = {},
    ): DeepAnalysis = withContext(Dispatchers.Default) {
        val main = engine.analyse(request, settings, onUpdate)
        var extra = emptyList<CandidateLine>()
        if (main.depth >= Brilliancy.MIN_DEPTH) {
            val known = main.lines.map { it.move }
            val offers = Brilliancy.candidates(request.position).filter { it !in known }
            if (offers.isNotEmpty()) {
                onHunt()
                val narrow = settings.copy(
                    multiPv = minOf(SACRIFICE_LINES, offers.size),
                    depth = main.depth,
                    moveTimeMs = settings.moveTimeMs / 2,
                )
                // A much shallower result is not trustworthy enough to call a sacrifice sound.
                extra = engine.analyse(request.copy(searchMoves = offers), narrow).lines.filter { it.depth >= main.depth - 2 }
            }
        }
        DeepAnalysis(main, Brilliancy.all(request.position, main.lines + extra))
    }
}
