package com.screenmind.app.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import kotlin.concurrent.thread

/** Drives a UCI engine (Stockfish) running as a child process. Works fully offline. */
class StockfishEngine(private val command: List<String>) : ChessEngine {
    constructor(binary: File) : this(listOf(binary.absolutePath))

    private class Session(val process: Process, val input: BufferedWriter, val lines: Channel<String>)

    private val mutex = Mutex()
    @Volatile private var session: Session? = null
    override var name: String = "Stockfish"
        private set

    private fun send(s: Session, command: String) {
        try {
            s.input.write(command)
            s.input.write("\n")
            s.input.flush()
        } catch (e: IOException) {
            throw EngineException("The engine stopped responding", e)
        }
    }

    private suspend fun waitFor(s: Session, timeoutMs: Long, onLine: (String) -> Unit = {}, done: (String) -> Boolean): String {
        val found = withTimeoutOrNull(timeoutMs) {
            var match: String? = null
            while (match == null) {
                val line = s.lines.receiveCatching().getOrNull() ?: throw EngineException("The engine process exited")
                onLine(line)
                if (done(line)) match = line
            }
            match
        }
        return found ?: throw EngineException("The engine timed out")
    }

    private suspend fun ensureStarted(): Session {
        session?.let { if (it.process.isAlive) return it }
        val process = try {
            ProcessBuilder(command).redirectErrorStream(true).start()
        } catch (e: IOException) {
            throw EngineException("Could not start the engine: ${e.message}", e)
        }
        val lines = Channel<String>(Channel.UNLIMITED)
        thread(isDaemon = true, name = "uci-reader") {
            try {
                process.inputStream.bufferedReader().forEachLine { lines.trySend(it) }
            } catch (_: IOException) {
                // The process was destroyed; closing the channel reports it.
            } finally {
                lines.close()
            }
        }
        val s = Session(process, process.outputStream.bufferedWriter(), lines)
        session = s
        send(s, "uci")
        waitFor(s, 15_000, onLine = { if (it.startsWith("id name ")) name = it.removePrefix("id name ").trim() }) { it == "uciok" }
        return s
    }

    override suspend fun analyse(
        request: AnalysisRequest,
        settings: EngineSettings,
        onUpdate: (AnalysisResult) -> Unit,
    ): AnalysisResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (request.position.legalMoves().isEmpty()) return@withLock AnalysisResult(emptyList(), 0, name)
            var searching = false
            try {
                val s = ensureStarted()
                send(s, "setoption name Threads value ${settings.threads}")
                send(s, "setoption name Hash value ${settings.hashMb}")
                send(s, "setoption name MultiPV value ${settings.multiPv}")
                send(s, "isready")
                waitFor(s, 30_000) { it == "readyok" }
                val history = if (request.moves.isEmpty()) "" else " moves " + request.moves.joinToString(" ") { it.uci() }
                send(s, "position fen ${request.startFen}$history")
                val only = if (request.searchMoves.isEmpty()) "" else
                    " searchmoves " + request.searchMoves.joinToString(" ") { it.uci() }
                send(s, "go depth ${settings.depth} movetime ${settings.moveTimeMs}$only")
                searching = true
                val best = sortedMapOf<Int, CandidateLine>()
                var lastDepth = 0
                waitFor(s, settings.moveTimeMs + 20_000, onLine = { line ->
                    val info = UciParser.parseInfo(line, request.position)
                    if (info != null) {
                        best[info.rank] = info
                        // Publish once per completed depth to keep the UI quiet.
                        val choices = request.searchMoves.size.takeIf { it > 0 } ?: request.position.legalMoves().size
                        val expected = minOf(settings.multiPv, choices)
                        if (info.rank == expected && info.depth > lastDepth) {
                            lastDepth = info.depth
                            onUpdate(AnalysisResult(best.values.toList(), info.depth, name))
                        }
                    }
                }) { it.startsWith("bestmove") }
                searching = false
                if (best.isEmpty()) throw EngineException("The engine returned no moves")
                AnalysisResult(best.values.toList(), best.values.maxOf { it.depth }, name)
            } catch (e: CancellationException) {
                if (searching) stopSearch() else close()
                throw e
            } catch (e: EngineException) {
                close()
                throw e
            }
        }
    }

    /** Stops the current search and discards its output so the next one starts clean. */
    private suspend fun stopSearch() = withContext(NonCancellable) {
        val s = session ?: return@withContext
        try {
            send(s, "stop")
            waitFor(s, 3_000) { it.startsWith("bestmove") }
        } catch (_: EngineException) {
            close()
        }
    }

    override fun close() {
        val s = session ?: return
        session = null
        try {
            s.input.write("quit\n")
            s.input.flush()
        } catch (_: IOException) {
            // Already gone.
        }
        s.process.destroy()
    }
}
