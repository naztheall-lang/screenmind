package com.screenmind.app

import com.screenmind.app.assistant.OfflineAssistant
import com.screenmind.app.chess.Fen
import com.screenmind.app.engine.Brilliancy
import com.screenmind.app.engine.CandidateLine
import com.screenmind.app.engine.Score
import com.screenmind.app.software.IRect
import com.screenmind.app.software.RawNode
import com.screenmind.app.software.UiClassifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdateTest {
    private val position = Fen.parse("4k3/8/4p3/8/8/2N5/8/R3K3 w - - 0 1")
    private val offer = position.findLegal("c3d5")!!
    private val quiet = position.findLegal("c3e4")!!
    private fun line(rank: Int, move: com.screenmind.app.chess.Move, cp: Int, depth: Int = 16) =
        CandidateLine(rank, Score(cp), depth, listOf(move))

    @Test fun measuresSacrifices() {
        assertEquals(320, Brilliancy.sacrifice(position, offer))
        assertTrue(Brilliancy.sacrifice(position, quiet) <= 0)
    }

    @Test fun labelsOnlySoundSacrifices() {
        val good = listOf(line(1, quiet, 120), line(2, offer, 100))
        assertEquals(offer, Brilliancy.pick(position, good)!!.move)
        // Unsound, too shallow, or unnecessary because a quiet move already wins.
        assertNull(Brilliancy.pick(position, listOf(line(1, quiet, 120), line(2, offer, -200))))
        assertNull(Brilliancy.pick(position, listOf(line(1, offer, 100, 4))))
        assertNull(Brilliancy.pick(position, listOf(line(1, quiet, 900), line(2, offer, 880))))
    }

    @Test fun assistantUnderstandsCasualQuestions() {
        val screen = UiClassifier.build(
            "App", "a.b", 720, 1600,
            listOf(RawNode("android.widget.Button", text = "Settings", bounds = IRect(600, 60, 710, 130), clickable = true)),
            emptyList(),
        )
        assertTrue(OfflineAssistant.answer("bro can you tell me where's the gear icon pls?", screen).text.contains("top right"))
        assertTrue(OfflineAssistant.answer("What can I tap?", screen).text.contains("Settings"))
        assertTrue(OfflineAssistant.answer("hi", screen).text.contains("ask things like"))
        assertTrue(OfflineAssistant.answer("can you tell me the best move", screen).text.contains("don't suggest moves"))
    }

    /** A scripted engine: the sacrifice only appears when it is searched on its own. */
    @Test fun huntsForSacrificesOutsideTheTopLines() = kotlinx.coroutines.runBlocking {
        val asked = ArrayList<List<com.screenmind.app.chess.Move>>()
        val engine = object : com.screenmind.app.engine.ChessEngine {
            override val name = "scripted"
            override suspend fun analyse(
                request: com.screenmind.app.engine.AnalysisRequest,
                settings: com.screenmind.app.engine.EngineSettings,
                onUpdate: (com.screenmind.app.engine.AnalysisResult) -> Unit,
            ): com.screenmind.app.engine.AnalysisResult {
                asked.add(request.searchMoves)
                val lines = if (request.searchMoves.isEmpty()) listOf(line(1, quiet, 120)) else listOf(line(1, offer, 100))
                return com.screenmind.app.engine.AnalysisResult(lines, 16, name)
            }
            override fun close() {}
        }
        val deep = com.screenmind.app.engine.DeepSearch.run(
            engine, com.screenmind.app.engine.AnalysisRequest(position), com.screenmind.app.engine.EngineSettings(),
        )
        assertEquals(2, asked.size)
        assertTrue(offer in asked[1])
        assertEquals(listOf(offer), deep.brilliant.map { it.move })
    }

    @Test fun engineSearchesOnlyRequestedMoves() = kotlinx.coroutines.runBlocking {
        val result = com.screenmind.app.engine.BuiltinEngine().analyse(
            com.screenmind.app.engine.AnalysisRequest(position, searchMoves = listOf(offer)),
            com.screenmind.app.engine.EngineSettings(depth = 2),
        )
        assertEquals(listOf(offer), result.lines.map { it.move })
    }
}
